﻿using Amazon.DynamoDBv2;
using Amazon.Lambda;
using Amazon.Lambda.ApplicationLoadBalancerEvents;
using Amazon.Lambda.TestUtilities;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.S3;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Extensions.Caching;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using FAMS.HOAService.v1;
using FAMS.HOAService.v1.Models.Service;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using Xunit;

namespace FAMS.HOAService.Tests.v1
{
   public class APITest
    {
        AWSCredentials credentials;
        IAmazonS3 s3Client;
        IAmazonDynamoDB dbClient;
        SecretsManagerCache secretsClient;

        private string POST_VERB = "order";
        private string GET_VERB = "report";
        private string MOCK_VERB = "mock";
        private string VERSION = "v1";
        private string lambda_generated_name = "sbx-hoa-api-w2-allowing-shrimp-private-v1-jodi";
        private string dynamo_generated_name = "sbx-hoa-api-w2-allowing-shrimp-transactions";
        private string s3_generated_name = "sbx-hoa-api-w2-allowing-shrimp";
        public APITest()
        {
            credentials = GetAWSCredentialsFromProfile("sbx");
            s3Client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USWest2);
            dbClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.USWest2);
            IAmazonSecretsManager secretsmanager = new AmazonSecretsManagerClient(credentials, Amazon.RegionEndpoint.USWest2);
            secretsClient = new SecretsManagerCache(secretsmanager);

            Environment.SetEnvironmentVariable("S3_BUCKET", s3_generated_name);
            Environment.SetEnvironmentVariable("DYNAMODB_TABLE", dynamo_generated_name);
            Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:666678657097:key/0d65baf0-0e17-46cb-83b6-e8cb17541a49");
            Environment.SetEnvironmentVariable("LOG_JODI", "true");
            Environment.SetEnvironmentVariable("SERVICE_ZONE_NAME", "hoa");
            Environment.SetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE", "false");
            Environment.SetEnvironmentVariable("ENVIRONMENT", "sbx");
            Environment.SetEnvironmentVariable("RDS_ENDPOINT", "sbx-hoa-api-w2-rds-dgservices.cluster-chguvg3czf42.us-west-2.rds.amazonaws.com");
            Environment.SetEnvironmentVariable("RDS_PWD_SSMPATH", "/FAMS/JODI/postgresqldb/service/inf/adminpassword");
            Environment.SetEnvironmentVariable("VENDOR_INFO_SSMPATH", "/FAMS/JODI/hoa-api/v1/service/inf/vendorinfo");
        }

        #region "HOA Data Vendor"
        [Fact]
        [Trait("Vendor", "")]
        public async void POST_HOAData_Basic_Vendor()
        {
            string fileName = "HOAServiceRequest_Vendor.json";

            var requestStream = BuildJodiRequest("FAMS.HOAService.Tests.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/{2}", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), POST_VERB), null);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The POST search call was not successful.");
        }

        [Fact]
        [Trait("Vendor", "")]
        public async void POST_HOAData_Parcel_Vendor()
        {
            string fileName = "HOAServiceRequest_Parcel_Vendor.json";

            var requestStream = BuildJodiRequest("FAMS.HOAService.Tests.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/{2}", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), POST_VERB), null);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The POST search call was not successful.");
        }

        [Fact]
        [Trait("Vendor", "")]
        public async void POST_HOAData_Parcel_ALB_Vendor()
        {
            string fileName = "HOAServiceRequest_Vendor.json";

            var requestStream = BuildJodiRequest("FAMS.HOAService.Tests.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/{2}", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), POST_VERB), null);

            string elbbody = string.Empty;
            requestStream.Position = 0;
            using (StreamReader rdr = new StreamReader(requestStream))
            {
                elbbody = rdr.ReadToEnd();
            }
            ApplicationLoadBalancerRequest elbrequest = new ApplicationLoadBalancerRequest();
            elbrequest.Body = elbbody;
            // Invoke the lambda function
            var api = new ALB(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(elbrequest, context);

            var desResponse = routingResponse;
            Assert.True(desResponse != null && desResponse.StatusCode == 200, "The POST search call was not successful.");
        }

        #endregion

        #region "Mock"
        [Fact]
        [Trait("Mock", "")]
        public async void POST_Regular()
        {
            string fileName = "HOAServiceRequest_Regular.json";

            var requestStream = BuildJodiRequest("FAMS.HOAService.Tests.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/{2}", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), POST_VERB), null);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The POST search call was not successful.");
        }


        [Fact]
        [Trait("Mock", "")]
        public async void MOCKPOST_Regular()
        {
            string fileName = "HOAServiceMock_Regular.json";

            var requestStream = BuildJodiRequest("FAMS.HOAService.Tests.SampleMock", fileName, "POST", string.Format("/{0}/{1}/{2}", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), MOCK_VERB), null);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The mock POST call was not successful.");
        }

        [Fact]
        [Trait("Mock", "")]
        public async void MOCKPOST_Get()
        {
            string fileName = "HOAServiceMock_Get.json";

            var requestStream = BuildJodiRequest("FAMS.HOAService.Tests.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/{2}", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), POST_VERB), null);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The mock POST call was not successful.");
        }
        #endregion

        #region Helpers

        private AWSCredentials GetAWSCredentialsFromProfile(string profile)
        {
            var credentialProfileStoreChain = new CredentialProfileStoreChain();

            if (credentialProfileStoreChain.TryGetAWSCredentials(profile, out AWSCredentials credentials))
                return credentials;
            else
                throw new AmazonClientException("Unable to find a " + profile + " profile in CredentialProfileStoreChain.");
        }

        private string ReadFileToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();

            resource.CopyTo(ms);

            return Encoding.ASCII.GetString(ms.ToArray());
        }

        private string ConvertServiceRequestToBase64(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);

            return Convert.ToBase64String(ms.ToArray());
        }

        private string ConvertServiceRequestToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);
            string resp = string.Empty;
            //StreamReader sr = null;

            using (Stream resource = assembly.GetManifestResourceStream(file))
            {
                using (var reader = new StreamReader(resource))
                {
                    resp = reader.ReadToEnd();
                }
            }

            return resp;
        }

        private string GetContentTypeFromFile(string extension)
        {
            if (extension.Equals(".json"))
                return "application/json";
            else if (extension.Equals(".xml"))
                return "text/xml";
            else
                return string.Empty;
        }



        public Stream BuildJodiRequest(string filePath, string fileName, string method, string servicePath, string transactionID)
        {
            transactionID = (string.IsNullOrEmpty(transactionID)) ? Guid.NewGuid().ToString() : transactionID;


            HOAServiceRequest req = new HOAServiceRequest
            {
                RequestorID = "RequestorIDRegular123"
            };

            string json = ConvertServiceRequestToString(filePath, fileName);

            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(json);
            string base64body = System.Convert.ToBase64String(plainTextBytes);


            JODIRequest jr = new JODIRequest
            {
                Lambda = lambda_generated_name,
                Body = (string.IsNullOrEmpty(filePath) || string.IsNullOrEmpty(fileName)) ? string.Empty : base64body,
                BodyType = (string.IsNullOrEmpty(fileName)) ? string.Empty : GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", method},
                    { "orig-path", servicePath},
                    { "request-id", transactionID }
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        { "accept", "application/json" },
                        { "content-type", "application/json" },
                        {"cacheperiod", "-1" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        { "clientID", "PDSCLIENT" },
                        { "portalCode", "API" },
                        { "globalID", "TESTPDSCO01" }
                    }
                }
            };

            if (!string.IsNullOrEmpty(transactionID))
            {
                jr.Params.QueryString = new SerializableDictionary<string, string>()
                {
                    { "transactionID", transactionID }
                };
            }

            MemoryStream requestStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, requestStream);

            return requestStream;
        }

        #endregion

    }
}

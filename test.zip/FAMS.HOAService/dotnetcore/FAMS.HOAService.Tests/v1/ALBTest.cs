﻿using Amazon.DynamoDBv2;
using Amazon.Lambda;
using Amazon.Lambda.ApplicationLoadBalancerEvents;
using Amazon.Lambda.TestUtilities;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.S3;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Extensions.Caching;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using FAMS.HOAService.v1;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using Xunit;


namespace FAMS.HOAService.Tests.v1
{
   public class ALBTest
    {
        AWSCredentials credentials;
        IAmazonS3 s3Client;
        IAmazonDynamoDB dbClient;
        IAmazonLambda lambdaClient;
        SecretsManagerCache secretsClient;


        private string POST_VERB = "order";
        private string GET_VERB = "report";
        private string MOCK_VERB = "mock";
        private string VERSION = "v2";

        //private string aws_generated_name = "sbx-propertydata-api-w2-rested-ladybug";
        private string lambda_generated_name = "sbx-property-api-w2-poetic-possum-private-v2-blue";
        private string dynamo_generated_name = "sbx-property-api-w2-poetic-possum-transactions";
        private string s3_generated_name = "sbx-property-api-w2-poetic-possum";

        public ALBTest()
        {
            credentials = GetAWSCredentialsFromProfile("sbx");
            s3Client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USWest2);
            dbClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.USWest2);
            lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.USWest2);
            IAmazonSecretsManager secretsmanager = new AmazonSecretsManagerClient(credentials, Amazon.RegionEndpoint.USWest2);
            secretsClient = new SecretsManagerCache(secretsmanager);


            Environment.SetEnvironmentVariable("S3_BUCKET", s3_generated_name);
            Environment.SetEnvironmentVariable("DYNAMODB_TABLE", dynamo_generated_name);
            Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:666678657097:key/9dfcb18e-0617-4775-a1a3-603d5c5b3459");
            Environment.SetEnvironmentVariable("LOG_JODI", "true");
            Environment.SetEnvironmentVariable("SERVICE_ZONE_NAME", "property");
            Environment.SetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE", "false");
            Environment.SetEnvironmentVariable("ENVIRONMENT", "sbx");
            //Environment.SetEnvironmentVariable("RDS_ENDPOINT", "sbx-property-api-w2-rds-dgservices.cluster-chguvg3czf42.us-west-2.rds.amazonaws.com");
            //Environment.SetEnvironmentVariable("RDS_INFO_SSMPATH", "/FAMS/JODI/postgresqldb/service/inf/adminpassword");
            //Environment.SetEnvironmentVariable("VENDOR_INFO_SSMPATH", "/FAMS/JODI/property-api/v2/service/inf/vendorinfo");
        }
        [Fact]
        [Trait("Vendor", "")]
        public async void POST_PropertyData_Basic_ELB()
        {
            string fileName = "PropertyDataServiceRequest_QA.json";

            ApplicationLoadBalancerRequest elbrequest = BuildALBRequest("FAMS.PropertyService.Tests.v1.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/{2}/premium", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), POST_VERB), null);

            // Invoke the lambda function
            var api = new ALB(s3Client, dbClient,  secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(elbrequest, context);

            var desResponse = (routingResponse);
            Assert.True(desResponse != null && desResponse.StatusCode == 200, "The POST search call was not successful.");
        }
        [Fact]
        [Trait("Vendor", "")]
        public async void Get_PropertyData_Basic_ELB()
        {
            string fileName = "PropertyDataServiceRequest_QA.json";

            ApplicationLoadBalancerRequest elbrequest = BuildALBRequest("FAMS.PropertyService.Tests.v1.SampleRequests", fileName, "GET", string.Format("/{0}/{1}/{2}/premium", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), GET_VERB), null);

            // Invoke the lambda function
            var api = new ALB(s3Client, dbClient,  secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(elbrequest, context);

            var desResponse = (routingResponse);
            Assert.True(desResponse != null && desResponse.StatusCode == 200, "The POST search call was not successful.");
        }

        #region Helpers

        private AWSCredentials GetAWSCredentialsFromProfile(string profile)
        {
            var credentialProfileStoreChain = new CredentialProfileStoreChain();

            if (credentialProfileStoreChain.TryGetAWSCredentials(profile, out AWSCredentials credentials))
                return credentials;
            else
                throw new AmazonClientException("Unable to find a " + profile + " profile in CredentialProfileStoreChain.");
        }

        private string ReadFileToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();

            resource.CopyTo(ms);

            return Encoding.ASCII.GetString(ms.ToArray());
        }

        private string ConvertServiceRequestToBase64(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);

            return Convert.ToBase64String(ms.ToArray());
        }

        private string ConvertServiceRequestToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);
            string resp = string.Empty;
            //StreamReader sr = null;

            using (Stream resource = assembly.GetManifestResourceStream(file))
            {
                using (var reader = new StreamReader(resource))
                {
                    resp = reader.ReadToEnd();
                }
            }

            return resp;
        }

        private string GetContentTypeFromFile(string extension)
        {
            if (extension.Equals(".json"))
                return "application/json";
            else if (extension.Equals(".xml"))
                return "text/xml";
            else
                return string.Empty;
        }

        public string BuildServiceRequest(string filePath, string fileName)
        {
            string json = string.Empty;
            if (!string.IsNullOrEmpty(filePath))
            {
                json = ConvertServiceRequestToString(filePath, fileName);
            }
            return json;
        }

        public ApplicationLoadBalancerRequest BuildALBRequest(string filePath, string fileName, string method, string servicePath, string transactionID)
        {
            ApplicationLoadBalancerRequest albRequest = new ApplicationLoadBalancerRequest();
            transactionID = (string.IsNullOrEmpty(transactionID)) ? Guid.NewGuid().ToString() : transactionID;

            string json = BuildServiceRequest(filePath, fileName);
            albRequest.Body = json;
            Dictionary<string, string> headers = new Dictionary<string, string>();

            headers.Add("accept", "application/json");
            headers.Add("content-type", "application/json");
            headers.Add("px-clientid", "PDSCLIENT");
            headers.Add("px-portalcode", "API");
            headers.Add("px-globalid", "TESTPDSCO01");
            headers.Add("persist", "false");

            albRequest.HttpMethod = method;
            albRequest.Path = servicePath;

            albRequest.Headers = headers;
            //albRequest.QueryStringParameters.Add("transactionID", transactionID);

            return albRequest;
        }


        #endregion
    }
}

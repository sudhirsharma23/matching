﻿using Amazon.DynamoDBv2;
using Amazon.Lambda;
using Amazon.Lambda.Core;
using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.HOAService.core;
using FAMS.HOAService.v1.Models.Service;
using FAMS.HOAService.v1.Models.Vendor;
using FAMS.HOAService.v1.UseCases.Service;

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Amazon.Lambda.ApplicationLoadBalancerEvents;
using System.Text.RegularExpressions;
using System.Drawing;
using Amazon.SecretsManager.Extensions.Caching;

namespace FAMS.HOAService.v1
{
    public class ALB
    {

        #region "properties"
        const string API_VERSION = "v1";

        ServiceUseCase ServiceUseCase;
        HOADataUseCase hoaDataUseCase;
        IAmazonS3 S3Client;
        TransactionRecord<VendorCall> transaction = new TransactionRecord<VendorCall>();
        static List<Route> MethodLookup;
        static object MethodLock = new object();

        public ALB()
        {
            ServiceUseCase = new ServiceUseCase();
            S3Client = new AmazonS3Client();
            hoaDataUseCase = new HOADataUseCase(S3Client, ServiceUseCase);
            InitializeMethodLookup();
            InitializeHttpClient();
        }

        // Used for testing purposes.
        public ALB(IAmazonS3 s3Client, IAmazonDynamoDB dbClient, SecretsManagerCache secretsClient)
        {
            ServiceUseCase = new ServiceUseCase(s3Client, dbClient, secretsClient);
            S3Client = s3Client;
            hoaDataUseCase = new HOADataUseCase(S3Client, ServiceUseCase);
            InitializeMethodLookup();
            InitializeHttpClient();
        }

        #endregion

        #region Route Handler"
        [LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]
        public async Task<ApplicationLoadBalancerResponse> RouteHandler(ApplicationLoadBalancerRequest request, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            ApplicationLoadBalancerResponse response = new ApplicationLoadBalancerResponse();

            try
            {
                ServiceUseCase.InitializeUseCase(request, context);

                Route method = FindMethod(MethodLookup, ServiceUseCase.RequestMetaData.HttpMethod, ServiceUseCase.RequestMetaData.Path);


                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},Supported Methods=GET,POST",
                                                       ServiceUseCase?.RequestMetaData?.Path,
                                                        string.Join(",", MethodLookup.Select(a => a.Path)),
                                                        ServiceUseCase?.RequestMetaData?.HttpMethod);

                    throw new Exception(errorMsg);
                }



                response.StatusCode = response.StatusCode;
                response.Body = response.Body;
                response.StatusDescription = $"{response.StatusCode} {(HttpStatusCode)response.StatusCode}";
                response.IsBase64Encoded = response.IsBase64Encoded;
                response.Headers = response.Headers;

            }
            catch (Exception ex)
            {
                ServiceUseCase?.Logger.LogServiceError(ex,
                                     $"Failure in the RouteHandler. ApplicationLoadBalancerRequest={request}",
                                      FunctionTimer.ElapsedMilliseconds);

                string accept = string.Empty, contentType = string.Empty;
                request?.Headers?.TryGetValue("accept", out accept);
                request?.Headers?.TryGetValue("content-type", out contentType);
                accept = JODIAssistant.SetValidAcceptType(accept, contentType);
                HOAServiceResponse serviceResponse = new HOAServiceResponse();
                Error e = new Error
                {
                    Code = "EX003",
                    Description = $"Internal error occured"
                };
                serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                serviceResponse.Errors.Add(e);
                serviceResponse.TransactionID = ServiceUseCase?.RequestMetaData?.TransactionID;


                response = CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.InternalServerError, accept);
                response.StatusCode = response.StatusCode;
                response.Body = response.Body;
                response.StatusDescription = $"{response.StatusCode} {(HttpStatusCode)response.StatusCode}";
                response.IsBase64Encoded = response.IsBase64Encoded;
                response.Headers = response.Headers;
            }
            finally
            {
                ServiceUseCase?.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                FunctionTimer.Stop();


            }
            return response;
        }

        #endregion


        #region Ping & Health HAndlers and Debug Handler"

        #region "Ping and Healthcheck"
        private async Task<ApplicationLoadBalancerResponse> PingHandler(ApplicationLoadBalancerRequest albRequest, ILambdaContext context)
        {
            return new ApplicationLoadBalancerResponse()
            {
                StatusCode = (int)HttpStatusCode.OK,
                Headers = new Dictionary<string, string> { { "Content-Type", "application/json" } },
                Body = JODIAssistant.SerializeBody<string>("application/json", "{}")
            };
        }
        private async Task<ApplicationLoadBalancerResponse> HealthCheckHandler(ApplicationLoadBalancerRequest albRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();
            string contentType = "application/json";
            HealthCheck health = new HealthCheck(context.FunctionName);
            try
            {
                health = await ServiceUseCase.RunHealthCheck(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.S3_BUCKET, GlobalConfiguration.DYNAMO_TABLE);

                var hoaHealth = await hoaDataUseCase.RunHealthCheck();
                health.Components.TryAdd("HOA", hoaHealth);
                if (hoaHealth.Status == ComponentStatus.Red)
                    health.ServiceStatus = ComponentStatus.Red;

                return new ApplicationLoadBalancerResponse()
                {
                    StatusCode = health.ServiceStatus == ComponentStatus.Red ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK,
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", "application/json" } },
                    Body = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, health),
                    IsBase64Encoded = true
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase?.Logger.LogServiceError(ex, $"Health check failed ", FunctionTimer.ElapsedMilliseconds);
                return new ApplicationLoadBalancerResponse()
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", "application/json" } },
                    Body = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, health),
                    IsBase64Encoded = true
                };

            }
        }

        #endregion

        #region "Debug Handler

        public async Task<ApplicationLoadBalancerResponse> DebugHandler(ApplicationLoadBalancerRequest albRequest, ILambdaContext context)
        {
            Stopwatch functionTimer = new Stopwatch();
            functionTimer.Start();

            ApplicationLoadBalancerResponse response = null;
            string transactionID = string.Empty;

            try
            {

                albRequest?.QueryStringParameters?.TryGetValue("transactionID", out transactionID);

                if (string.IsNullOrEmpty(transactionID))
                    return CreateJODIErrorResponse("transactionID can't be empty", 400, ServiceUseCase.RequestMetaData.Accept, string.Empty);

                var debugResponse = await hoaDataUseCase.HOADebugHandler(transactionID);

                if (debugResponse?.ServiceRequest == null && debugResponse?.ServiceResponse == null && debugResponse?.TransactionRecord == null
                    && debugResponse?.VendorRequest == null && debugResponse?.VendorResponse == null)

                {
                    return CreateJODIErrorResponse("Not Found", 404, ServiceUseCase.RequestMetaData.Accept, string.Empty);
                }


                //create JODI response
                return new ApplicationLoadBalancerResponse()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase.RequestMetaData.Accept } },
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceDebug>(ServiceUseCase.RequestMetaData.Accept, debugResponse),
                    IsBase64Encoded = true
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, $"Failure in the DebugHandler. TransactionID={transactionID}", functionTimer.ElapsedMilliseconds);

                response = CreateJODIErrorResponse("Internal Service Error", 500, ServiceUseCase.RequestMetaData.Accept, transactionID);
            }
            finally
            {
                ServiceUseCase.Logger.LogFunctionExecutionTime(functionTimer.ElapsedMilliseconds);
            }

            return response;
        }


        #endregion

        #endregion

        #region "HOA Data Handler"

        private async Task<ApplicationLoadBalancerResponse> HOAHandler(ApplicationLoadBalancerRequest albRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            ApplicationLoadBalancerResponse applicationLoadbalancerResponse = null;
            HOAServiceResponse serviceResponse = new HOAServiceResponse();

            try
            {
                HOAServiceRequest request = null;
                try
                {
                    request = GetRequestfromALBBody<HOAServiceRequest>(albRequest);
                }

                catch (InvalidOperationException ix)
                {
                    Error e = new Error
                    {
                        Code = "EX001",
                        Description = $"unable to Serialize Request"
                    };
                    serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                    serviceResponse.Errors.Add(e);
                    ServiceUseCase?.Logger.LogServiceError(ix, $"error for TransactionID:{ServiceUseCase?.RequestMetaData?.TransactionID}", FunctionTimer.ElapsedMilliseconds);

                    return CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.BadRequest, ServiceUseCase?.RequestMetaData?.Accept);
                }

                catch (Exception ex)
                {
                    Error e = new Error
                    {
                        Code = "EX002",
                        Description = $"Errors in  Request"
                    };
                    serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                    serviceResponse.Errors.Add(e);
                    ServiceUseCase?.Logger.LogServiceError(ex, $"error for TransactionID:{ServiceUseCase?.RequestMetaData?.TransactionID}", FunctionTimer.ElapsedMilliseconds);
                    return CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.BadRequest, ServiceUseCase?.RequestMetaData?.Accept);
                }


                serviceResponse = await hoaDataUseCase.HOAHandler(request, transaction);
                applicationLoadbalancerResponse = GetALBResponse(serviceResponse, transaction.HttpStatus);
            }
            catch (Exception ex)
            {
                ServiceUseCase?.Logger.LogServiceError(ex, $"Failure in the PostHandler for TransactionID={transaction.TransactionID},Correlation-Token={ServiceUseCase?.RequestMetaData?.CorrelationToken}", FunctionTimer.ElapsedMilliseconds);
            }
            finally
            {
                FunctionTimer.Stop();
            }
            return applicationLoadbalancerResponse;

        }
        private T GetRequestfromALBBody<T>(ApplicationLoadBalancerRequest albRequest)
        {
            T serviceRequest = default(T);
            string albRequestbody = string.Empty;
            if ("gzip".Equals(ServiceUseCase?.RequestMetaData?.AcceptEncoding, StringComparison.InvariantCultureIgnoreCase))
            {
                albRequestbody = GZipHelper.Unzip(Convert.FromBase64String(albRequest.Body));
            }
            else
            {
                albRequestbody = albRequest.Body;
            }
            if (ServiceUseCase.RequestMetaData.ContentType.Contains("xml"))
            {
                serviceRequest = SerializationAssistant.DeserializeXml<T>(albRequestbody);
            }
            else if (ServiceUseCase.RequestMetaData.ContentType.Contains("json"))
            {
                serviceRequest = SerializationAssistant.DeserializeJson<T>(albRequestbody);
            }
            return serviceRequest;
        }

        #endregion

        #region "Get Handler"

        private bool IsPersonaValid(Dictionary<string, string> persona, out string msg, params string[] fieldsToValidate)
        {
            msg = null;

            if (persona == null)
            {
                msg = "Persona is required";
                return false;
            }

            foreach (var field in fieldsToValidate)
            {
                if (!persona.ContainsKey(field) || string.IsNullOrWhiteSpace(persona[field]))
                {
                    msg = "Persona must contain " + field;
                    return false;
                }
            }

            return true;
        }


        private async Task<ApplicationLoadBalancerResponse> GetHandler(ApplicationLoadBalancerRequest albRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();
            HOAServiceResponse serviceResponse = null;
            HOAGetResponse hOAGetResponse = null;

            string transactionID = string.Empty;
            albRequest?.QueryStringParameters?.TryGetValue("transactionID", out transactionID);

            if (!IsPersonaValid(ServiceUseCase.RequestMetaData.Persona, out string msg, "clientID", "globalID") ||
                string.IsNullOrWhiteSpace(transactionID))
            {
                return new ApplicationLoadBalancerResponse()
                {
                    StatusCode = (int)HttpStatusCode.BadRequest,
                    Body = string.IsNullOrWhiteSpace(msg) ? msg : "transactionID is required"
                };
            }
            var response = new ApplicationLoadBalancerResponse()
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase.RequestMetaData?.Accept } },
                IsBase64Encoded = true
            };

            try
            {
                hOAGetResponse = await hoaDataUseCase.GetHandler(transactionID);
                 response = GetALBResponse<HOAServiceResponse>(hOAGetResponse?.ServiceResponse, hOAGetResponse.StatusCode);
                return response;
            }
            catch (Exception ex)
            {
                ServiceUseCase?.Logger.LogServiceError(ex, $"Failure in the GetHandler for TransactionID={transactionID},Correlation-Token={ServiceUseCase.RequestMetaData.CorrelationToken} ", FunctionTimer.ElapsedMilliseconds);
                Error e = new Error
                {
                    Code = "EX003",
                    Description = $"Internal error occured"
                };
                serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                serviceResponse.Errors.Add(e);
                serviceResponse.Status = ServiceStatusCode.Error.ToString();
                response = new ApplicationLoadBalancerResponse()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase.RequestMetaData?.Accept } },
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(ServiceUseCase.RequestMetaData.Accept, serviceResponse),
                    IsBase64Encoded = true
                };

                return response;
            }
            finally
            {
                FunctionTimer.Stop();

                ServiceUseCase?.Logger.LogMessage($"Property GET Handler complete for TransactionID={transactionID},Correlation-Token={ServiceUseCase.RequestMetaData.CorrelationToken}", FunctionTimer.ElapsedMilliseconds, ServiceUseCase.RequestMetaData.PortalCode);
            }
        }

        private ApplicationLoadBalancerResponse GetALBResponse<T>(T serviceResponse, int HttpStatus)
        {
            string responsestr = string.Empty;
            bool gzipIt = false;
            int maxSize = 999900;
            ApplicationLoadBalancerResponse albResponse = new ApplicationLoadBalancerResponse
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase?.RequestMetaData?.Accept } },
                StatusCode = HttpStatus,
                IsBase64Encoded = true
            };
            if (ServiceUseCase?.RequestMetaData?.Accept.EndsWith("json", StringComparison.InvariantCultureIgnoreCase) ?? false)
            {
                responsestr = System.Text.Json.JsonSerializer.Serialize<T>(serviceResponse);
            }
            else if (ServiceUseCase?.RequestMetaData?.Accept.EndsWith("xml", StringComparison.InvariantCultureIgnoreCase) ?? false)
            {
                responsestr = SerializationAssistant.SerializeXml<T>(serviceResponse);
            }

            if (System.Text.ASCIIEncoding.ASCII.GetByteCount(responsestr) >= maxSize)
            {
                gzipIt = true;
            }

            if ("gzip".Equals(ServiceUseCase?.RequestMetaData?.AcceptEncoding, StringComparison.InvariantCultureIgnoreCase) || gzipIt)
            {
                albResponse.Headers.Add("accept-encoding", "gzip");

                albResponse.Body = JODIAssistant.SerializeBodyToB64(ServiceUseCase?.RequestMetaData?.Accept, GZipHelper.Zip(responsestr));
            }
            else
            {
                albResponse.Body = JODIAssistant.SerializeBodyToB64(ServiceUseCase?.RequestMetaData?.Accept, serviceResponse);
            }
            return albResponse;
        }
        #endregion

        #region Mock Handlers


        private async Task<ApplicationLoadBalancerResponse> PostMockHandler(ApplicationLoadBalancerRequest albRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();
            string requestID = string.Empty;
            string contentType = "application/json";

            ApplicationLoadBalancerResponse jodiResponse = null;

            try
            {
                Dictionary<string, VendorConfiguration> serviceConfig = ServiceUseCase.GetVendorConfiguration();

                List<VendorConfiguration> configList = serviceConfig.Values.ToList();

                VendorConfiguration vendorConfig = configList.FirstOrDefault();

                var request = GetRequestfromALBBody<HOAServiceMock>(albRequest);

                var metaData = new Dictionary<string, string>() { { "Content-Type", vendorConfig.RequestContentType } };

                string mockKey = ServiceUseCase.ComputeMockKey(request.MockServiceRequest.Address);

                // Saving as string so we can submit malformed JSON for testing purposes.
                var mockVendorResponse = await ServiceUseCase.SaveToS3<string>(request.MockVendorResponse,
                                                                        GlobalConfiguration.S3_BUCKET,
                                                                        ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, mockKey),
                                                                        "N/A",
                                                                        GlobalConfiguration.KMS_KEY_ID,
                                                                        metaData: metaData);

                // Create JODI response
                jodiResponse = new ApplicationLoadBalancerResponse()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", contentType } },
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceRequest>(contentType, request.MockServiceRequest),
                    IsBase64Encoded = true
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase?.Logger.LogServiceError(ex, "Failure in the PostMockHandler", FunctionTimer.ElapsedMilliseconds);
                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, requestID);
            }
            finally
            {
                FunctionTimer.Stop();
            }

            return jodiResponse;
        }

        #endregion


        #region "Migrate response --delete after  data migration"


        public async Task<ApplicationLoadBalancerResponse> PostHOAResponseHandler(ApplicationLoadBalancerRequest albRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            ApplicationLoadBalancerResponse applicationLoadbalancerResponse = null;
            TransactionRecord<VendorCall> transaction = new TransactionRecord<VendorCall>();

            HOAServiceResponse serviceResponse = null;
            HOAGetResponse hoaGetResponse = null;
            try
            {

                serviceResponse = GetRequestfromALBBody<HOAServiceResponse>(albRequest);
                

                if (serviceResponse == null)
                {
                    serviceResponse = new HOAServiceResponse();
                    Error e = new Error
                    {
                        Code = "EX001",
                        Description = $"unable to Serialize Request"
                    };
                    serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                    serviceResponse.Errors.Add(e);


                    return CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.BadRequest, ServiceUseCase?.RequestMetaData?.ContentType);

                }

                hoaGetResponse = await hoaDataUseCase.MigrateHandler(serviceResponse);

                //create JODI response
                applicationLoadbalancerResponse = new ApplicationLoadBalancerResponse()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase?.RequestMetaData?.Accept } },
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(ServiceUseCase?.RequestMetaData?.Accept, hoaGetResponse?.ServiceResponse),
                    IsBase64Encoded = true
                };
            }
            catch (Exception ex)
            {
                FunctionTimer.Stop();
                ServiceUseCase.Logger.LogServiceError(ex, "Unhandled exception in PostMockHandler", FunctionTimer.ElapsedMilliseconds);

                Error e = new Error
                {
                    Code = "EX003",
                    Description = $"Internal error occured"
                };
                serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                serviceResponse.Errors.Add(e);
                serviceResponse.Status = ServiceStatusCode.Error.ToString();
                applicationLoadbalancerResponse = new ApplicationLoadBalancerResponse()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", "application/json" } },
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(ServiceUseCase?.RequestMetaData?.Accept, serviceResponse),
                    IsBase64Encoded = true
                };
                return applicationLoadbalancerResponse;

            }

            return applicationLoadbalancerResponse;
        }

        #endregion

        private Route FindMethod(List<Route> methods, string httpMethod, string uri)
        {
            Route method = null;

            if (methods != null && methods.Count > 0)
            {

                if (string.IsNullOrEmpty(uri))
                    throw new Exception("Unable to route to correct function as no URI is specified in the request");

                if (string.IsNullOrEmpty(httpMethod))
                    throw new Exception("Unable to route to correct function as no Http Method is specified in the request");

                //Finds methods where http verb equals method verb & path matches regex
                method = methods.Where(x => x.Verb.ToString().ToUpper().Equals(httpMethod.ToUpper()) && Regex.IsMatch(uri, x.Path, RegexOptions.IgnoreCase)).FirstOrDefault();
            }

            return method;
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        var getVerb = "report";
                        var postVerb = "order";
                        var mockVerb = "mock";
                        var healthVerb = "health";
                        var debugVerb = "debug";

                        MethodLookup = new List<Route>()
                        {
                        new Route
                        {
                            InvokeFunction = HealthCheckHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/{1}$", GlobalConfiguration.SERVICE_ZONE_NAME, healthVerb)
                        },
                        new Route
                        {
                            InvokeFunction = GetHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/{1}$", GlobalConfiguration.SERVICE_ZONE_NAME, getVerb)
                        },

                        new Route
                        {
                            InvokeFunction = PingHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/ping", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                            new Route
                        {
                            InvokeFunction = HOAHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/{1}$", GlobalConfiguration.SERVICE_ZONE_NAME, postVerb)
                        },

                            new Route
                        {
                            InvokeFunction = PostMockHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/{1}$", GlobalConfiguration.SERVICE_ZONE_NAME, mockVerb)
                        },

                             new Route
                        {
                            InvokeFunction = DebugHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/{1}$", GlobalConfiguration.SERVICE_ZONE_NAME, debugVerb)
                        },
                        new Route
                        {
                            InvokeFunction = PostHOAResponseHandler,
                            Verb = FAMS.Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/migrate$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                       
                    };
                    }
                }
            }
        }

        private ApplicationLoadBalancerResponse CreateErrorResponse(HOAServiceResponse serviceResponse, string status, int HttpStatuscode, string accept)
        {
            serviceResponse.Status = status;
            return new ApplicationLoadBalancerResponse()
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", accept } },
                StatusCode = HttpStatuscode,
                Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(accept, serviceResponse)
            };

        }

        private ApplicationLoadBalancerResponse CreateJODIErrorResponse(string errorMsg, int statusCode, string contentType, string transactionID)
        {
            return new ApplicationLoadBalancerResponse()
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", contentType } },
                Body = string.Format("{0} TransactionID={1}", errorMsg, transactionID),
                StatusCode = statusCode,
                IsBase64Encoded = false
            };
        }

        private class Route
        {
            public delegate Task<ApplicationLoadBalancerResponse> Function(ApplicationLoadBalancerRequest request, ILambdaContext context);

            public Function InvokeFunction { get; set; }
            public Common.API.Models.Enums.HttpVerb Verb { get; set; }
            public string Path { get; set; }
        }

        #region "helpers"
        static ConcurrentDictionary<string, HttpClient> HttpClients;
        static object HttpClientLock = new object();
        private void InitializeHttpClient()
        {
            if (HttpClients == null)
            {
                lock (HttpClientLock)
                {
                    if (HttpClients == null)
                    {
                        HttpClients = new ConcurrentDictionary<string, HttpClient>();
                    }
                }
            }
        }
        #endregion

    }
}

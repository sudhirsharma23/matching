﻿using FAMS.Common.API.Models.Infrastructure;
using FAMS.HOAService.v1.Models.Service;
using FAMS.HOAService.v1.Models.Vendor;
using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.HOAService.v1.Mappers
{
    public class DataTreeRequestMapper
    {
        public DataTreeHOARequest MapServiceRequestToVendorRequest(HOAServiceRequest request, VendorConfiguration config)
        {
            var dataTreeRequest = new DataTreeHOARequest()
            {
                MISMOVersionID = "2.1",
                REQUESTING_PARTY = new REQUESTING_PARTY()
                {
                    PREFERRED_RESPONSE = new PREFERRED_RESPONSE()
                    {
                        _Format = "XML"
                    }
                },
                RECEIVING_PARTY = new RECEIVING_PARTY()
                {
                },
                REQUEST = new REQUEST()
                {
                    _JobIdentifier = string.Empty,
                    _RequestDateTime = DateTime.Now.ToString(),
                    InternalAccountIdentifier = "0",
                    LoginAccountIdentifier = config.Login,
                    LoginAccountPassword = config.Password,
                    _HVERequestType = "02",
                    REQUESTDATA = new REQUESTDATA()
                    {
                        PROPERTY_INFORMATION_REQUEST = new PROPERTY_INFORMATION_REQUEST()
                        {
                            _ActionType = "Submit",
                            _DTDB_PRODUCT = new _DTDB_PRODUCT()
                            {
                                _HOAReport = "Y"
                            },
                            _PROPERTY_CRITERIA = new _PROPERTY_CRITERIA()
                            {
                                _StreetAddress = request?.Address?.StreetAddress1,
                                _City = request?.Address?.City,
                                _State = request?.Address?.State,
                                _County = string.Empty,
                                _PostalCode = request?.Address?.ZipCode,
                                _LastSalePriceAmount = string.Empty,
                                _LastSaleDate = string.Empty,
                                PARSED_STREET_ADDRESS = new PARSED_STREET_ADDRESS()
                                {
                                    _HouseNumber = string.Empty,
                                    _StreetName = string.Empty,
                                    _ApartmentOrUnit = string.Empty,
                                    _DirectionPrefix = string.Empty,
                                    _DirectionSuffix = string.Empty,
                                    _StreetSuffix = string.Empty,
                                }
                            },
                            _SEARCH_CRITERIA = new _SEARCH_CRITERIA()
                            {
                                _SUBJECT_SEARCH = new _SUBJECT_SEARCH()
                                {
                                    _AssessorsParcelIdentifier = request.Address.APN,
                                    _OwnerFirstName = string.Empty,
                                    _OwnerLastName = string.Empty
                                }

                            }
                        }
                    }
                }
            };

            return dataTreeRequest;
        }

    }
}

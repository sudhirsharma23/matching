﻿using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.HOAService.v1.Models.Service;
using FAMS.HOAService.v1.Models.Vendor;
using FAMS.HOAService.v1.UseCases.Service;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FAMS.HOAService.v1.Mappers
{
    public class DataTreeResponseMapper
    {
        public HOAServiceResponse CreateServiceResponse(DataTreeHOAResponse response, TransactionRecord<VendorCall> Transaction
         , ConcurrentBag<VendorCall> vendorCalls, ServiceUseCase serviceUseCase)
        {
          
            HOAServiceResponse ServiceResponse = new HOAServiceResponse();
            string Status = ServiceStatusCode.NoHit.ToString();
            ServiceResponse.Status = Status;
            ServiceResponse.RequestorID = Transaction?.RequestorID;
            ServiceResponse.TransactionID = Transaction?.TransactionID;
            List<Diagnostic> diagnosticlist = null;
            var property = response?.RESPONSE?.RESPONSE_DATA?.PROPERTY_INFORMATION_RESPONSE?._PROPERTY_INFORMATION?.PROPERTY;

            if (property != null && property?._HOA_INFORMATION?._HOA != null && property?._HOA_INFORMATION?._HOA.Count > 0 
                && !string.IsNullOrWhiteSpace( property?._HOA_INFORMATION?._HOA?.FirstOrDefault()?._Name))
            {
                Status = ServiceStatusCode.Hit.ToString();
                ServiceResponse.Property = new Models.Service.Property()
                {
                    StreetAddress1 = property._StreetAddress,
                    StreetAddress2 = property._StreetAddress2,
                    City = property._City,
                    State = property._State,
                    ZipCode = property._PostalCode,
                    RefID = property._PropertyId,
                    County = property._County,
                    Country = property._Country,
                    CensusTractIdentifier = property.CensusTractIdentifier,
                    APN = property._AssessorsParcelIdentifier,
                    SubdivisionIdentifier = property._SubdivisionIdentifier,
                    UnitNumber = property?._PARSED_STREET_ADDRESS?._ApartmentOrUnit,
                    StreetNumber = string.IsNullOrWhiteSpace(property?._PARSED_STREET_ADDRESS?._StandardizedHouseNumber) ? property?._PARSED_STREET_ADDRESS?._StandardizedHouseNumber
                                                                                                                         : property?._PARSED_STREET_ADDRESS?._HouseNumber,
                    StreetPreDirection = property?._PARSED_STREET_ADDRESS?._DirectionPrefix,
                    StreetName = property?._PARSED_STREET_ADDRESS?._StreetName,
                    StreetSuffix = property?._PARSED_STREET_ADDRESS?._StreetSuffix,
                    StreetPostDirection = property?._PARSED_STREET_ADDRESS?._DirectionSuffix,
                    UnitDesignation = property?._PARSED_STREET_ADDRESS?._SuiteType,
                };

                if (property?._HOA_INFORMATION?._HOA != null && property?._HOA_INFORMATION?._HOA.Count > 0)
                {
                    ServiceResponse.HOAInformation = new List<Models.Service.HOA>();
                    foreach (var hoa in property?._HOA_INFORMATION?._HOA)
                    {
                        Models.Service.HOA hoaData = new Models.Service.HOA();

                        hoaData.AssociationName = hoa._Name;
                        hoaData.HOAType = hoa._Type;
                        hoaData.City = hoa._City;
                        decimal.TryParse(hoa._Amount, out decimal amount);

                        hoaData.Amount = amount;
                        decimal.TryParse(hoa._MinAmount, out decimal minamount);
                        hoaData.MinAmount = minamount;
                        decimal.TryParse(hoa._MaxAmount, out decimal maxamount);
                        hoaData.MaxAmount = maxamount;
                        hoaData.FeeFrequency = hoa._FeeFrequency;
                        hoaData.FeeType = hoa._FeeType;

                        if (hoa?._HOA_CONTACT_INFORMATION != null && hoa?._HOA_CONTACT_INFORMATION.Count > 0)
                        {
                            hoaData.Contacts = new List<Contact>();
                            foreach (var contact in hoa?._HOA_CONTACT_INFORMATION)
                            {
                                Contact contactinfo = new Contact();
                                contactinfo.ContactType = contact._Type;
                                contactinfo.ContactName = contact._ContactName;
                                contactinfo.Address = new Address
                                {
                                    StreetAddress1 = contact._Address,
                                    City = contact._City,
                                    State = contact._State,
                                    ZipCode = contact._Zip,
                                    ZipFour = contact._Plus4
                                };
                                contactinfo.Email = contact._Email;
                                var phones = new List<Phone>();
                                phones.Add(new Phone
                                {
                                    PhoneType = Common.API.Models.Enums.PhoneType.Work,
                                    PhoneNumber = contact._BusinessPhone
                                });
                                phones.Add(new Phone
                                {
                                    PhoneType = Common.API.Models.Enums.PhoneType.Mobile,
                                    PhoneNumber = contact._CellPhone
                                });

                                contactinfo.Phones = phones.ToArray();

                                hoaData.Contacts.Add(contactinfo);
                            }
                        }
                        ServiceResponse.HOAInformation.Add(hoaData);

                    }
                }
            }

            #region "Diagnostics"
            if (serviceUseCase.RequestMetaData.Diagnostics)
            {
                ServiceResponse.Diagnostics = new List<Diagnostic>();
                diagnosticlist = new List<Diagnostic>();
                if (vendorCalls != null && vendorCalls.Count > 0)
                {
                    foreach (var vendorcall in vendorCalls)
                    {
                        Diagnostic diagnostic = new Diagnostic
                        {
                            VendorCode = vendorcall?.Name?.Split(' ')?.First(),
                            VendorCallStatus = vendorcall?.HttpStatus,
                            VendorResponseTime = vendorcall?.Elapsedms,
                            VendorLogin = vendorcall?.Login,
                            VendorURL = vendorcall?.URL,
                            Message = serviceUseCase.Error,
                            DataSource = Transaction?.DataSource
                        };
                        diagnosticlist.Add(diagnostic);
                    }
                }
                else
                {
                    Diagnostic diagnostic = new Diagnostic
                    {
                        Message = serviceUseCase.Error,
                        DataSource = Transaction?.DataSource
                    };
                    diagnosticlist.Add(diagnostic);
                }

            }
            ServiceResponse.Diagnostics = diagnosticlist;
            #endregion

            ServiceResponse.Status = Status;

            return ServiceResponse;
        }
    }
}

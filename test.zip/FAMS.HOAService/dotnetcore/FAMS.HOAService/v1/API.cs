﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.Common.API.Models.Enums;
using FAMS.HOAService.v1.Models.Service;
using FAMS.HOAService.v1.Models.Vendor;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using FAMS.HOAService.v1.UseCases.Service;
using Newtonsoft.Json.Linq;
using FAMS.HOAService.v1.UseCases.Vendor.DataTree;
using FAMS.HOAService.core;
using FAMS.HOAService.v1.UseCases.Vendor;
using FAMS.Common.API.Models.Entities;
using Amazon.Lambda.ApplicationLoadBalancerEvents;
using System.Text.Json;
using Newtonsoft.Json;
using Amazon.SecretsManager.Extensions.Caching;

namespace FAMS.HOAService.v1
{
    public class API
    {
        static ConcurrentDictionary<string, HttpClient> HttpClients;
        static object HttpClientLock = new object();

        static ConcurrentDictionary<string, List<VendorConfiguration>> VendorConfigs;
        static object ConfigLock = new object();

        static List<Method> MethodLookup;
        static object MethodLock = new object();

        const string API_VERSION = "v1";
        TransactionRecord<VendorCall> transaction = new TransactionRecord<VendorCall>();

        #region "Constructors"
        ServiceUseCase ServiceUseCase;
        HOADataUseCase hoaDataUseCase;

        Stopwatch FunctionTimer = new Stopwatch();
        IAmazonS3 S3Client;
        public API()
        {
            ServiceUseCase = new ServiceUseCase();
            S3Client = new AmazonS3Client();
            hoaDataUseCase=  new HOADataUseCase(S3Client, ServiceUseCase);
            InitializeVendorConfigs();
            InitializeHttpClient();
        }

        // Used for testing purposes.
        public API(IAmazonS3 s3Client, IAmazonDynamoDB dbClient, SecretsManagerCache secretsClient)
        {
            ServiceUseCase = new ServiceUseCase(s3Client, dbClient, secretsClient);
            S3Client = s3Client;
            hoaDataUseCase = new HOADataUseCase(S3Client, ServiceUseCase);
            InitializeVendorConfigs();
            InitializeHttpClient();
        }
        #endregion

        #region Private Methods
        private void InitializeHttpClient()
        {
            if (HttpClients == null)
            {
                lock (HttpClientLock)
                {
                    if (HttpClients == null)
                    {
                        HttpClients = new ConcurrentDictionary<string, HttpClient>();
                    }
                }
            }
        }

        private void InitializeVendorConfigs()
        {
            if (VendorConfigs == null)
            {
                lock (ConfigLock)
                {
                    if (VendorConfigs == null)
                    {
                        VendorConfigs = new ConcurrentDictionary<string, List<VendorConfiguration>>();
                    }
                }
            }
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        MethodLookup = new List<Method>()
                        {
                            new Method
                        {
                            InvokeFunction_v2 = GetHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/report$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                            new Method
                        {
                            InvokeFunction_v2 = PostHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/order$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                            new Method
                        {
                            InvokeFunction_v2 = HealthCheckHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/health$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                            new Method
                        {
                            InvokeFunction_v2 = PostMockHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/mock$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                            new Method
                        {
                            InvokeFunction_v2 = PingHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/ping$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                            new Method
                        {
                            InvokeFunction_v2 = DebugHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/debug$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                        new Method
                        {
                            InvokeFunction_v2 = PostHOAResponseHandler,
                            Verb = FAMS.Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/migrate$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        }
                    };



                    }
                }
            }

        }

        #endregion

        #region "Debug Handler

        public async Task<JODIResponse_v2> DebugHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch functionTimer = new Stopwatch();
            functionTimer.Start();

            JODIResponse_v2 response = null;
            string transactionID = string.Empty;
            try
            {
              
                jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);

                if (string.IsNullOrEmpty(transactionID))
                    return CreateJODIErrorResponse("transactionID can't be empty", 400, ServiceUseCase?.RequestMetaData?.Accept, string.Empty);

                var debugResponse = await hoaDataUseCase.HOADebugHandler(transactionID);

                if (debugResponse?.ServiceRequest == null  && debugResponse?.ServiceResponse == null && debugResponse?.TransactionRecord == null
                    && debugResponse?.VendorRequest == null && debugResponse?.VendorResponse == null)
                {
                    
                    return CreateJODIErrorResponse("Not Found", 404, ServiceUseCase?.RequestMetaData?.Accept, string.Empty);
                }

             

                //create JODI response
                return new JODIResponse_v2()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase?.RequestMetaData?.Accept } },
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceDebug>(ServiceUseCase?.RequestMetaData?.Accept, debugResponse),
                    IsBase64Encoded = true
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, $"Failure in the DebugHandler. TransactionID={transactionID}", functionTimer.ElapsedMilliseconds);

                response = CreateJODIErrorResponse("Internal Service Error", 500, ServiceUseCase?.RequestMetaData?.Accept, transactionID);
            }
            finally
            {
                ServiceUseCase.Logger.LogFunctionExecutionTime(functionTimer.ElapsedMilliseconds);
            }

            return response;
        }


        #endregion


        #region Function Handlers
        /// <summary>
        /// Routing handler for the lambda functions.  This is the one method that the lambda will call directly, then based on HTTP Method and URI, this method will invoke the correct function to call.
        /// </summary>
        /// <param name="jodiRequest">Stream of JODIRequest. Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>Stream of JODI response.  The service response is b64 encoded in the body </returns>
        public async Task<Stream> RouteHandler(Stream jodiRequestStream, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            JODIRequest request = null;
            JODIResponse_v2 response = null;
            MemoryStream responseStream = new MemoryStream();
            try
            {
                request = SerializationAssistant.DeserializeJson<JODIRequest>(jodiRequestStream);

                if (request == null)
                    throw new Exception("Unable to deserialize to JODIRequest object.");
               ServiceUseCase.InitializeUseCase(request, context);
                InitializeMethodLookup();

                Method method = JODIAssistant.FindMethod(MethodLookup, request);

                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction_v2(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},TransactionID={3},Supported Methods=GET,POST",
                                               ServiceUseCase?.RequestMetaData?.Path,
                                              string.Join(",", MethodLookup.Select(a => a.Path)),
                                               ServiceUseCase?.RequestMetaData?.HttpMethod, ServiceUseCase?.RequestMetaData?.TransactionID);
                    throw new Exception(errorMsg);
                }

                SerializationAssistant.SerializeJson<JODIResponse_v2>(response, responseStream);
                responseStream.Position = 0;

                return responseStream;
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex,
                                                              string.Format("Failure in the RouteHandler. JODIRequest={0}", JODIAssistant.StreamToJson(jodiRequestStream)),
                                                              FunctionTimer.ElapsedMilliseconds);

                string accept = string.Empty, contentType = string.Empty;
                request?.Params?.Header?.TryGetValue("accept", out accept);
                request?.Params?.Header?.TryGetValue("content-type", out contentType);
                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                HOAServiceResponse serviceResponse = new HOAServiceResponse();
                Error e = new Error
                {
                    Code = "EX003",
                    Description = $"Internal error occured"
                };
                serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                serviceResponse.Errors.Add(e);
                serviceResponse.TransactionID = ServiceUseCase?.RequestMetaData?.TransactionID;

                response = CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.InternalServerError, accept);
                SerializationAssistant.SerializeJson<JODIResponse_v2>(response, responseStream);
                return responseStream;
            }
            finally
            {
                FunctionTimer.Stop();

                //dont want to log to CW for keep warm request

                if (GlobalConfiguration.LOG_JODI)
                {
                    ServiceUseCase.Logger.LogJsonObject(request);
                    ServiceUseCase.Logger.LogJsonObject(response);
                }

                ServiceUseCase.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);


            }
        }

       
        #region "Get Handler"

        private bool IsPersonaValid(Dictionary<string, string> persona, out string msg, params string[] fieldsToValidate)
        {
            msg = null;

            if (persona == null)
            {
                msg = "Persona is required";
                return false;
            }

            foreach (var field in fieldsToValidate)
            {
                if (!persona.ContainsKey(field) || string.IsNullOrWhiteSpace(persona[field]))
                {
                    msg = "Persona must contain " + field;
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// GET - retrieve vendor response by Company ID & Transaction ID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse_v2> GetHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string transactionID = string.Empty;
            HOAServiceResponse serviceResponse = null;
            HOAGetResponse hOAGetResponse = null;

            jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);
            if (!IsPersonaValid(ServiceUseCase.RequestMetaData.Persona, out string msg, "clientID", "globalID") ||
               string.IsNullOrWhiteSpace(transactionID))
            {
                return new JODIResponse_v2()
                {
                    StatusCode = (int)HttpStatusCode.BadRequest,
                    Body = string.IsNullOrWhiteSpace(msg) ? msg : "transactionID is required"
                };
            }
            var response = new JODIResponse_v2()
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase.RequestMetaData?.Accept } },
                IsBase64Encoded = true
            };

            try
            {
                transactionID = transactionID?.ToLower();
                hOAGetResponse = await hoaDataUseCase.GetHandler(transactionID);
                response = GetJODIResponse<HOAServiceResponse>(hOAGetResponse?.ServiceResponse, hOAGetResponse.StatusCode);
               
                return response;

            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, $"Failure in the GetHandler for TransactionID={transactionID}", FunctionTimer.ElapsedMilliseconds);
                Error e = new Error
                {
                    Code = "EX003",
                    Description = $"Internal error occured"
                };
                serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                serviceResponse.Errors.Add(e);
                serviceResponse.Status = ServiceStatusCode.Error.ToString();
                response = new JODIResponse_v2()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase.RequestMetaData?.Accept } },
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(ServiceUseCase.RequestMetaData?.Accept, serviceResponse),
                    IsBase64Encoded = true
                };

                return response;
            }
            finally
            {
                FunctionTimer.Stop();

                ServiceUseCase.Logger.LogMessage(string.Format("HOA GET Handler complete for TransactionID={1},Correlation-Token={0} ", ServiceUseCase.RequestMetaData?.CorrelationToken, transactionID), FunctionTimer.ElapsedMilliseconds, ServiceUseCase.RequestMetaData?.PortalCode);

            }
        }


        private JODIResponse_v2 GetJODIResponse<T>(T serviceResponse, int HttpStatus)
        {
            string responsestr = string.Empty;
            bool gzipIt = false;
            int maxSize = 5999000;
            JODIResponse_v2 jodiResponse = new JODIResponse_v2
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase?.RequestMetaData?.Accept } },
                StatusCode = HttpStatus,
                IsBase64Encoded = true
            };
            if (ServiceUseCase?.RequestMetaData?.Accept.EndsWith("json", StringComparison.InvariantCultureIgnoreCase) ?? false)
            {
                responsestr = System.Text.Json.JsonSerializer.Serialize<T>(serviceResponse);
            }
            else if (ServiceUseCase?.RequestMetaData?.Accept.EndsWith("xml", StringComparison.InvariantCultureIgnoreCase) ?? false)
            {
                responsestr = SerializationAssistant.SerializeXml<T>(serviceResponse);
            }

            if (System.Text.ASCIIEncoding.ASCII.GetByteCount(responsestr) >= maxSize)
            {
                gzipIt = true;
            }

            if ("gzip".Equals(ServiceUseCase?.RequestMetaData?.AcceptEncoding, StringComparison.InvariantCultureIgnoreCase) || gzipIt)
            {
                jodiResponse.Headers.Add("accept-encoding", "gzip");

                jodiResponse.Body = JODIAssistant.SerializeBodyToB64(ServiceUseCase?.RequestMetaData?.Accept, GZipHelper.Zip(responsestr));
            }
            else
            {
                jodiResponse.Body = JODIAssistant.SerializeBodyToB64(ServiceUseCase?.RequestMetaData?.Accept, serviceResponse);
            }
            return jodiResponse;
        }

        private T GetRequestfromJODI<T>(JODIRequest jodiRequest)
        {
            T serviceRequest = default(T); string albRequestbody = string.Empty;
            if ("gzip".Equals(ServiceUseCase?.RequestMetaData?.AcceptEncoding, StringComparison.InvariantCultureIgnoreCase))
            {
                serviceRequest = JODIAssistant.DeserializeB64Body<T>(jodiRequest.BodyType, GZipHelper.Unzip(Convert.FromBase64String(jodiRequest.Body)));
            }
            else
            {
                serviceRequest = JODIAssistant.DeserializeB64Body<T>(jodiRequest.BodyType, jodiRequest.Body);
            }
            return serviceRequest;
        }

        #endregion

        #region "post Handler"
        private JODIResponse_v2 CreateErrorResponse(HOAServiceResponse serviceResponse, string status, int HttpStatuscode, string accept)
        {
            serviceResponse.Status = status;
            return new JODIResponse_v2()
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", accept } },
                StatusCode = HttpStatuscode,
                Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(accept, serviceResponse)
            };

        }
        
       
        private async Task<JODIResponse_v2> PostHandler(JODIRequest jodiRequest, ILambdaContext contextt)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();
            JODIResponse_v2 jodiResponse = null;
            HOAServiceResponse serviceResponse = new HOAServiceResponse();

            try
            {
                HOAServiceRequest request = null;
                try
                {
                    request = GetRequestfromJODI<HOAServiceRequest>(jodiRequest);
                }

                catch (InvalidOperationException ix)
                {
                    Error e = new Error
                    {
                        Code = "EX001",
                        Description = $"unable to Serialize Request"
                    };
                    serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                    serviceResponse.Errors.Add(e);
                    ServiceUseCase?.Logger.LogServiceError(ix, $"error for TransactionID:{ServiceUseCase?.RequestMetaData?.TransactionID}", FunctionTimer.ElapsedMilliseconds);

                    return CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.BadRequest, ServiceUseCase?.RequestMetaData?.Accept);
                }

                catch (Exception ex)
                {
                    Error e = new Error
                    {
                        Code = "EX002",
                        Description = $"Errors in  Request"
                    };
                    serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                    serviceResponse.Errors.Add(e);
                    ServiceUseCase?.Logger.LogServiceError(ex, $"error for TransactionID:{ServiceUseCase?.RequestMetaData?.TransactionID}", FunctionTimer.ElapsedMilliseconds);
                    return CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.BadRequest, ServiceUseCase?.RequestMetaData?.Accept);
                }

               
                serviceResponse = await hoaDataUseCase.HOAHandler(request, transaction);
                jodiResponse = GetJODIResponse<HOAServiceResponse>(serviceResponse, transaction.HttpStatus);
            }
            catch (Exception ex)
            {
                ServiceUseCase?.Logger.LogServiceError(ex, $"Failure in the PostHandler for TransactionID={transaction.TransactionID},Correlation-Token={ServiceUseCase?.RequestMetaData?.CorrelationToken}", FunctionTimer.ElapsedMilliseconds);
            }
            finally
            {
                FunctionTimer.Stop();
            }
            return jodiResponse;

        }
        #endregion


        #region "Ping and Health Check Handler"
        /// <summary>
        /// A simple health check(check S3/Dynamo are active + make echotest call to vendor)
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the health check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse_v2> HealthCheckHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            string requestID = string.Empty;
            string contentType = "application/json";
            HealthCheck health = new HealthCheck(context.FunctionName);
            try
            {
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);

                HealthCheck healthCheck = await ServiceUseCase.RunHealthCheck(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.S3_BUCKET, GlobalConfiguration.DYNAMO_TABLE);
              
                var hoaHealth = await hoaDataUseCase.RunHealthCheck();
                health.Components.TryAdd("HOA", hoaHealth);
                if (hoaHealth.Status == ComponentStatus.Red)
                    health.ServiceStatus = ComponentStatus.Red;

                return new JODIResponse_v2()
                {
                    StatusCode = health.ServiceStatus == ComponentStatus.Red ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK,
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", "application/json" } },
                    Body = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, health),
                    IsBase64Encoded = true
                };

            }
            catch (Exception ex)
            {

                jodiRequest?.Context?.TryGetValue("request-id", out requestID);

                ServiceUseCase.Logger.LogServiceError(ex, $"Health check failed for requestid:{requestID}", FunctionTimer.ElapsedMilliseconds);
                return new JODIResponse_v2()
                {
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", "application/json" } },
                    Body = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, health),
                    IsBase64Encoded = true
                };
            }
        }

        /// <summary>
        /// A simple ping check
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the ping check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>An empty JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse_v2> PingHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            return JODIAssistant.SetPingTestResponse_v2();
        }

        #endregion

        #region "Post Mock Handler"

        /// <summary>
        /// Creates mock vendor responses and returns back the service request to get that mock response.
        /// </summary>
        /// <param name="request">A service mock object containing the service request + mocked vendor response</param>
        /// <param name="context"></param>
        /// <returns>The service request that was passed in. This will be used as the body of the POST request to the service.</returns>
        private async Task<JODIResponse_v2> PostMockHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string requestID = string.Empty;
            jodiRequest?.Context?.TryGetValue("request-id", out requestID);
            string contentType = "application/json";
            JODIResponse_v2 jodiResponse = null;
            try
            {
                Dictionary<string, VendorConfiguration> serviceConfig = ServiceUseCase.GetVendorConfiguration();

                List<VendorConfiguration> configList = serviceConfig.Values.ToList();

                VendorConfiguration vendorConfig = configList.FirstOrDefault();

                var request = GetRequestfromJODI<HOAServiceMock>(jodiRequest);

                var metaData = new Dictionary<string, string>() { { "Content-Type", vendorConfig.RequestContentType } };

                string mockKey = ServiceUseCase.ComputeMockKey(request.MockServiceRequest.Address);

                // Saving as string so we can submit malformed JSON for testing purposes.
                var mockVendorResponse = await ServiceUseCase.SaveToS3<string>(request.MockVendorResponse,
                                                                        GlobalConfiguration.S3_BUCKET,
                                                                        ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, mockKey),
                                                                        "N/A",
                                                                        GlobalConfiguration.KMS_KEY_ID,
                                                                        metaData: metaData);

                // Create JODI response
                jodiResponse = new JODIResponse_v2()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", contentType } },
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceRequest>(jodiRequest.BodyType, request.MockServiceRequest),
                    IsBase64Encoded = true
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, "Failure in the PostMockHandler", FunctionTimer.ElapsedMilliseconds);
                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, requestID);
            }
            finally
            {
                FunctionTimer.Stop();
            }
            return jodiResponse;
        }

        #endregion


        #region "Migrate response --delete after  data migration"


        public async Task<JODIResponse_v2> PostHOAResponseHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            JODIResponse_v2 jodiResponse = null;
            TransactionRecord<VendorCall> transaction = new TransactionRecord<VendorCall>();
            HOAServiceResponse serviceResponse = null;
            HOAGetResponse hoaGetResponse = null;

            try
            {
                serviceResponse = GetRequestfromJODI<HOAServiceResponse>(jodiRequest);
               
                if (serviceResponse == null)
                {
                    serviceResponse = new HOAServiceResponse();
                    Error e = new Error
                    {
                        Code = "EX001",
                        Description = $"unable to Serialize Request"
                    };
                    serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                    serviceResponse.Errors.Add(e);

                    return CreateErrorResponse(serviceResponse, ServiceStatusCode.Error.ToString(), (int)HttpStatusCode.BadRequest, ServiceUseCase?.RequestMetaData?.ContentType);

                }

                hoaGetResponse = await hoaDataUseCase.MigrateHandler(serviceResponse);

                //create JODI response
                jodiResponse = new JODIResponse_v2()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", ServiceUseCase?.RequestMetaData?.ContentType } },
                    StatusCode = (int)HttpStatusCode.OK,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(ServiceUseCase?.RequestMetaData?.ContentType, hoaGetResponse?.ServiceResponse),
                    IsBase64Encoded = true
                };
            }
            catch (Exception ex)
            {
                FunctionTimer.Stop();
                ServiceUseCase.Logger.LogServiceError(ex, "Unhandled exception in PostMockHandler", FunctionTimer.ElapsedMilliseconds);

                Error e = new Error
                {
                    Code = "EX003",
                    Description = $"Internal error occured"
                };
                serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                serviceResponse.Errors.Add(e);
                serviceResponse.Status = ServiceStatusCode.Error.ToString();
                jodiResponse = new JODIResponse_v2()
                {
                    Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", "application/json" } },
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Body = JODIAssistant.SerializeBodyToB64<HOAServiceResponse>(ServiceUseCase?.RequestMetaData?.ContentType, serviceResponse),
                    IsBase64Encoded = true
                };
                return jodiResponse;


            }

            return jodiResponse;
        }

        #endregion

        #endregion

        private JODIResponse_v2 CreateJODIErrorResponse(string errorMsg, int statusCode, string contentType, string transactionID)
        {
            return new JODIResponse_v2()
            {
                Headers = new Common.API.Models.SerializableDictionary<string, string> { { "Content-Type", contentType } },
                Body = string.Format("{0} TransactionID={1}", errorMsg, transactionID),
                StatusCode = statusCode,
                IsBase64Encoded = false
            };
        }
    }
}

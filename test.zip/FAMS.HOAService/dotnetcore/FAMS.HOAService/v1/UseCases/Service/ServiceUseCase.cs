﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.ApplicationLoadBalancerEvents;
using Amazon.Lambda.Core;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SecretsManager.Extensions.Caching;

using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.HOAService.core;
using FAMS.HOAService.v1.Models.Service;
using FAMS.HOAService.v1.UseCases.Vendor;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;


namespace FAMS.HOAService.v1.UseCases.Service
{
    public class ServiceUseCase
    {
        #region "Properties"
        private IAmazonS3 _s3Client;
        private IAmazonDynamoDB _dbClient;
        private IDynamoDBContext _dbContext;
        private SecretsManagerCache _secretsClient;

        public LoggingAssistant Logger { get; set; }
        public RequestMetaData RequestMetaData;
        public string Error { get; set; }
        #endregion

        public ServiceUseCase()
        {
            _s3Client = new AmazonS3Client();
            _dbClient = new AmazonDynamoDBClient();
            _dbContext = new DynamoDBContext(_dbClient);
            _secretsClient = new SecretsManagerCache();

        }

        public ServiceUseCase(IAmazonS3 s3Client, IAmazonDynamoDB dynamoClient, SecretsManagerCache secretsClient)
        {
            _s3Client = s3Client;
            _dbClient = dynamoClient;
            _dbContext = new DynamoDBContext(_dbClient);
            _secretsClient = secretsClient;

        }


        //public void InitializeUseCase(APIGatewayProxyRequest request, ILambdaContext context)
        //{
        //    RequestMetaData = new RequestMetaData(request);
        //    Logger = new LoggingAssistant(context.FunctionName, "FAMS.HOAService", RequestMetaData.TransactionID, RequestMetaData.Persona, RequestMetaData.CorrelationToken);
        //    Error = null;
        //}

        public void InitializeUseCase(ApplicationLoadBalancerRequest request, ILambdaContext context)
        {
            RequestMetaData = new RequestMetaData(request);
            Logger = new LoggingAssistant(context.FunctionName, "FAMS.HOAService", RequestMetaData.TransactionID, RequestMetaData.Persona, RequestMetaData.CorrelationToken);
            Error = null;
        }

        public void InitializeUseCase(JODIRequest request, ILambdaContext context)
        {
            RequestMetaData = new RequestMetaData(request);
            Logger = new LoggingAssistant(context.FunctionName, "FAMS.HOAService", RequestMetaData.TransactionID, RequestMetaData.Persona, RequestMetaData.CorrelationToken);
            Error = null;
        }

        public List<VendorName> GetVendorNames()
        {
            List<VendorName> vendorNames = new List<VendorName>();
            vendorNames.Add(VendorName.DataTree_HOAService);
            vendorNames.Add(VendorName.DataTreeDR_HOAService);
            return vendorNames;
        }

        public string BuildS3Key(params string[] components)
        {
            if (components == null)
                throw new ArgumentException("Invalid values provided", "components");

            var builder = new StringBuilder();
            for (int i = 0; i < components.Length; i++)
            {
                var part = components[i];
                builder.Append(part);

                if (i < (components.Length - 1))
                    builder.Append("/");
            }

            return builder.ToString();
        }

        public string GetAppPlan(JODIRequest jodiRequest)
        {
            string appPlan = string.Empty;
            string applicationPlan = string.Empty;

            if (jodiRequest.Context != null && jodiRequest.Context.TryGetValue("application-plan", out applicationPlan))
                appPlan = applicationPlan;
            else if (jodiRequest.Params != null && jodiRequest.Params.Header.TryGetValue("application-plan", out applicationPlan))
                appPlan = applicationPlan;

            return applicationPlan;
        }



        public bool IsMockRequest(HOAServiceRequest request, string applicationPlan)
        {
            bool ismock = false;
            if (!string.IsNullOrEmpty(applicationPlan) && applicationPlan.ToLower().StartsWith("mock"))
                ismock = true;
            else if (!string.IsNullOrWhiteSpace(request.Address?.State) && request.Address.State.StartsWith("z", StringComparison.OrdinalIgnoreCase))
                ismock = true;
            return ismock;

        }

        public bool ValidateGETCall(ConcurrentDictionary<string, string> metaData, string globalID)
        {
            bool isValid = false;

            if (!string.IsNullOrWhiteSpace(GlobalConfiguration.GATEWAY_NAME) && GlobalConfiguration.GATEWAY_NAME.Equals("private", StringComparison.OrdinalIgnoreCase))
            {
                isValid = true;
            }
            else
            {
                if (metaData["x-amz-meta-globalid"].Equals(globalID, StringComparison.OrdinalIgnoreCase))
                {
                    isValid = true;
                }
            }

            return isValid;
        }


        public async Task<PutObjectResponse> SaveToS3<T>(T document, string bucket, string key, string transactionID, string kmsKeyId, int cacheDays = 0, Dictionary<string, string> metaData = null, LifeSpan lifeSpan = LifeSpan.SevenYears)
        {
            PutObjectResponse response = null;

            try
            {
                Stopwatch sw = new Stopwatch();
                sw.Start();
                response = await AWSAssistant.SaveToS3<T>(_s3Client, document, bucket, key, kmsKeyId, cacheDays, metaData, lifeSpan);
                var req_id = response.ResponseMetadata.RequestId;
               
                sw.Stop();
                Logger.LogMessage($"s3-put bucket={bucket}, key={key}, s3reqId={req_id}, transactionID={transactionID}", sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex, $"Failure saving to S3 bucket={bucket}, key={key},transactionID={transactionID}", bucket, key);
                throw ex;
            }

            return response;
        }

        public async Task<GetObjectResponse> GetS3Object(string bucket, string key)
        {

            GetObjectResponse getResponse = null;

            try
            {
                Stopwatch sw = new Stopwatch();
                sw.Start();
                getResponse = await _s3Client.GetObjectAsync(new GetObjectRequest
                {
                    BucketName = bucket,
                    Key = key
                });
                var req_id = getResponse.ResponseMetadata.RequestId;
                sw.Stop();
                Logger.LogMessage($"s3-get bucket={bucket}, s3reqId={req_id}, key={key}", sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex, "error in GET s3 Object", bucket, key);
            }
            return getResponse;
        }

        public async Task<T> SearchS3ByKey<T>(string bucket, string key, string transactionID, bool log404Error = false, int? cacheLimit = null)
        {
            T document = default(T);

            try
            {
                Stopwatch sw = new Stopwatch();
                sw.Start();
                document = await SearchS3ByKey<T>(_s3Client, bucket, key, log404Error, cacheLimit);
                sw.Stop();
                Logger.LogMessage($"s3-search bucket={bucket}, key={key}", sw.ElapsedMilliseconds);
            }
            catch (AmazonS3Exception ex)
            {
                //Some cases 404 is OK like when we are just searching for a key
                if (log404Error || ex.StatusCode != HttpStatusCode.NotFound)
                {
                    Logger.LogS3Error(ex,
                                   "Failure searching S3",
                                   bucket,
                                   key);
                }
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex,
                            "Failure searching S3",
                            bucket,
                            key);
            }

            return document;
        }
        #region " AWS Search S3ByKey
        public async Task<T> SearchS3ByKey<T>(IAmazonS3 S3Client, string bucket, string key, bool log404Error = false, int? cacheLimit = null)
        {
            return await SearchS3ByKeyFilterByMetaData<T>(S3Client, bucket, key, null, log404Error, cacheLimit);
        }

        public async Task<T> SearchS3ByKeyFilterByMetaData<T>(IAmazonS3 S3Client, string bucket, string key, Dictionary<string, string> metaData, bool log404Error = false, int? cacheLimit = null)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            string req_id = string.Empty;
            T document = default(T);

            GetObjectResponse getResponse = null;

            try
            {
                getResponse = await S3Client.GetObjectAsync(new GetObjectRequest
                {
                    BucketName = bucket,
                    Key = key
                });
                req_id = getResponse.ResponseMetadata.RequestId;
            }
            catch (AmazonS3Exception ex)
            {
                if (!log404Error && ex.StatusCode == HttpStatusCode.NotFound)
                    return document;

                throw;
            }

            //check cache. if falls out of a cache range, then return null document
            if (cacheLimit != null)
            {
                int cl = (int)cacheLimit;
                if (getResponse.LastModified.CompareTo(DateTime.Now.AddDays(-cl)) < 0)
                {
                    return document;
                }
            }

            if (metaData != null)
            {
                //check metadata. if not same, then return null document
                foreach (var kvp in metaData)
                {
                    if (!getResponse.Metadata[kvp.Key].Equals(metaData[kvp.Key], StringComparison.OrdinalIgnoreCase))
                    {
                        return document;
                    }
                }
            }


            using (StreamReader sr = new StreamReader(getResponse.ResponseStream))
            {
                string type = getResponse?.Headers?.ContentType ?? string.Empty;

                if (key.EndsWith("json") || type.EndsWith("json"))
                {
                    document = SerializationAssistant.DeserializeJson<T>(sr);
                }
                else if (key.EndsWith("xml") || type.EndsWith("xml"))
                {
                    document = SerializationAssistant.DeserializeXml<T>(sr);
                }
                else if (typeof(T) == typeof(string))
                {
                    document = (T)(object)await sr.ReadToEndAsync();
                }
                else
                {
                    throw new Exception(string.Format("Unable to deserialize document to object as no file extension is specified. Bucket={0},Key={1}", bucket, key));
                }
            }
            sw.Stop();
            Logger.LogMessage($"s3-search bucket={bucket}, s3reqId={req_id}, key={key}", sw.ElapsedMilliseconds);
            return document;
        }

        #endregion

        public async Task SaveDynamoDBTransaction<T>(string table, T trans, string hashKey)
        {
            try
            {
                Stopwatch sw = new Stopwatch();
                sw.Start();
                 await AWSAssistant.SaveToDynamoDB<T>(_dbContext, table, trans, hashKey);
                sw.Stop();
                Logger.LogMessage($"dyndb-put table={table}, key={hashKey}", sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                Logger.LogDynamoError(ex, "Failure saving transaction to DynamoDB", hashKey, table);
                Logger.LogJsonObject<T>(trans);
            }

        }

        public async Task<T> GetDynamoDBTransaction<T>(string table, string hashKey)
        {
            T transaction = default(T);

            try
            {
                Stopwatch sw = new Stopwatch();
                sw.Start();
                transaction = await AWSAssistant.GetFromDynamoDB<T>(_dbContext, table, hashKey);
                sw.Stop();
                Logger.LogMessage($"dyndb-get table={table}, key={hashKey}", sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                Logger.LogDynamoError(ex, "Failure retrieving transaction from DynamoDB", hashKey, table);
            }

            return transaction;
        }

        public async Task<DescribeTableResponse> GetDynamoDBTableInfo(string table)
        {
            DescribeTableResponse response = null;

            try
            {
                response = await _dbClient.DescribeTableAsync(table);
            }
            catch (Exception ex)
            {
                Logger.LogDynamoError(ex, "Failure getting table info from DynamoDB", table);
            }

            return response;
        }

        public T GetServiceRequestFromJODI<T>(JODIRequest jodiRequest, Stopwatch functionTimer) where T : class
        {
            T request = null;

            try
            {
                request = JODIAssistant.DeserializeB64Body<T>(jodiRequest.BodyType, jodiRequest.Body);
            }
            catch (Exception ex)
            {
                string requestID = string.Empty;
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                Logger.LogServiceError(ex, string.Format("Failure to deserialize b64 body. Body={0}", jodiRequest.Body), functionTimer.ElapsedMilliseconds);

            }

            return request;
        }

        public async Task<T> GetMockedResponseFromS3<T>(string bucket, string key, string transactionID, string contentType)
        {
            T cachedResponse = default(T);

            try
            {
                var s3Response = await AWSAssistant.SearchS3ByKey<string>(_s3Client, bucket, key);

                if ("application/json".Equals(contentType, StringComparison.OrdinalIgnoreCase))
                {
                    cachedResponse = SerializationAssistant.DeserializeJson<T>(s3Response);
                }
                else
                {
                    cachedResponse = SerializationAssistant.DeserializeXml<T>(s3Response);
                }
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex, "Failure retrieving mocked vendor response from S3", bucket, key);
            }

            return cachedResponse;
        }

        public string ComputeCacheKey(Address request)
        {
            if (request == null)
                return null;

            byte[] hashValue = null;
            string key = string.Format("{0}", JsonConvert.SerializeObject(request).Replace("\"\"", "null"));
            key = new string(key.ToLower().ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());  // Lowercase + remove whitespace.
            UTF8Encoding enc = new UTF8Encoding();

            using (var sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(enc.GetBytes(key));
            }

            return BitConverter.ToString(hashValue).Replace("-", "");
        }

        public string ComputeMockKey(Address request)
        {
            return ComputeCacheKey(request);
        }


        public async Task<HealthCheck> RunHealthCheck(string service, string bucket, string table)
        {
            HealthCheck healthCheck = new HealthCheck(service);
            await healthCheck.VerifyS3AndDynamo(_s3Client, bucket, _dbClient, table);
            return healthCheck;
        }

        private async Task<string> GetVendorConfigFromSecrets(string vendorName)
        {
            string vendorInfo = null;
            string path = string.Empty;
            StringBuilder sb = new StringBuilder();

            if (vendorName.Contains("datatree", StringComparison.InvariantCultureIgnoreCase))
            {
                sb.Append("datatree/");
            }


            if (RequestMetaData.ConfigOverride && !string.IsNullOrWhiteSpace(RequestMetaData.CredsID))
            {
                sb.Append($"{RequestMetaData.GlobalID}/{RequestMetaData.CredsID}");
            }
            else
            {
                sb.Append($"{RequestMetaData.PortalCode}/default");
            }

            path = sb.ToString();


            try
            {
                vendorInfo = await _secretsClient.GetSecretString(path);
            }
            catch (Exception e)
            {
                Error = $"Unable to Retrieve Vendor Credentials for Vendorname = {vendorName}";
                Logger.LogServiceError(e, $"Unable to retrieve secrets for Vendorname={vendorName},path={path},TransactionID={RequestMetaData?.TransactionID},Correlation-Token={RequestMetaData?.CorrelationToken}", 0, RequestMetaData?.PortalCode);
            }
            return vendorInfo;
        }

        public async Task GetVendorCredentials(VendorConfiguration config)
        {
            var vendorCredentials = await GetVendorConfigFromSecrets(config.VendorCode);

            JObject envConfig = null;
            if (!string.IsNullOrWhiteSpace(vendorCredentials))
            {
                envConfig = JObject.Parse(vendorCredentials);
            }

            if (RequestMetaData.ConfigOverride && string.IsNullOrWhiteSpace(RequestMetaData?.CredsID))
            {
                config.Login = RequestMetaData?.VendorUN;
                config.Password = RequestMetaData?.VendorPWD;
                Error = string.Empty;
            }
            else if (envConfig != null)
            {
                config.Login = envConfig["Login"]?.ToString();
                config.Password = envConfig["Password"]?.ToString();
            }

        }
        public Dictionary<string, VendorConfiguration> GetVendorConfiguration()
        {
            var environment = GlobalConfiguration.Environment;
            string directoryname = string.Format("{0}v1/Configs", AppDomain.CurrentDomain.BaseDirectory);
            string filename = @"default.json";
            string file = string.Empty;

            file = Path.Combine(directoryname, filename);
            string resp = string.Empty;
            using (StreamReader sr = File.OpenText(file))
            {
                resp = sr.ReadToEnd();
            }

            var portalConfig = JObject.Parse(resp);
            var defaultConfig = portalConfig["default"] as JObject;

            if (portalConfig[GlobalConfiguration.Environment] is JObject envConfig)
            {
                defaultConfig.Merge(envConfig, new JsonMergeSettings()
                {
                    MergeArrayHandling = MergeArrayHandling.Merge,
                    MergeNullValueHandling = MergeNullValueHandling.Merge
                });
            }
            else
            {
                throw new Exception(string.Format("Unable to find vendor configuration overrides. Environment: {0}, ", environment));
            }
            Dictionary<string, VendorConfiguration> config = defaultConfig.ToObject<Dictionary<string, VendorConfiguration>>();
            return config;

        }



        public List<Error> BuildValidationErrorResponse(HOAServiceRequest request, TransactionRecord<VendorCall> transaction)
        {
            List<Error> errorlist = new List<Error>();
            if (string.IsNullOrWhiteSpace(request?.RequestorID))
            {
                errorlist.Add(new Error
                {
                    Code = "BR001",
                    Description = "RequestorID is a required field."
                });
            }
            if (string.IsNullOrWhiteSpace(transaction.ClientID))
            {
                errorlist.Add(new Error
                {
                    Code = "BR002",
                    Description = "ClientID is a required field."
                });
            }
            if (string.IsNullOrWhiteSpace(transaction.PortalCode))
            {
                errorlist.Add(new Error
                {
                    Code = "BR003",
                    Description = "PortalCode is a required field."
                });
            }
            if (string.IsNullOrWhiteSpace(transaction.GlobalID))
            {
                errorlist.Add(new Error
                {
                    Code = "BR004",
                    Description = "GlobalID is a required field."
                });
            }

            if (string.IsNullOrWhiteSpace(request?.Address?.StreetAddress1) || request?.Address?.StreetAddress1.Length < 4)
            {
                errorlist.Add(new Error
                {
                    Code = "BR005",
                    Description = "Street Address 1 must have at least 4 characters"
                });
            }

            if (string.IsNullOrWhiteSpace(request?.Address?.City) && string.IsNullOrWhiteSpace(request?.Address?.State) &&  string.IsNullOrWhiteSpace(request?.Address?.ZipCode))
            {
                errorlist.Add(new Error
                {
                    Code = "BR006",
                    Description = "City and State or Zipcode is required"
                });
            }
            else
            {
                if (string.IsNullOrWhiteSpace(request?.Address?.City) || request.Address.City.Length < 2)
                {
                    errorlist.Add(new Error
                    {
                        Code = "BR007",
                        Description = "City must have at least 2 characters"
                    });
                }
                if (string.IsNullOrWhiteSpace(request?.Address?.State) || request.Address.State.Length < 2)
                {
                    errorlist.Add(new Error
                    {
                        Code = "BR008",
                        Description = "State must be 2 characters"
                    });
                }
            }

            return errorlist;
        }


    }
}

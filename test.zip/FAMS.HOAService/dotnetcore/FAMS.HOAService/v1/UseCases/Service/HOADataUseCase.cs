﻿using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.HOAService.core;
using FAMS.HOAService.v1.Models.Service;
using FAMS.HOAService.v1.Models.Vendor;
using FAMS.HOAService.v1.UseCases.Vendor;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace FAMS.HOAService.v1.UseCases.Service
{
    public class HOADataUseCase
    {
        const string API_VERSION = "v1";

        ServiceUseCase ServiceUseCase;
        IAmazonS3 S3Client;
        ConcurrentBag<Task> awsTasks;
        public HOADataUseCase(IAmazonS3 s3Client, ServiceUseCase serviceUseCase)
        {
            S3Client = s3Client;
            ServiceUseCase = serviceUseCase;

        }
        private async Task<DataTreeHOAResponse> GetandValidateCache(HOAServiceRequest request,string CacheKey, int cacheLimit)
        {
            DataTreeHOAResponse serviceResponse = null;
            ConcurrentDictionary<string, string> metaData = new ConcurrentDictionary<string, string>();

            string Cachedresponsekey = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, CacheKey);
            var cacheResponse = await ServiceUseCase.GetS3Object(GlobalConfiguration.S3_BUCKET, Cachedresponsekey);
            
            if (cacheResponse != null)
            {
                foreach (var meta in cacheResponse.Metadata.Keys)
                {
                    metaData.GetOrAdd(meta, cacheResponse.Metadata[meta]);
                }

                if (cacheResponse.LastModified.CompareTo(DateTime.Now.AddDays(-cacheLimit)) > 0)
                {
                    using (StreamReader sr = new StreamReader(cacheResponse.ResponseStream))
                    {
                        string type = cacheResponse?.Headers?.ContentType ?? string.Empty;

                        if (type.EndsWith("json"))
                        {
                            serviceResponse = SerializationAssistant.DeserializeJson<DataTreeHOAResponse>(sr);
                        }
                        else if (type.EndsWith("xml"))
                        {
                            serviceResponse = SerializationAssistant.DeserializeXml<DataTreeHOAResponse>(sr);
                        }

                    }
                }

            }
            return serviceResponse;
        }

        public async Task<HOAServiceResponse> HOAHandler(HOAServiceRequest request, TransactionRecord<VendorCall> transaction)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();
            ConcurrentBag<VendorCall> vendorCalls = new ConcurrentBag<VendorCall>();
            awsTasks = new ConcurrentBag<Task>();

            DataTreeHOAResponse hoaResponse = null;
            HOAServiceResponse serviceResponse = new HOAServiceResponse();
            Dictionary<string, string> metaData = null;
            long buildcanonicalfromvendor = 0;
            Stopwatch sw = new Stopwatch();
            try
            {
                transaction.TransactionID = ServiceUseCase?.RequestMetaData?.TransactionID;
                transaction.AppPlan = ServiceUseCase?.RequestMetaData?.ApplicationPlan;
                transaction.RequestorID = request?.RequestorID;
                transaction.ClientID = ServiceUseCase?.RequestMetaData?.ClientID;
                transaction.GlobalID = ServiceUseCase?.RequestMetaData?.GlobalID;
                transaction.CompanyName = ServiceUseCase?.RequestMetaData?.CompanyName;
                transaction.PortalCode = ServiceUseCase?.RequestMetaData?.PortalCode;
                transaction.ServiceName = GlobalConfiguration.SERVICE_ZONE_NAME;
                transaction.BucketName = GlobalConfiguration.S3_BUCKET;
                serviceResponse.RequestorID = request?.RequestorID;

                metaData = new Dictionary<string, string>() { { "x-amz-meta-globalid", ServiceUseCase?.RequestMetaData?.GlobalID },
                                                                  { "Content-Type", ServiceUseCase?.RequestMetaData?.Accept },
                                                                  {"x-amz-meta-apiversion" ,API_VERSION}
                                                                };


                //Save Request always

                transaction.RequestS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.SERVICE_REQUEST_FOLDER, API_VERSION, transaction.TransactionID);
                transaction.ResponseS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION, transaction.TransactionID);

                if (ServiceUseCase.RequestMetaData.persist && "true".Equals(GlobalConfiguration.SAVE_VENDOR_REQUEST, StringComparison.InvariantCultureIgnoreCase))
                {
                    awsTasks.Add(ServiceUseCase.SaveToS3<HOAServiceRequest>(request, GlobalConfiguration.S3_BUCKET, transaction.RequestS3Key, transaction.TransactionID, GlobalConfiguration.KMS_KEY_ID, 0, metaData, LifeSpan.OneHundredEightyDays));
                }
                List<Error> validationErrors = ServiceUseCase.BuildValidationErrorResponse(request, transaction);
                if (validationErrors != null && validationErrors.Count > 0)
                {
                    serviceResponse = new HOAServiceResponse();
                    serviceResponse.Errors = validationErrors;
                    ServiceUseCase?.Logger.LogServiceError(new Exception(), $"Request failed validation.for TransactionID={transaction?.TransactionID},Correlation-Token={ServiceUseCase?.RequestMetaData?.CorrelationToken}", FunctionTimer.ElapsedMilliseconds);
                    return serviceResponse;
                }

                Dictionary<string, VendorConfiguration> serviceConfig = ServiceUseCase.GetVendorConfiguration();

                List<VendorConfiguration> configList = serviceConfig.Values.ToList();

                VendorConfiguration vendorConfig = configList.FirstOrDefault();

                var vendorUseCase = VendorUseCaseFactory.CreateVendorUseCase(S3Client, ServiceUseCase);

                if (ServiceUseCase.IsMockRequest(request, ServiceUseCase?.RequestMetaData?.ApplicationPlan))
                {

                    transaction.DataSource = DataSource.Mock.ToString();
                    hoaResponse = await ServiceUseCase.GetMockedResponseFromS3<DataTreeHOAResponse>(GlobalConfiguration.S3_BUCKET
                        , ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, ServiceUseCase.ComputeMockKey(request.Address))
                        , transaction.TransactionID, vendorConfig.RequestContentType);

                    // Check for mock by mock key.
                    if (hoaResponse == null)
                    {
                        FunctionTimer.Stop();
                        transaction.HttpStatus = (int)HttpStatusCode.OK;
                        transaction.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                        serviceResponse = vendorUseCase.ReturnNoHit(transaction.TransactionID, transaction.RequestorID) as HOAServiceResponse;

                        return serviceResponse;
                    }

                    // Build service response if mock is found.
                    serviceResponse = vendorUseCase.BuildCanonicalResponse(hoaResponse, transaction, vendorCalls, ServiceUseCase) as HOAServiceResponse;

                }
                else
                {
                    transaction.CacheKey = ServiceUseCase.ComputeCacheKey(request.Address);
                    if (ServiceUseCase.RequestMetaData.CacheLookup)
                    {
                        var cacheLimit = GetCachePeriod(vendorConfig);
                        hoaResponse = await GetandValidateCache(request, transaction.CacheKey, cacheLimit);
                    }
                    if (hoaResponse == null) // No cache.
                    {
                        transaction.DataSource = DataSource.Vendor.ToString();

                        hoaResponse = await vendorUseCase.FetchServiceResponseAsync(request, configList, transaction, vendorCalls, ServiceUseCase, awsTasks, false) as DataTreeHOAResponse;
                        string VendorRequestKey = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.VENDOR_REQUEST_FOLDER, API_VERSION, transaction?.CacheKey);
                        string VendorResponseKey = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, transaction?.CacheKey);
                        vendorCalls.FirstOrDefault().RequestS3Key = VendorRequestKey;
                        vendorCalls.FirstOrDefault().ResponseS3Key = VendorResponseKey;

                        if (hoaResponse != null)
                        {
                            
                            if (ServiceUseCase.RequestMetaData.persist)
                            {
                                awsTasks.Add(ServiceUseCase.SaveToS3<DataTreeHOAResponse>(hoaResponse, GlobalConfiguration.S3_BUCKET, VendorResponseKey
                                   , transaction.TransactionID, GlobalConfiguration.KMS_KEY_ID, vendorConfig.CachePeriodDays, metaData, LifeSpan.OneHundredEightyDays));
                            }
                        }
                    }
                    else // Found cache.
                    {
                        transaction.DataSource = DataSource.Cache.ToString();

                    }
                    if (hoaResponse != null)
                    {
                        sw.Restart();
                        serviceResponse = vendorUseCase.BuildCanonicalResponse(hoaResponse, transaction, vendorCalls, ServiceUseCase);
                        buildcanonicalfromvendor = sw.ElapsedMilliseconds;
                        sw.Stop();
                    }

                }
                ServiceUseCase?.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                transaction.HttpStatus = (int)HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                transaction.HttpStatus = (int)HttpStatusCode.InternalServerError;
                transaction.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                transaction.DateTimeUTC = DateTime.UtcNow;
                transaction.VendorCalls = vendorCalls.ToList<VendorCall>();

                Error e = new Error
                {
                    Code = "EX003",
                    Description = $"Internal error occured"
                };
                serviceResponse.Errors = serviceResponse.Errors == null ? new List<Error>() : serviceResponse.Errors;
                serviceResponse.Errors.Add(e);
                serviceResponse.Status = ServiceStatusCode.Error.ToString();
                ServiceUseCase?.Logger.LogServiceError(ex, $"Failure in the PostHandler for TransactionID={transaction.TransactionID},Correlation-Token={ServiceUseCase?.RequestMetaData?.CorrelationToken}", FunctionTimer.ElapsedMilliseconds);

            }
            finally
            {
                ServiceUseCase?.Logger.LogMessage($"PropertyHandler complete for TransactionID={transaction.TransactionID},Correlation-Token={ServiceUseCase?.RequestMetaData?.CorrelationToken}" +
                    $",VendorCall={vendorCalls?.FirstOrDefault()?.Elapsedms}", FunctionTimer.ElapsedMilliseconds, ServiceUseCase?.RequestMetaData?.PortalCode);
                transaction.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                transaction.DateTimeUTC = DateTime.UtcNow;
                transaction.VendorCalls = vendorCalls.ToList<VendorCall>();

                Stopwatch awsTaskSW = new Stopwatch();

                if (serviceResponse != null && !string.IsNullOrWhiteSpace(transaction.ResponseS3Key))
                {
                    if (metaData.Keys.Contains("Content-Type"))
                    {
                        metaData.Remove("Content-Type");
                    }
                    metaData.Add("Content-Type", ServiceUseCase?.RequestMetaData?.Accept);
                    if (ServiceUseCase.RequestMetaData.persist)
                    {
                        awsTasks.Add(ServiceUseCase.SaveToS3<HOAServiceResponse>(serviceResponse, GlobalConfiguration.S3_BUCKET, transaction.ResponseS3Key, transaction.TransactionID, GlobalConfiguration.KMS_KEY_ID, 0, metaData));
                    }
                }

                try
                {

                    if (transaction != null && !string.IsNullOrWhiteSpace(transaction?.TransactionID) && ServiceUseCase.RequestMetaData.persist)
                    {
                        ServiceUseCase.SaveDynamoDBTransaction<TransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transaction, transaction.TransactionID);

                    }
                }
                catch (Exception ex)
                {
                    transaction.HttpStatus = (int)HttpStatusCode.InternalServerError;

                    ServiceUseCase?.Logger.LogServiceError(ex,
                                           $"Failure in the PostHandler: Unable to save transaction TransactionID={transaction.TransactionID},Correlation-Token{ServiceUseCase?.RequestMetaData?.CorrelationToken}",
                                            FunctionTimer.ElapsedMilliseconds);
                }
                finally
                {
                    if (ServiceUseCase.RequestMetaData.persist)
                    {
                        awsTaskSW.Start();
                        await Task.WhenAll(awsTasks.ToArray());
                        awsTaskSW.Stop();
                    }
                }

                ServiceUseCase?.Logger.LogMessage($"Property POST Handler complete saving Response and Transaction for TransactionID={transaction?.TransactionID},Correlation-Token={ServiceUseCase?.RequestMetaData?.CorrelationToken}" +
                    $",VendorCallElapsedMs={vendorCalls?.FirstOrDefault()?.Elapsedms},SavinginAWS={awsTaskSW.ElapsedMilliseconds}" +
                    $",MapCanonicalResponse={buildcanonicalfromvendor},DataSource={transaction?.DataSource}", FunctionTimer.ElapsedMilliseconds, ServiceUseCase?.RequestMetaData?.PortalCode);
                FunctionTimer.Stop();
            }
            return serviceResponse;

        }

        public async Task<HOAGetResponse> GetHandler(string transactionID)
        {
            HOAServiceResponse serviceResponse = null;
            int StatusCode = (int)HttpStatusCode.NotFound;
            HOAGetResponse hOAGetResponse = null;
            ConcurrentDictionary<string, string> metaData = new ConcurrentDictionary<string, string>();

            string responseS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION, transactionID);
            var getResponse = await ServiceUseCase.GetS3Object(GlobalConfiguration.S3_BUCKET, responseS3Key);


            if (getResponse != null)
            {
                foreach (var meta in getResponse.Metadata.Keys)
                {
                    metaData.GetOrAdd(meta, getResponse.Metadata[meta]);
                }


                if (ServiceUseCase.ValidateGETCall(metaData, ServiceUseCase.RequestMetaData.GlobalID))
                {
                    StatusCode = (int)HttpStatusCode.OK;

                    using (StreamReader sr = new StreamReader(getResponse.ResponseStream))
                    {
                        string type = getResponse?.Headers?.ContentType ?? string.Empty;

                        if (type.EndsWith("json"))
                        {
                            serviceResponse = SerializationAssistant.DeserializeJson<HOAServiceResponse>(sr);
                        }
                        else if (type.EndsWith("xml"))
                        {
                            serviceResponse = SerializationAssistant.DeserializeXml<HOAServiceResponse>(sr);
                        }

                    }
                    if (!ServiceUseCase.RequestMetaData.Diagnostics)
                    {
                        serviceResponse.Diagnostics = null;
                    }
                }
            }
            else
            {
                StatusCode = (int)HttpStatusCode.OK;
                serviceResponse = new HOAServiceResponse
                {
                    Status = ServiceStatusCode.NotFound.ToString()
                };
            }
            hOAGetResponse = new HOAGetResponse
            {
                ServiceResponse = serviceResponse,
                StatusCode = StatusCode
            };
            return hOAGetResponse;
        }
        public async Task<HOAServiceDebug> HOADebugHandler(string transactionID)
        {
            TransactionRecord<VendorCall> transactionRecord = await ServiceUseCase.GetDynamoDBTransaction<TransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transactionID);

            string RequestS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.SERVICE_REQUEST_FOLDER, API_VERSION, transactionID);
            string ResponseS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION, transactionID);

            var serviceRequest = await ServiceUseCase.SearchS3ByKey<HOAServiceRequest>(GlobalConfiguration.S3_BUCKET, RequestS3Key, transactionID);
            
            var serviceResponse = await ServiceUseCase.SearchS3ByKey<HOAServiceResponse>(GlobalConfiguration.S3_BUCKET, ResponseS3Key, transactionID);
           
            VendorCall vendorCall = transactionRecord?.VendorCalls?.FirstOrDefault();
            DataTreeHOARequest vendorRequest = null;
            DataTreeHOAResponse vendorResponse = null;

            if (vendorCall != null)
            {
                if (!string.IsNullOrWhiteSpace(vendorCall?.RequestS3Key))
                {
                    vendorRequest = await ServiceUseCase.SearchS3ByKey<DataTreeHOARequest>(GlobalConfiguration.S3_BUCKET, vendorCall?.RequestS3Key, transactionID);
                }
                if (!string.IsNullOrWhiteSpace(vendorCall?.ResponseS3Key))
                {
                    vendorResponse = await ServiceUseCase.SearchS3ByKey<DataTreeHOAResponse>(GlobalConfiguration.S3_BUCKET, vendorCall?.ResponseS3Key, transactionID);
                }
            }
            var debugResponse = new HOAServiceDebug()
            {
                ServiceRequest = serviceRequest,
                ServiceResponse = serviceResponse,
                TransactionRecord = transactionRecord,
                VendorRequest = vendorRequest,
                VendorResponse = vendorResponse
            };

            return debugResponse;
        }

        private int GetCachePeriod(VendorConfiguration vendorConfig)
        {
            int cacheLimit = vendorConfig.CachePeriodDays;
            if ((int)ServiceUseCase?.RequestMetaData?.CachePeriod != int.MinValue)
            {
                cacheLimit = ServiceUseCase.RequestMetaData.CachePeriod;
                return cacheLimit;
            }
            DayOfWeek startDay = System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.FirstDayOfWeek;
            cacheLimit = DateTime.UtcNow.DayOfWeek - startDay;
            return cacheLimit;
        }
        private HOAServiceRequest BuildHealthRequest()
        {
            var serviceRequest = new HOAServiceRequest()
            {
                Address = new Common.API.Models.Entities.Address()
                {
                    StreetAddress1 = "2438 CALLE AQUAMARINA",
                    City = "SAN CLEMENTE",
                    State = "CA",
                    ZipCode = "92673"
                }
            };

            return serviceRequest;
        }
        public async Task<HealthCheckComponent> RunHealthCheck()
        {
            Stopwatch vendorWatch = new Stopwatch();

            HOAServiceResponse serviceResponse = new HOAServiceResponse();
            ConcurrentBag<VendorCall> vendorCalls = new ConcurrentBag<VendorCall>();
            TransactionRecord<VendorCall> transaction = new TransactionRecord<VendorCall>();
            awsTasks = new ConcurrentBag<Task>();
            HealthCheckComponent vendorComponent = new HealthCheckComponent()
            {
                Name = "HOA",
                Type = ComponentType.Vendor
            };


            var request = BuildHealthRequest();
            ServiceUseCase.RequestMetaData.SetPortalCodeforHealthcheck();
            transaction.CacheKey = ServiceUseCase.ComputeCacheKey(request.Address);
            Dictionary<string, VendorConfiguration> serviceConfig = ServiceUseCase.GetVendorConfiguration();

            List<VendorConfiguration> configList = serviceConfig.Values.ToList();
            var vendorUseCase = VendorUseCaseFactory.CreateVendorUseCase(S3Client, ServiceUseCase);
            vendorWatch.Start();
            var hoaResponse = await vendorUseCase.FetchServiceResponseAsync(request, configList, transaction, vendorCalls, ServiceUseCase, awsTasks, true) as DataTreeHOAResponse;
            serviceResponse = vendorUseCase.BuildCanonicalResponse(hoaResponse, transaction, vendorCalls, ServiceUseCase) as HOAServiceResponse;
            vendorWatch.Stop();

            vendorComponent.Information = new Dictionary<string, string>()
            {
                {"ResponseStatus", (serviceResponse.Status).ToString() },
                {"ResponseTimeMS",vendorWatch.ElapsedMilliseconds.ToString() }
            };

            if (!serviceResponse.Status.Equals("hit", StringComparison.InvariantCultureIgnoreCase))
            {
                vendorComponent.Status = ComponentStatus.Red;
                vendorComponent.Information.Add("Error", $"Error communicating with vendor. Status={serviceResponse?.Status}");
            }
            else
            {
                vendorComponent.Status = ComponentStatus.Green;
            }
            return vendorComponent;

        }

        #region "Migrate Handler"
        public async Task<HOAGetResponse> MigrateHandler(HOAServiceResponse serviceResponse)
        {
            HOAGetResponse hoaGetResponse = null;

            TransactionRecord<VendorCall> transaction = new TransactionRecord<VendorCall>();
            string transactionID = Guid.NewGuid().ToString();

            transactionID = !string.IsNullOrWhiteSpace(serviceResponse?.TransactionID) ? serviceResponse?.TransactionID : transactionID;

            transaction.TransactionID = transactionID?.ToLower();
            serviceResponse.TransactionID = transactionID?.ToLower();
            string transactionprefix = transaction.TransactionID.Substring(0, 4);

            transaction.RequestorID = serviceResponse?.RequestorID;
            transaction.ClientID = ServiceUseCase?.RequestMetaData?.ClientID;
            transaction.GlobalID = ServiceUseCase?.RequestMetaData?.GlobalID;
            transaction.PortalCode = ServiceUseCase?.RequestMetaData?.PortalCode;
            transaction.ExcludeFromBilling = true;
            transaction.DataSource = DataSource.Vendor.ToString();
            transaction.BucketName = GlobalConfiguration.S3_BUCKET;

            transaction.ResponseS3Key = ServiceUseCase.BuildS3Key(transactionprefix, GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION,  transaction.TransactionID);
            transaction.HttpStatus = (int)HttpStatusCode.OK;

            var metaData = new Dictionary<string, string>() { { "x-amz-meta-globalID", ServiceUseCase?.RequestMetaData?.GlobalID },
                                                                  { "x-amz-meta-transactionID", transaction.TransactionID },
                                                                  { "Content-Type", ServiceUseCase?.RequestMetaData?.Accept } ,
                                                                   };

            await (ServiceUseCase.SaveToS3(serviceResponse, GlobalConfiguration.S3_BUCKET, transaction.ResponseS3Key, transaction.TransactionID, GlobalConfiguration.KMS_KEY_ID, 0, metaData));
            hoaGetResponse = new HOAGetResponse
            {
                ServiceResponse = serviceResponse,
                StatusCode = transaction.HttpStatus
            };
            return hoaGetResponse;
        }

        #endregion

    }
    public class HOAGetResponse
    {
        public HOAServiceResponse ServiceResponse { get; set; }
        public int StatusCode { get; set; }
    }
}

﻿using FAMS.Common.API.Models.Entities;

namespace FAMS.HOAService.v1.Models.Service
{
   public class HOAServiceRequest
    {
        public string RequestorID { get; set; }
        public Address Address { get; set; }
       
    }
}

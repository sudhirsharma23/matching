﻿using FAMS.Common.API.Models.Infrastructure;
using FAMS.HOAService.v1.Models.Vendor;
using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.HOAService.v1.Models.Service
{
    public class HOAServiceDebug
    {
        public TransactionRecord<VendorCall> TransactionRecord { get; set; }
        public HOAServiceRequest ServiceRequest { get; set; }
        public HOAServiceResponse ServiceResponse { get; set; }
        public DataTreeHOARequest VendorRequest { get; set; }
        public DataTreeHOAResponse VendorResponse { get; set; }
    }
}

﻿

using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.HOAService.v1.Models.Vendor;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FAMS.HOAService.v1.Models.Service
{

    public enum ServiceStatusCode
    {
        Error,
        NotFound,
        Hit,
        NoHit,
    }
    public class HOAServiceResponse:IResponse
    {
        public string TransactionID { get; set; }
        public string RequestorID { get; set; }
        public string Status { get; set; }
        public List<Error> Errors { get; set; }
        public List<Diagnostic> Diagnostics { get; set; }
        public Property Property { get; set; }

        public List<HOA> HOAInformation { get; set; }
      
    }

    public class Property : Address
    {
        [StringLength(50)]
        public string CensusTractIdentifier { get; set; }

        [StringLength(100)]
        public string SubdivisionIdentifier { get; set; }
    }
   
    public class HOA
    {
        public List<Contact> Contacts { get; set; }
        [StringLength(200)]
        public string AssociationName { get; set; }
        [StringLength(200)]
        public string HOAType { get; set; }
        [StringLength(100)]
        public string City { get; set; }
        public decimal? Amount { get; set; }
        public decimal? MinAmount { get; set; }
        public decimal? MaxAmount { get; set; }
        [StringLength(50)]
        public string FeeFrequency { get; set; }
        [StringLength(50)]
        public string FeeType { get; set; }
    }
    public class Diagnostic
    {
        public string VendorURL { get; set; }
        public string VendorCode { get; set; }
        public string VendorLogin { get; set; }
        public int? VendorCallStatus { get; set; }
        public long? VendorResponseTime { get; set; }
        public string Message { get; set; }
        public string DataSource { get; set; }
    }

}

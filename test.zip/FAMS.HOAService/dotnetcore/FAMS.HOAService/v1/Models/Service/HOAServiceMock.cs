﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.HOAService.v1.Models.Service
{
    public class HOAServiceMock
    {
        public HOAServiceRequest MockServiceRequest { get; set; }
        public string MockVendorResponse { get; set; }
    }
}

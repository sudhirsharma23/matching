﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.HOAService.core
{
    public static class GlobalConfiguration
    {
        public static readonly string S3_BUCKET = System.Environment.GetEnvironmentVariable("S3_BUCKET");
        public static readonly string DYNAMO_TABLE = System.Environment.GetEnvironmentVariable("DYNAMODB_TABLE");
        public static readonly string KMS_KEY_ID = System.Environment.GetEnvironmentVariable("KMS_KEY_ID");
        public static readonly string Environment = System.Environment.GetEnvironmentVariable("ENVIRONMENT");
        public static readonly string SERVICE_ZONE_NAME = System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME");

        public static readonly string SAVE_VENDOR_REQUEST = System.Environment.GetEnvironmentVariable("SAVE_VENDOR_REQUEST");
        public static readonly string GATEWAY_NAME = System.Environment.GetEnvironmentVariable("GATEWAY_NAME");
        //  public static readonly string KEEP_WARM_CLOUDWATCH_EVENT_RULE = System.Environment.GetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE");

        public static readonly bool LOG_JODI = System.Environment.GetEnvironmentVariable("LOG_JODI").Equals("true", StringComparison.OrdinalIgnoreCase) ? true : false;

        public static readonly string SERVICE_REQUEST_FOLDER = "ServiceRequests";
        public static readonly string SERVICE_RESPONSE_FOLDER = "ServiceResponses";
        public static readonly string VENDOR_REQUEST_FOLDER = "VendorRequests";
        public static readonly string VENDOR_RESPONSE_FOLDER = "VendorResponses";
        public static readonly string MOCK_RESPONSE_FOLDER = "MockResponses";
        public static readonly string VENDOR_CONFIG_FOLDER = "VendorConfigurations";

       
    }
}

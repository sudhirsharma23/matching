1. alb arn for private.sbx.firstam.io was created using the repo https://fams.visualstudio.com/ITX-DevOps/_git/itx.digitalgateway?path=%2Fterraform%2Fv12%2F_sbx
2. Coment everything under the ######USED for OLD JODI#### in private-service.tf
3. then run the terraform in sandbox like you do in higher environments.
4. the targetgroups and service   needs colored workspaces.
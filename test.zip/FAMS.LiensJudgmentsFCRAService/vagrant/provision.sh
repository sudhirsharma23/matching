#!/bin/bash

sudo yum update -y

sudo yum install -y epel-release

echo "Installing common utils..."
sudo yum install -y wget
sudo yum install -y zip
sudo yum install -y unzip
sudo  yum install -y net-tools

echo "Installing paython34..."
sudo yum install -y python34
sudo yum install -y python34-setuptools


if [ ! -d /tmp/jq ]; then
	echo "Installing jq..."
	mkdir /tmp/jq
	cd /tmp/jq
	wget -O jq https://github.com/stedolan/jq/releases/download/jq-1.5/jq-linux64
	chmod +x ./jq
	sudo cp jq /usr/bin
fi


if [ ! -d /home/vagrant/packer ]; then
	echo "Installing packer..."
	mkdir /home/vagrant/packer
	cd /home/vagrant/packer
	wget https://releases.hashicorp.com/packer/1.0.4/packer_1.0.4_linux_amd64.zip
	unzip packer_1.0.4_linux_amd64.zip
	cd /usr/bin
	sudo ln -s /home/vagrant/packer/packer packer_io
fi

echo "Installing awscli..."
sudo curl "https://s3.amazonaws.com/aws-cli/awscli-bundle.zip" -o "awscli-bundle.zip"
sudo unzip awscli-bundle.zip
sudo ./awscli-bundle/install -i /usr/local/aws -b /usr/bin/aws

echo "Reading config.json..."
ConfigPath=/home/vagrant/config.json
#grab hostName
HostName=$(cat $ConfigPath | jq -r ".hostName")
#grab user
User=$(cat $ConfigPath| jq -r ".user")
#grab user
AccessKey=$(cat $ConfigPath | jq -r ".awsAccessKey")
#grab user
SecretKey=$(cat $ConfigPath | jq -r ".awsSecretKey")
#grab region
Region=$(cat $ConfigPath | jq -r ".region")


if [ ! -d ~/.aws ]; then
	mkdir ~/.aws
fi


if [ -f ~/.aws/config ]; then
	rm ~/.aws/config
fi

echo "Creating  ~/.aws/config..."
echo "[default]" >> ~/.aws/config
echo "aws_access_key_id=$AccessKey" >> ~/.aws/config
echo "aws_secret_access_key=$SecretKey" >> ~/.aws/config
echo "region=$Region" >> ~/.aws/config
mkdir /home/vagrant/.aws
cp ~/.aws/config /home/vagrant/.aws/config 


if [ ! -f /usr/local/bin/docker-compose ]; then

	echo "Installing docker-compose..."
	sudo curl -L https://github.com/docker/compose/releases/download/1.15.0/docker-compose-`uname -s`-`uname -m` > /usr/local/bin/docker-compose
	sudo chmod +x /usr/local/bin/docker-compose
fi









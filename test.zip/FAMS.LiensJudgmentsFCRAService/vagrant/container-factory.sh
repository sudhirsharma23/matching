#!/bin/bash


echo "starting container-factory..."

# echo "Reading config.json..."

# ConfigPath=/home/vagrant/config.json
# HostName=$(cat $ConfigPath | jq -r ".hostName") #grab hostName
# User=$(cat $ConfigPath| jq -r ".user") #grab user
# AccessKey=$(cat $ConfigPath | jq -r ".awsAccessKey") #grab AccessKey
# SecretKey=$(cat $ConfigPath | jq -r ".awsSecretKey") #grab SecretKey
# Region=$(cat $ConfigPath | jq -r ".region") #grab region

# if [ ! -d ~/.aws ]; then
# 	mkdir ~/.aws
# fi

# if [ -f ~/.aws/config ]; then
# 	rm ~/.aws/config
# fi

# echo "Creating  ~/.aws/config..."
# echo "[default]" >> ~/.aws/config
# echo "aws_access_key_id=$AccessKey" >> ~/.aws/config
# echo "aws_secret_access_key=$SecretKey" >> ~/.aws/config
# echo "region=$Region" >> ~/.aws/config
# cat  ~/.aws/config
# cp /root/.aws/config /vargant/.aws/credentials # copy to 'credentials' to vangrant user .aws for ECR login


echo "looking for docker image openresty-base..."
## Build openresty-base with docker
docker images | grep openresty-base
greprc=$?
if [[ $greprc -eq 1 ]] ; then
	cd /vagrant/docker_build/openresty-base
	./docker-build.sh
fi

## Build node-base with docker
docker images | grep node-base
greprc=$?
if [[ $greprc -eq 1 ]] ; then
	cd /vagrant/docker_build/node-base
	./docker-build.sh
fi

docker rm $(docker ps -a | grep consul | cut -d" " -f1) -f
docker run -d -p 8500:8500 --name=dev-consul -e CONSUL_BIND_INTERFACE=eth0 consul

docker rm $(docker ps -a | grep registrator | cut -d" " -f1) -f
docker run -d \
    --name=registrator \
    --net=host \
    --volume=/var/run/docker.sock:/tmp/docker.sock \
    gliderlabs/registrator:latest \
      -internal \
      consul://localhost:8500




#fire up lambda-proxy container
cd /vagrant/packer_build/lambda-proxy
chmod +x ./packer-run.sh
./packer-run.sh

#fire up edge-proxy-consul-tpl container
cd /vagrant/packer_build/edge-proxy-consul-tpl
chmod +x ./packer-run.sh
./packer-run.sh

#start log aggragator
docker rm $(docker ps -a | grep logspout | cut -d" " -f1) -f
docker run -d -p 8000:8000 -v=/var/run/docker.sock:/tmp/docker.sock --name logspout progrium/logspout
#!/bin/bash

docker build -t alpine-bash:latest .
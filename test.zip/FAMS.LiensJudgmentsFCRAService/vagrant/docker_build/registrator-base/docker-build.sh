#!/bin/bash

docker build -t registrator-base:latest .
#!/bin/bash

echo "Reading config.json..."
ConfigPath=/home/vagrant/config.json
#grab hostName
HostName=$(cat $ConfigPath | jq -r ".hostName")
#grab user
User=$(cat $ConfigPath| jq -r ".user")
#grab user
AccessKey=$(cat $ConfigPath | jq -r ".awsAccessKey")
#grab user
SecretKey=$(cat $ConfigPath | jq -r ".awsSecretKey")
#grab region
Region=$(cat $ConfigPath | jq -r ".region")


if [ ! -d ~/.aws ]; then
	mkdir ~/.aws
fi


if [ -f ~/.aws/config ]; then
	rm ~/.aws/config
fi

if [ -f ~/.aws/credentials ]; then
	rm ~/.aws/credentials
fi

rm /home/vagrant/.aws/credentials

echo "Creating  ~/.aws/config..."
echo "[default]" >> ~/.aws/config
echo "aws_access_key_id=$AccessKey" >> ~/.aws/config
echo "aws_secret_access_key=$SecretKey" >> ~/.aws/config
echo "region=$Region" >> ~/.aws/config
mkdir /home/vagrant/.aws

cp ~/.aws/config /home/vagrant/.aws/config 
cp ~/.aws/config /home/vagrant/.aws/credentials
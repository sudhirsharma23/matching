#!/bin/bash

set -x
set -e

apk add jq

#unzip chaperone config
unzip /tmp/chaperone.zip -d /etc/chaperone.d

## self signed certs
if [ ! -d "/etc/nginx" ]; then
    mkdir /etc/nginx
fi
if [ ! -d "/etc/nginx/ssl" ]; then
   mkdir /etc/nginx/ssl
fi

cp /tmp/ca_combined.crt /etc/nginx/ssl/ca_combined.crt


cd /etc/nginx/ssl
openssl req -new -newkey rsa:4096 -days 1460 -nodes -x509 \
-subj "/C=US/ST=CA/L=Santa Ana/O=ITX/CN=www.example.com" \
-keyout www.example.com.key  -out www.example.com.cert

#install consul-template
cd /tmp
curl https://releases.hashicorp.com/consul-template/0.19.3/consul-template_0.19.3_linux_amd64.zip --output consul-template.zip
unzip consul-template.zip
cp consul-template /usr/local/bin/consul-template


# consul-template configurations folder
mkdir -p /etc/consul-template/config.d

#unzip consul-template  config
unzip /tmp/consul-template-config.zip -d /etc/consul-template/config.d

#unzip scripts
unzip /tmp/scripts.zip -d /tmp/scripts

#unzip lau-checkups config
#unzip /tmp/checkups-files.zip  -d /tmp/checkups
#cp /tmp/checkups/checkups-files/* /usr/local/openresty/lualib/resty/ -r


#install lau modules using OPM
opm get thibaultcha/lua-resty-jit-uuid
#opm get huangnauh/lua-resty-consul
opm get agentzh/lua-resty-http
#opm get chronolaw/lua-resty-msgpack

# wget http://luarocks.github.io/luarocks/releases/luarocks-2.4.3.tar.gz
# tar -xzvf luarocks-2.4.3.tar.gz -C /tmp
# cd /tmp/luarocks-2.4.3
# ./configure --prefix=/usr/local/openresty/luajit \
#     --with-lua=/usr/local/openresty/luajit/ \
#     --lua-suffix=jit \
#     --with-lua-include=/usr/local/openresty/luajit/include/luajit-2.1
# make build
# make install


# luarocks install lua-resty-shcache

# apk add git
# luarocks install lua-cmsgpack
# luarocks install luasocket
#!/bin/sh
host_ip=$(/sbin/ip route|awk '/default/ { print $3 }')

export CONSUL_SERVER_ADDRESS=$host_ip

#echo "$host_ip:8500"
echo "127.0.0.1:8500"


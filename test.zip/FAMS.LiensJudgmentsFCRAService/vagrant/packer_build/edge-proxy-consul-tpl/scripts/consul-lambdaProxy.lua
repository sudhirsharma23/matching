local http = require "resty.http"
local cjson = require "cjson"
local httpc = http.new()

function tablelength(T)
  local count = 0
  for _ in pairs(T) do count = count + 1 end
  return count
end

  
local consul_adr = os.getenv("A_CONSUL_ADDRESS")

local tag = "default"
if ngx.var.version ~= "" then
    tag = string.sub(ngx.var.version,2)
 end

service_q = "http://" .. consul_adr .. "/v1/catalog/service/lambda_proxy?tag=".. tag;

ngx.log(ngx.STDERR, service_q) 

local res, err = httpc:request_uri(service_q, {
    method = "GET"
  })

  if not res then
    ngx.say("failed to request: ", err)
    return
  end
  ngx.log(ngx.STDERR, res.body) 

  local json = cjson.decode(res.body)
  local server_list = {}

  local count = 1
  for k, v in pairs(json) do
    local key = v.ServiceAddress .. ":" .. v.ServicePort 
    table.insert(server_list,count, key)
    count = count + 1 
  end

  local backends = ngx.shared.backends
  local last_one = backends:get(service_q)
  if(not last_one) then
    last_one = 0
  end

  next_one = last_one + 1
  len = tablelength(server_list)
  if ( next_one > len) then
    next_one = 1
  end

  backends:set(service_q,next_one)
  ngx.ctx.next_server = server_list[next_one]
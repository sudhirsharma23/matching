#!/bin/sh
host_ip=$(/sbin/ip route|awk '/default/ { print $3 }')
consul_server_address=$(curl http://$host_ip:8500/v1/catalog/service/consul -s | jq  ".[0].Address" -r)
echo "$consul_server_address:8301"


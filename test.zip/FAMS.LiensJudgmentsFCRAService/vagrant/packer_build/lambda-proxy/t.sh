#!/bin/bash
dn=$(dirname ${BASH_SOURCE[0]})
if [[ $dn = "." ]]; then
	bp=$PWD
else
	bp=$dn
fi


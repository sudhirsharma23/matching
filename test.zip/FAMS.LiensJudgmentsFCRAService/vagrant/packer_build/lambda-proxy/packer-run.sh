#!/bin/bash

#set -x
dn=$(dirname ${BASH_SOURCE[0]})
if [[ $dn = "." ]]; then
	bp=$PWD
else
	bp=$dn
fi
. $bp/packer-build.sh


#todo: change to use vault/consul-template to issue/reissue aws creds
rs=$(aws sts assume-role --role-arn arn:aws:iam::666678657097:role/CrossAccountAdmin  --role-session-name jharris)
echo $rs | jq '.Credentials.SessionToken'
aKey=$(echo $rs | jq '.Credentials.AccessKeyId' -r)
sKey=$(echo $rs | jq '.Credentials.SecretAccessKey' -r)
ses=$(echo $rs | jq '.Credentials.SessionToken' -r)

map_path=$(cat /vagrant/artifacts.json | jq '."lambda-map"' -r)

docker run -d \
    -e "SERVICE_NAME=lambda_proxy" \
    -e "SERVICE_TAGS=v1,default" \
    -e "AWS_ACCESS_KEY_ID=$aKey" \
    -e "AWS_SECRET_ACCESS_KEY=$sKey" \
    -e "AWS_SESSION_TOKEN=$ses" \
    -e "AWS_DEFAULT_REGION=us-west-2" \
    -e "MAP_S3_PATH=$map_path" \
    -e "PERSONA_S3_BUCKET=sbx-persona-test" \
    -e "PERSONA_S3_PREFIX=persona/" \
    -e "KEEP_X_CERT=true" \
    -p 3030:8030 --name lambda-proxy-0 --entrypoint tini lambda-proxy /usr/local/bin/start.sh


#docker run -d -e "SERVICE_NAME=lambda_proxy" -p 3030:8030 --name lambda-proxy-0 --entrypoint /tini prince-rest node /var/lambda-proxy/lambdaProxy.js
#docker run -d -e "SERVICE_NAME=lambda_proxy" -p 3031:8030 --name lambda-proxy-1 --entrypoint /tini prince-rest node /var/lambda-proxy/lambdaProxy.js
#docker run -d -e "SERVICE_NAME=lambda_proxy" -p 3032:8030 --name plambda-proxy-2 --entrypoint /tini prince-rest node /var/lambda-proxy/lambdaProxy.js

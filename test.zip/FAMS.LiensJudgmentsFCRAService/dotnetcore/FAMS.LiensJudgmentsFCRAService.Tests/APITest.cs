using Amazon.DynamoDBv2;
using Amazon.Lambda.TestUtilities;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.S3;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Extensions.Caching;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using FAMS.LiensJudgmentsFCRAService.v1;
using FAMS.LiensJudgmentsFCRAService.v1.Models.Service;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Xunit;

namespace FAMS.LiensJudgmentsFCRAService.Tests
{
    public class APITest
    {
        AWSCredentials credentials;
        IAmazonS3 s3Client;
        IAmazonDynamoDB dbClient;
        SecretsManagerCache secretsClient;
        private string aws_generated_name = "sbx-internal-api-w2-nice-shark";


        public APITest()
        {
            credentials = GetAWSCredentialsFromProfile("fg-nonprod");
            s3Client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USWest2);
            dbClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.USWest2);
            IAmazonSecretsManager secretsmanager = new AmazonSecretsManagerClient(credentials, Amazon.RegionEndpoint.USWest2);
            secretsClient = new SecretsManagerCache(secretsmanager);
            Environment.SetEnvironmentVariable("S3_BUCKET", "rc-lnj-fcra-api-w2-caring-bass");
            Environment.SetEnvironmentVariable("DYNAMODB_TABLE", "rc-lnj-fcra-api-w2-transactions");
            Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:936562317728:key/4349fe36-a647-4bba-a90b-3c10fb1a5b33");
            Environment.SetEnvironmentVariable("LOG_JODI", "false");
            Environment.SetEnvironmentVariable("SERVICE_ZONE_NAME", "lnj-fcra");
            Environment.SetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE", "KeepWarmHealthCheck");
            Environment.SetEnvironmentVariable("ENVIRONMENT", "rc");
            Environment.SetEnvironmentVariable("PDF_UTILITY_URL", "https://dev-pdf-utility-w2-ruling-pika.dev.firstam.io");
        }

        [Fact]
        public async void TestRouteHandlerPOST()
        {
            string fileName = "999111112.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = aws_generated_name,
                Body = ConvertServiceRequestToBase64WithNewRequestorID("FAMS.LiensJudgmentsFCRAService.Tests.SampleRequests", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "request-id", Guid.NewGuid().ToString() },
                    { "orig-path", string.Format("/{0}/order", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "AlexTEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            var des = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(des.HttpStatus == 200);
            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerPOSTMOCK()
        {
            string fileName = "999111112.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = aws_generated_name,
                Body = ConvertServiceRequestToBase64("FAMS.LiensJudgmentsFCRAService.Tests.SampleMock", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/mock", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "AlexTEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            var des = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(des.HttpStatus == 200);
            Assert.IsType<MemoryStream>(routingResponse);
        }
        [Fact]
        public async void TestRouteHandlerGET()
        {
            JODIRequest jr = new JODIRequest
            {
                Lambda = "liensjudgmentsfcra",
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/report", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    {"stage", "sbx"},
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "AlexTEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    },
                    QueryString = new SerializableDictionary<string, string>()
                    {
                        {"transactionID", "e5424ca3-ae7a-45d4-bd53-5ec3ee3af12c" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            var des = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            
            Assert.True(des.HttpStatus == 200);
            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerHEALTH()
        {
            JODIRequest jr = new JODIRequest
            {
                Lambda = "liensjudgmentsfcra",
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/health", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    {"request-id", "d0354377-f9a6-450a-a614-ec81b1150bae" },
                    {"stage", "sbx"}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "AlexTEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, secretsClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            var des = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(des.HttpStatus == 200);
            Assert.IsType<MemoryStream>(routingResponse);
        }

        private AWSCredentials GetAWSCredentialsFromProfile(string profile)
        {
            var credentialProfileStoreChain = new CredentialProfileStoreChain();

            if (credentialProfileStoreChain.TryGetAWSCredentials(profile, out AWSCredentials credentials))
                return credentials;
            else
                throw new AmazonClientException("Unable to find a " + profile + " profile in CredentialProfileStoreChain.");
        }

        private string ConvertServiceRequestToBase64(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);

            return Convert.ToBase64String(ms.ToArray());
        }

        private string ConvertServiceRequestToBase64WithNewRequestorID(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            using (MemoryStream ms = new MemoryStream())
            {
                resource.CopyTo(ms);
                ms.Position = 0;

                using (var sr = new StreamReader(ms))
                {
                    string request = sr.ReadToEnd();

                    var serializedRqst = string.Empty;

                    if (fileName.EndsWith("xml"))
                    {
                        var serviceRequest = SerializationAssistant.DeserializeXml<LiensJudgmentsFCRAServiceRequest>(request);
                        serviceRequest.RequestorID = RandomString(15);

                        serializedRqst = SerializationAssistant.SerializeXml(serviceRequest);
                    }
                    else
                    {
                        var serviceRequest = SerializationAssistant.DeserializeJson<LiensJudgmentsFCRAServiceRequest>(request);
                        serviceRequest.RequestorID = RandomString(15);

                        serializedRqst = SerializationAssistant.SerializeJson(serviceRequest);
                    }



                    return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(serializedRqst));
                }
            }
        }

        private string GetContentTypeFromFile(string extension)
        {
            if (extension.Equals(".json"))
                return "application/json";
            else if (extension.Equals(".xml"))
                return "text/xml";
            else
                return string.Empty;
        }

        private Random random = new Random();
        public string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }


    }
}

﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SecretsManager.Extensions.Caching;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Enums;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.LiensJudgmentsFCRAService.v1.Models.Service;
using FAMS.LiensJudgmentsFCRAService.v1.Models.Vendor;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ResultType = FAMS.LiensJudgmentsFCRAService.v1.Models.Service.ResultType;

namespace FAMS.LiensJudgmentsFCRAService.v1
{
    public class UseCase
    {
        private string API_VERSION = "v1";
        private IAmazonS3 _s3Client;
        private IAmazonDynamoDB _dbClient;
        private IDynamoDBContext _dbContext;
        private LoggingAssistant _logger;
        private SecretsManagerCache _secretsClient;
        public string Errors { get; set; }

        public LoggingAssistant Logger
        {
            get
            {
                return this._logger;
            }
            set
            {
                this._logger = value;
            }
        }
        public RequestMetaData RequestMetaData;
        public UseCase()
        {
            _s3Client = new AmazonS3Client();
            _dbClient = new AmazonDynamoDBClient();
            _dbContext = new DynamoDBContext(_dbClient);
            _secretsClient = new SecretsManagerCache();
        }

        public UseCase(IAmazonS3 s3Client, IAmazonDynamoDB dynamoClient, SecretsManagerCache secretsClient)
        {
            _s3Client = s3Client;
            _dbClient = dynamoClient;
            _dbContext = new DynamoDBContext(_dbClient);
            _secretsClient = secretsClient;
        }

        public void InitializeUseCase(JODIRequest request, ILambdaContext context)
        {
            RequestMetaData = new RequestMetaData(request);
            Logger = new LoggingAssistant(context.FunctionName, "FAMS.LiensJudgmentsFCRAService", RequestMetaData.TransactionID, RequestMetaData.Persona);
            Errors = null;
        }

        public static HttpClient InitializeHttpClient(ConcurrentDictionary<string, HttpClient> clients, VendorConfiguration config, string portalCode)
        {
            HttpClient client = null;

            //httpclient proxy settings are automatically obtained from IE settings and used for all HTTP calls by default
            HttpClientHandler handler = new HttpClientHandler()
            {
                Credentials = new NetworkCredential(config.Login, config.Password)
            };
            client = new HttpClient(handler);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.Timeout = new TimeSpan(0, 0, config.TimeoutMS / 1000);

            return client;
        }

        public async Task<HttpResponseMessage> CallVendor(HttpClient client, object lexisRequest, string url, VendorCall vendorCall)
        {
            HttpResponseMessage response = null;
            Stopwatch VendorWatch = new Stopwatch();
            if (!FAMS.Common.API.Assistants.UriAssistant.IsValidURL(url, Logger))
            {
                throw new UriFormatException("Invalid Vendor URL: " + url);
            }
            try
            {
                VendorWatch.Start();

                var stringContent = new StringContent(SerializationAssistant.SerializeJson(lexisRequest), Encoding.UTF8, "application/json");

                response = await client.PostAsync(url, stringContent);
            }
            catch
            {
                Errors = "Invalid vendor Response";
                throw;
            }
            finally
            {
                VendorWatch.Stop();

                if (vendorCall != null)
                {
                    Logger.LogVendorCall(vendorCall.Name,
                                                   string.Format("Calling Vendor.  URL={0},RequestS3Key={1}", url, vendorCall.RequestS3Key),
                                                   VendorWatch.ElapsedMilliseconds);

                    vendorCall.Elapsedms = VendorWatch.ElapsedMilliseconds;
                }
            }

            return response;
        }

        public Task<HttpResponseMessage> CallVendor(HttpClient client, object lexisRequest, string url)
        {
            return CallVendor(client, lexisRequest, url, null);
        }

        public T GetServiceRequestFromJODI<T>(JODIRequest jodiRequest, Stopwatch functionTimer) where T : class
        {
            T request = null;

            try
            {
                request = JODIAssistant.DeserializeB64Body<T>(jodiRequest.BodyType, jodiRequest.Body);
            }
            catch (Exception ex)
            {
                string requestID = string.Empty;
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);

                _logger.LogServiceError(ex, string.Format("Failure to deserialize b64 body. Body={0}", jodiRequest.Body), functionTimer.ElapsedMilliseconds);
            }

            return request;
        }

        public RiskView2RequestEnvelope MapServiceRequestToVendorRequest(LiensJudgmentsFCRAServiceRequest serviceRequest, string transactionID, string portalCode, string intendedPurpose)
        {
            return new RiskView2RequestEnvelope()
            {
                RiskView2Request = new RiskView2Request()
                {
                    User = new User()
                    {
                        ReferenceCode = portalCode, //returned in billing statement
                        BillingCode = string.Format("{0}-{1}", "FAMS", portalCode), //returned in the LexisNexis billing detail logs.
                        QueryId = transactionID //echoed back in results.
                    },
                    Options = new Options()
                    {
                        IncludeReport = false,
                        IntendedPurpose = intendedPurpose,
                        IncludeLiensJudgmentsReport = true,
                        LiensJudgmentsReportOptions = new LiensJudgmentsReportOptions()
                        {
                            ExcludeCityTaxLiens = false,
                            ExcludeCountyTaxLiens = false,
                            ExcludeEvictions = false,
                            ExcludeFederalTaxLiens = false,
                            ExcludeJudgments = false,
                            ExcludeOtherLiens = false,
                            ExcludeStateTaxLiens = false,
                            ExcludeStateTaxWarrants = false,
                            ReportingPeriod = 84,
                            MinimumAmount = "0",
                            AttributesOnly = false,
                            ExcludeReleasedCases = false,
                            //NotificationEmail = serviceRequest.NotificationEmail,
                            //StatusRefreshWaitPeriod = serviceRequest.StatusRefreshWaitPeriod
                        }
                    },
                    SearchBy = new SearchBy()
                    {
                        Name = serviceRequest.Person.Name,
                        Address = MapToLexisAddress(serviceRequest.Person.Address),
                        SSN = serviceRequest.Person.SSN,
                        HomePhone = serviceRequest.Person?.PhoneNumbers?.Where(x => x.PhoneType == PhoneType.Home).First()?.PhoneNumber
                    }
                }
            };
        }

        public LiensJudgmentsFCRAServiceResponse CreateServiceResponse(RiskView2ResponseEnvelope response, TransactionKey ljTrans, VendorConfiguration config, long ElapsedMS)
        {
            LiensJudgmentsFCRAServiceResponse serviceResponse = null;
            Diagnostic diagnostic = null;

            if (RequestMetaData.Diagnostics)
            {
                VendorCall vCall = null;
                if (ljTrans.VendorCalls != null && ljTrans.VendorCalls.Count > 0)
                {
                    vCall = ljTrans.VendorCalls.FirstOrDefault();
                }
                diagnostic = new Diagnostic
                {
                    VendorCode = vCall?.Name,
                    VendorLogin = config?.Login,
                    VendorURL = config?.URL,
                    VendorResponseTime = vCall?.Elapsedms,
                    VendorCallStatus = vCall?.HttpStatus,
                    Message = Errors,
                    DataSource = ljTrans.DataSource
                };
            }
            var riskviewExceptions = response?.RiskView2ResponseEx?.response?.Header?.Exceptions?.Item;
            if (riskviewExceptions != null && riskviewExceptions.Count > 0)
            {
                foreach (var ex in riskviewExceptions)
                {
                    if (ex.Code == 801)
                    {
                        string dtransID = ParseDeferredTransactionID(ex.Message);
                        ljTrans.DeferredTransactionID = dtransID;
                        serviceResponse = new LiensJudgmentsFCRAServiceResponse
                        {
                            DeferredTransactionID = dtransID,
                            RequestorID = ljTrans.RequestorID,
                            TransactionID = ljTrans.TransactionID,
                            Result = (ResultType)2,
                            Diagnostics = diagnostic
                        };
                    }
                }
                return serviceResponse;
            }

            var liens = response?.RiskView2ResponseEx?.response?.Result?.LiensJudgmentsReports?.Liens?.Lien;
            var judgments = response?.RiskView2ResponseEx?.response?.Result?.LiensJudgmentsReports?.Judgments?.Judgment;
            var attributes = response?.RiskView2ResponseEx?.response?.Result?.LiensJudgmentsReports?.LnJAttributes?.LnJAttribute;
            int sevIndex = -1;

            if (attributes != null)
            {
                var hitType = attributes.Where(a => a.Name.Equals("LnJLienJudgmentSeverityIndex", StringComparison.OrdinalIgnoreCase)).FirstOrDefault();

                int.TryParse(hitType.Value, out sevIndex);

                if (sevIndex > 1)
                    sevIndex = 1;
                else if (sevIndex == 0 && hitType.Value != "0") //int tryparse sets invalid parsing result to 0 but we want -1 unless the string is actually 0
                    sevIndex = -1;
            }

            // Order records by most recent.
            if (judgments != null && judgments.Count > 0)
            {
                judgments = judgments.OrderByDescending(x => DateTime.Parse(string.Format("{0}/{1}/{2}", x?.DateFiled?.Month, x?.DateFiled?.Day, x?.DateFiled?.Year))).ToList();
            }

            serviceResponse = new LiensJudgmentsFCRAServiceResponse
            {
                RequestorID = ljTrans.RequestorID,
                TransactionID = ljTrans.TransactionID,
                Result = (ResultType)sevIndex,
                Liens = MapToServiceResponseLiens(liens),
                Judgments = judgments,
                LnJAttributes = attributes,
                Diagnostics = diagnostic
            };

            return serviceResponse;
        }

        private string ParseDeferredTransactionID(string message)
        {
            string deferredTransactionID = string.Empty;
            if (!string.IsNullOrEmpty(message))
            {
                deferredTransactionID = message.Split('(', ')')[1];
            }

            return deferredTransactionID;
        }

        public JODIResponse BuildValidationErrorResponse(LiensJudgmentsFCRAServiceRequest request, TransactionRecord<VendorCall> transaction, Stopwatch functionTimer)
        {
            JODIResponse response = null;
            StringBuilder sb = new StringBuilder();

            //**Required Fields for Service**
            //requestorID, clientID, globalID, portalCode
            if (string.IsNullOrEmpty(request?.RequestorID))
                sb.Append("RequestorID is a required field.");

            if (string.IsNullOrEmpty(transaction.ClientID))
                sb.Append("ClientID is a required field.");

            if (string.IsNullOrEmpty(transaction.PortalCode))
                sb.Append("PortalCode is a required field.");

            if (string.IsNullOrEmpty(transaction.GlobalID))
                sb.Append("GlobalID is a required field.");

            //**Required Fields for Vendor**
            //First, Last, StreetAddress1, and Zip5
            //First, Last, StreetAddress1, City, and State
            //First, Last, and SSN
            var first = request?.Person?.Name?.First;
            var last = request?.Person?.Name?.Last;

            if (string.IsNullOrEmpty(first) || string.IsNullOrEmpty(last))
            {
                sb.Append("A First Name and Last Name for the entity is required.");
            }



            var ssn = request?.Person?.SSN;
            var address = request?.Person?.Address;

            if (string.IsNullOrEmpty(ssn))
            {
                if (string.IsNullOrEmpty(address?.StreetAddress1))
                {
                    sb.Append("A SSN or an Address for the entity is required.");
                }
                else if (string.IsNullOrEmpty(address?.ZipCode))
                {
                    if (string.IsNullOrEmpty(address?.City) || string.IsNullOrEmpty(address?.State))
                    {
                        sb.Append("A City and State OR a Zip is required with an Address.");
                    }
                }
            }
            else
            {
                if (!Regex.IsMatch(ssn, @"^\d{9}$"))
                    sb.Append("SSN must be 9 digits.");
            }


            if (!IntendedPurpose.IsValid(request.IntendedPurpose))
                sb.Append("The IntendedPurpose field does not have a valid value.");

            string message = sb.ToString().Trim();

            if (!string.IsNullOrEmpty(message))
            {
                response = new JODIResponse()
                {
                    ErrorMessage = new JODIErrorResponse()
                    {
                        HttpStatus = (int)HttpStatusCode.BadRequest,
                        Error = message,
                    }
                };

                _logger.LogServiceError(new Exception(message), "Request failed validation.", functionTimer.ElapsedMilliseconds);
            }

            return response;
        }

        public async Task<RiskView2ResponseEnvelope> GetMockedResponseFromS3(string bucket, string key)
        {
            RiskView2ResponseEnvelope cachedResponse = null;

            try
            {
                var s3Response = await AWSAssistant.SearchS3ByKey<string>(_s3Client, bucket, key);


                cachedResponse = SerializationAssistant.DeserializeJson<RiskView2ResponseEnvelope>(s3Response);
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex, "Failure retrieving mocked vendor response from S3", bucket, key);
            }

            return cachedResponse;
        }

        public string ComputeCacheKey(string globalID, Person searchBy)
        {
            if (searchBy == null)
                return null;

            byte[] hashValue = null;
            JObject jObj = JObject.FromObject(searchBy);
            var minFields = new JObject();
            minFields.Add("Name", jObj["Name"]);

            if (jObj["SSN"].Type != JTokenType.Null && !string.IsNullOrWhiteSpace(jObj["SSN"].ToString()))
                minFields.Add("SSN", jObj["SSN"]);
            else if (jObj["Address"].Type != JTokenType.Null)
                minFields.Add("Address", jObj["Address"]);

            string key = string.Format("{0}|{1}", globalID, SerializationAssistant.SerializeJson(minFields).Replace("\"\"", "null"));
            key = new string(key.ToLower().ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());  //lowercase + remove whitespace

            UTF8Encoding enc = new UTF8Encoding();

            using (var sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(enc.GetBytes(key));
            }

            return BitConverter.ToString(hashValue).Replace("-", "");
        }

        public string ComputeMockKey(Person searchBy)
        {
            if (searchBy == null)
                return null;

            byte[] hashValue = null;
            string key = SerializationAssistant.SerializeJson(searchBy).Replace("\"\"", "null");
            key = new string(key.ToLower().ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());
            UTF8Encoding enc = new UTF8Encoding();

            using (var sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(enc.GetBytes(key));
            }

            return BitConverter.ToString(hashValue).Replace("-", "");
        }

        public string BuildS3Key(string folder, string version, string name, string fileType)
        {
            if (string.IsNullOrEmpty(fileType))
                return string.Format("{0}/{1}/{2}", folder, version, name);
            else
                return string.Format("{0}/{1}/{2}.{3}", folder, version, name, fileType);
        }

        private async Task<string> GetVendorConfigFromSecrets(string vendorName)
        {
            string vendorInfo = null;
            string path = string.Empty;
            StringBuilder sb = new StringBuilder();
            if (vendorName.Contains("lexis", StringComparison.InvariantCultureIgnoreCase))
            {
                sb.Append("lexisfcra/");
            }

            if (RequestMetaData.ConfigOverride && !string.IsNullOrWhiteSpace(RequestMetaData.CredsID))
            {
                sb.Append($"{RequestMetaData.GlobalID}/{RequestMetaData.CredsID}");
            }
            else
            {
                sb.Append($"{RequestMetaData.PortalCode}/default");
            }

            path = sb.ToString();
            try
            {
                vendorInfo = await _secretsClient.GetSecretString(path);
            }
            catch (Exception e)
            {
                Errors = "Unable to Retrieve Vendor Credentials";
                Logger.LogServiceError(e, $"Unable to retrieve secrets for Vendorname={vendorName},path={path},TransactionID={RequestMetaData?.TransactionID},Correlation-Token={RequestMetaData?.CorrelationToken}", 0, RequestMetaData?.PortalCode);
            }
            return vendorInfo;
        }

        public async Task GetVendorCredentials(VendorConfiguration config)
        {
            var vendorCredentials = await GetVendorConfigFromSecrets(config.VendorCode);
            JObject envConfig = null;

            if (!string.IsNullOrWhiteSpace(vendorCredentials))
            {
                envConfig = JObject.Parse(vendorCredentials);
            }

            if (RequestMetaData.ConfigOverride && string.IsNullOrWhiteSpace(RequestMetaData?.CredsID))
            {
                config.Login = RequestMetaData?.VendorUN;
                config.Password = RequestMetaData?.VendorPWD;
            }
            else if (envConfig != null)
            {
                config.Login = envConfig["Login"]?.ToString();
                config.Password = envConfig["Password"]?.ToString();
            }

        }

        public Dictionary<string, VendorConfiguration> GetVendorConfiguration()
        {
            var environment = GlobalConfiguration.ENVIRONMENT;
            string directoryname = string.Format("{0}v1/Configs", AppDomain.CurrentDomain.BaseDirectory);
            string filename = @"default.json";
            string file = string.Empty;

            file = Path.Combine(directoryname, filename);
            string resp = string.Empty;
            using (StreamReader sr = File.OpenText(file))
            {
                resp = sr.ReadToEnd();
            }

            var portalConfig = JObject.Parse(resp);
            var defaultConfig = portalConfig["default"] as JObject;
            if (portalConfig[environment] is JObject envConfig)
            {
                defaultConfig.Merge(envConfig, new JsonMergeSettings()
                {
                    MergeArrayHandling = MergeArrayHandling.Merge,
                    MergeNullValueHandling = MergeNullValueHandling.Merge
                });
            }
            else
            {
                throw new Exception($"Unable to find vendor configuration overrides. Environment: {environment}");
            }

            Dictionary<string, VendorConfiguration> config = defaultConfig.ToObject<Dictionary<string, VendorConfiguration>>();
            return config;

        }



        public bool IsMockRequest(LiensJudgmentsFCRAServiceRequest request, string applicationPlan)
        {
            if (!string.IsNullOrEmpty(applicationPlan) && applicationPlan.ToLower().StartsWith("mock"))
                return true;
            else if (request?.Person?.SSN != null && request.Person.SSN.StartsWith("9"))
                return true;
            else
                return false;
        }

        public async Task<PutObjectResponse> SaveToS3<T>(T document, string bucket, string key, string kmsKeyId, int cacheDays = 0, Dictionary<string, string> metaData = null, LifeSpan lifeSpan = LifeSpan.SevenYears)
        {
            PutObjectResponse response = null;

            try
            {
                response = await AWSAssistant.SaveToS3<T>(_s3Client, document, bucket, key, kmsKeyId, cacheDays, metaData, lifeSpan);
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex, "Failure saving to S3", bucket, key);
                throw;
            }

            return response;
        }

        public async Task<T> SearchS3ByKey<T>(string bucket, string key, bool log404Error = false, int? cacheLimit = null)
        {
            T document = default(T);

            try
            {
                if (cacheLimit == 0)
                {
                    return document;
                }

                document = await AWSAssistant.SearchS3ByKey<T>(_s3Client, bucket, key, log404Error, cacheLimit);
            }
            catch (AmazonS3Exception ex)
            {
                //Some cases 404 is OK like when we are just searching for a key
                if (log404Error || ex.StatusCode != HttpStatusCode.NotFound)
                {
                    _logger.LogS3Error(ex,
                                       cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                       bucket,
                                       key);

                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex,
                                   cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                   bucket,
                                   key);

                throw;
            }

            return document;
        }

        public async Task SaveDynamoDBTransaction<T>(string table, T trans, string hashKey)
        {
            try
            {
                await AWSAssistant.SaveToDynamoDB<T>(_dbContext, table, trans, hashKey);
            }
            catch (Exception ex)
            {
                _logger.LogDynamoError(ex, "Failure saving transaction to DynamoDB", hashKey, table);
                _logger.LogJsonObject<T>(trans);

                throw;
            }
        }

        public async Task<T> GetDynamoDBTransaction<T>(string table, string hashKey)
        {
            T transaction = default(T);

            try
            {
                transaction = await AWSAssistant.GetFromDynamoDB<T>(_dbContext, table, hashKey);
            }
            catch (Exception ex)
            {
                Logger.LogDynamoError(ex, "Failure retrieving transaction from DynamoDB", table);

                throw;
            }

            return transaction;
        }

        public async Task<HealthCheck> RunHealthCheck(string service, string bucket, string table)
        {
            HealthCheck healthCheck = new HealthCheck(service);
            await healthCheck.VerifyS3AndDynamo(_s3Client, bucket, _dbClient, table);
            return healthCheck;
        }

        private List<LiensJudgmentsFCRAServiceResponseLien> MapToServiceResponseLiens(List<Lien> liens)
        {
            if (liens == null || liens.Count == 0)
                return null;

            List<LiensJudgmentsFCRAServiceResponseLien> newLiens = new List<LiensJudgmentsFCRAServiceResponseLien>();
            foreach (var lien in liens)
            {
                newLiens.Add(new LiensJudgmentsFCRAServiceResponseLien()
                {
                    Agency = lien.Agency,
                    AgencyCounty = lien.AgencyCounty,
                    AgencyState = lien.AgencyState,
                    Amount = lien.Amount,
                    DateFiled = lien.DateFiled,
                    DateLastSeen = lien.DateLastSeen,
                    FilingBook = lien.FilingBook,
                    FilingNumber = lien.FilingNumber,
                    FilingPage = lien.FilingPage,
                    LienFilingType = lien.LienType,
                    ReleaseDate = lien.ReleaseDate,
                    Seq = lien.Seq,

                    RecordID = lien.RecordID,
                    LienTypeID = lien.LienTypeID,
                    DefendantAddress = lien.DefendantAddress,
                    AgencyID = lien.AgencyID,
                    ConsumerStatementId = lien.ConsumerStatementId,
                    Defendant = lien.Defendant
                });
            }

            // Order records by most recent.
            if (newLiens.Count > 0)
            {
                newLiens = newLiens.OrderByDescending(x => DateTime.Parse(string.Format("{0}/{1}/{2}", x?.DateFiled?.Month, x?.DateFiled?.Day, x?.DateFiled?.Year))).ToList();
            }

            return newLiens;
        }

        private LexisAddress MapToLexisAddress(Address serviceAddress)
        {
            if (serviceAddress == null)
                return null;

            return new LexisAddress()
            {
                City = serviceAddress.City,
                County = serviceAddress.County,
                Latitude = Convert.ToString(serviceAddress?.Latitude),
                Longitude = Convert.ToString(serviceAddress?.Longitude),
                PostalCode = serviceAddress.PostalCode,
                State = serviceAddress.State,
                StateCityZip = serviceAddress.StateCityZip,
                StreetAddress1 = serviceAddress.StreetAddress1,
                StreetAddress2 = serviceAddress.StreetAddress2,
                StreetName = serviceAddress.StreetName,
                StreetNumber = serviceAddress.StreetNumber,
                StreetPostDirection = serviceAddress.StreetPostDirection,
                StreetPreDirection = serviceAddress.StreetPreDirection,
                StreetSuffix = serviceAddress.StreetSuffix,
                UnitDesignation = serviceAddress.UnitDesignation,
                UnitNumber = serviceAddress.UnitNumber,
                Zip4 = serviceAddress.ZipFour,
                Zip5 = serviceAddress.ZipCode
            };
        }

        public string GetAppPlan(JODIRequest jodiRequest)
        {
            string appPlan = string.Empty;
            string applicationPlan = string.Empty;

            if (jodiRequest.Context != null && jodiRequest.Context.TryGetValue("application-plan", out applicationPlan))
                appPlan = applicationPlan;
            else if (jodiRequest.Params != null && jodiRequest.Params.Header.TryGetValue("application-plan", out applicationPlan))
                appPlan = applicationPlan;

            return applicationPlan;
        }

        public async Task<string> ProcessBase64PDF(string url, string reportType, Dictionary<string, string> orderinfo, LiensJudgmentsFCRAServiceResponse lnjResponse, LiensJudgmentsFCRAServiceRequest lnjRequest)
        {
            Dictionary<string, object> request = new Dictionary<string, object>();
            request.Add("header", "FCRA Liens & Judgments");
            request.Add("subheader", !string.IsNullOrWhiteSpace(lnjRequest.Person?.Name?.Full) ? string.Format("FCRA Liens & Judgment Report for: {0}", lnjRequest.Person?.Name?.Full) : "");
            request.Add("orderinfo", orderinfo);
            request.Add("inputinfo", new Dictionary<string, object>()
            {
                { "Name", lnjRequest.Person?.Name},
                { "Address", lnjRequest.Person?.Address},
                { "SSN", lnjRequest.Person?.SSN}
            });
            request.Add("data", lnjResponse);

            var body = new StringContent(JsonConvert.SerializeObject(request), Encoding.UTF8, "application/json");

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            string pdfReportUrl = string.Format("{0}/pdf/generate/{1}", url, reportType);

            var pdfResponse = await client.PostAsync(pdfReportUrl, body);

            if (!pdfResponse.IsSuccessStatusCode)
            {
                return "Unable to retrieve PDF.";
            }
            else
            {
                return await pdfResponse.Content?.ReadAsStringAsync();
            }
        }

        public async Task<DeleteObjectResponse> DeleteFromS3(string key, string version)
        {
            DeleteObjectResponse response = null;

            try
            {
                response = await _s3Client.DeleteObjectAsync(new DeleteObjectRequest()
                {
                    BucketName = GlobalConfiguration.S3_BUCKET,
                    Key = key,
                    VersionId = version
                });
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex, "Failure deleting from S3. Version=" + version, GlobalConfiguration.S3_BUCKET, key);
                throw;
            }

            return response;
        }

        public async Task LegacyRedact(string s3Key, string version)
        {
            string transactionID = Path.GetFileNameWithoutExtension(s3Key);

            PutObjectResponse s3Response = null;
            UpdateItemResponse dbResponse = null;


            if (s3Key.Contains($"{GlobalConfiguration.SERVICE_REQUEST_FOLDER}/{API_VERSION}"))
            {
                await UpdateTag(s3Key, version, GlobalConfiguration.SERVICE_REDACT_LIFESPAN);

                var rqst = await AWSAssistant.SearchS3ByKey<LiensJudgmentsFCRAServiceRequest>(_s3Client, GlobalConfiguration.S3_BUCKET, s3Key);

                rqst.Redact();

                s3Key = s3Key.Replace(GlobalConfiguration.SERVICE_REQUEST_FOLDER, GlobalConfiguration.REDACTED_SERVICE_REQUEST_FOLDER);

                s3Response = await AWSAssistant.SaveToS3(_s3Client, rqst, GlobalConfiguration.S3_BUCKET, s3Key, GlobalConfiguration.KMS_KEY_ID, 0, lifeSpan: LifeSpan.SevenYears);
                dbResponse = await UpdateDynamo(transactionID, s3Key, "RedactedRequestS3Key");

                if (s3Response.HttpStatusCode != System.Net.HttpStatusCode.OK)
                    throw new Exception($"Failed to save redacted document to s3. s3key={s3Key}");

                if (dbResponse.HttpStatusCode != System.Net.HttpStatusCode.OK)
                    throw new Exception($"Failed to save redacted key to dynamo. s3key={s3Key}");
            }
            else if (s3Key.Contains($"{GlobalConfiguration.VENDOR_REQUEST_FOLDER}/{API_VERSION}"))
            {
                await UpdateTag(s3Key, version, GlobalConfiguration.VENDOR_REDACT_LIFESPAN);
            }
            else if (s3Key.Contains($"{GlobalConfiguration.VENDOR_RESPONSE_FOLDER}/{API_VERSION}"))
            {
                await UpdateTag(s3Key, version, GlobalConfiguration.VENDOR_REDACT_LIFESPAN);
            }
        }

        private async Task<UpdateItemResponse> UpdateDynamo(string transactionID, string s3Key, string fieldName)
        {
            var request = new UpdateItemRequest
            {
                TableName = GlobalConfiguration.DYNAMO_TABLE,
                Key = new Dictionary<string, AttributeValue>() { { "TransactionID", new AttributeValue { S = transactionID } } },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                {
                    {":rsk",new AttributeValue {S = s3Key}},
                },

                UpdateExpression = "SET " + fieldName + " = :rsk"
            };

            return await _dbClient.UpdateItemAsync(request);
        }

        private async Task<PutObjectTaggingResponse> UpdateTag(string s3Key, string version, string lifespan)
        {
            //TODO: add version?
            List<Amazon.S3.Model.Tag> tag = new List<Amazon.S3.Model.Tag>()
            {
                new Amazon.S3.Model.Tag()
                {
                    Key = "LifeSpan",
                    Value = lifespan
                }
            };

            return await _s3Client.PutObjectTaggingAsync(new PutObjectTaggingRequest()
            {
                BucketName = GlobalConfiguration.S3_BUCKET,
                Key = s3Key,
                VersionId = version,
                Tagging = new Tagging() { TagSet = tag }
            });
        }







    }

}

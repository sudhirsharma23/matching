﻿using Amazon.DynamoDBv2;
using Amazon.Lambda.Core;
using Amazon.S3;
using Amazon.SecretsManager.Extensions.Caching;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.LiensJudgmentsFCRAService.v1.Models.Service;
using FAMS.LiensJudgmentsFCRAService.v1.Models.Vendor;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace FAMS.LiensJudgmentsFCRAService.v1
{
    public class API
    {
        static ConcurrentDictionary<string, HttpClient> HttpClients;
        static object HttpClientLock = new object();

        static List<Method> MethodLookup;
        static object MethodLock = new object();

        LoggingAssistant Logger;
        UseCase UseCase;
        const string API_VERSION = "v1";


        #region Constructors
        public API()
        {
            UseCase = new UseCase();
            InitializeHttpClient();
        }


        //Used for testing purposes
        public API(IAmazonS3 s3Client, IAmazonDynamoDB dbClient, SecretsManagerCache secretsClient)
        {
            UseCase = new UseCase(s3Client, dbClient, secretsClient);
            InitializeHttpClient();
        }
        #endregion

        #region Function Handlers
        /// <summary>
        /// Routing handler for the lambda functions.  This is the one method that the lambda will call directly, then based on HTTP Method and URI, this method will invoke the correct function to call.
        /// </summary>
        /// <param name="jodiRequest">Stream of JODIRequest. Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>Stream of JODI response.  The service response is b64 encoded in the body </returns>
        public async Task<Stream> RouteHandler(Stream jodiRequestStream, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            JODIRequest request = null;
            JODIResponse response = null;
            MemoryStream responseStream = new MemoryStream();


            try
            {
                request = SerializationAssistant.DeserializeJson<JODIRequest>(jodiRequestStream);

                if (request == null)
                    throw new Exception("Unable to deserialize to JODIRequest object.");
                UseCase.InitializeUseCase(request, context);

                Logger = UseCase.Logger;
                InitializeMethodLookup();
                Method method = JODIAssistant.FindMethod(MethodLookup, request);

                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},Supported Methods=GET,POST",
                                                         UseCase?.RequestMetaData?.Path,
                                                        string.Join(",", MethodLookup.Select(a => a.Path)),
                                                         UseCase?.RequestMetaData?.HttpMethod);
                    throw new Exception(errorMsg);
                }

                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                responseStream.Position = 0;

                return responseStream;
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex,
                                       string.Format("Failure in the RouteHandler. JODIRequest={0}", JODIAssistant.StreamToJson(jodiRequestStream)),
                                       FunctionTimer.ElapsedMilliseconds);

                string accept = string.Empty, contentType = string.Empty;
                request?.Params?.Header?.TryGetValue("accept", out accept);
                request?.Params?.Header?.TryGetValue("content-type", out contentType);
                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                response = CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, UseCase?.RequestMetaData?.TransactionID);
                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                return responseStream;
            }
            finally
            {
                FunctionTimer.Stop();
                if (GlobalConfiguration.LOG_JODI)
                {
                    Logger.LogJsonObject<JODIRequest>(request);
                    Logger.LogJsonObject<JODIResponse>(response);
                }
                Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }

        /// <summary>
        /// GET - retrieve vendor response by Company ID & Transaction ID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> GetHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string transactionID = string.Empty;
            string accept = string.Empty;
            LiensJudgmentsFCRAServiceResponse response = null;

            try
            {
                accept = UseCase?.RequestMetaData?.Accept;
                jodiRequest.Params.QueryString.TryGetValue("transactionID", out transactionID);
                var ljTrans = await UseCase.GetDynamoDBTransaction<TransactionKey>(GlobalConfiguration.DYNAMO_TABLE, transactionID);

                if (ljTrans == null ||
                    string.IsNullOrEmpty(ljTrans.ResponseS3Key) ||
                    !ljTrans.GlobalID.Equals(UseCase?.RequestMetaData?.GlobalID, StringComparison.OrdinalIgnoreCase) ||
                    ljTrans.HttpStatus != 200)
                {
                    return new JODIResponse() { HttpStatus = (int)HttpStatusCode.NotFound };
                }

                response = await UseCase.SearchS3ByKey<LiensJudgmentsFCRAServiceResponse>(GlobalConfiguration.S3_BUCKET, ljTrans.ResponseS3Key, true);

                //if accept isn't a valid content type, set accept to content type of response saved in S3
                accept = JODIAssistant.SetValidAcceptType(accept, ljTrans.ResponseS3Key);

                if (response == null)
                    throw new Exception(string.Format("Service Response not found in S3. Key={0},Bucket={1}", ljTrans.ResponseS3Key, GlobalConfiguration.S3_BUCKET));
                else
                {
                    if (!UseCase.RequestMetaData.Diagnostics)
                    {
                        response.Diagnostics = null;
                    }

                    return new JODIResponse()
                    {
                        ContentType = accept,
                        HttpStatus = (int)HttpStatusCode.OK,
                        ResponseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsFCRAServiceResponse>(accept, response)
                    };
                }
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the GetHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)HttpStatusCode.InternalServerError, accept, UseCase?.RequestMetaData?.TransactionID);
            }
            finally
            {
                FunctionTimer.Stop();
                Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }

        /// <summary>
        /// GET - retrieve pdf vendor response by Company ID & Transaction ID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> GetPdfHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string transactionID = string.Empty;
            string accept = string.Empty;

            LiensJudgmentsFCRAServiceRequest request = null;
            LiensJudgmentsFCRAServiceResponse response = null;

            try
            {
                accept = JODIAssistant.SetValidAcceptType(UseCase?.RequestMetaData?.Accept, string.Empty);
                jodiRequest.Params.QueryString.TryGetValue("transactionID", out transactionID);
                var ljTrans = await UseCase.GetDynamoDBTransaction<TransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transactionID);

                if (ljTrans == null ||
                    string.IsNullOrEmpty(ljTrans.ResponseS3Key) ||
                    !ljTrans.GlobalID.Equals(UseCase?.RequestMetaData?.GlobalID, StringComparison.OrdinalIgnoreCase) ||
                    ljTrans.HttpStatus != 200)
                {
                    return new JODIResponse() { HttpStatus = (int)HttpStatusCode.NotFound };
                }

                List<Task> task = new List<Task>();

                var responseTask = UseCase.SearchS3ByKey<LiensJudgmentsFCRAServiceResponse>(GlobalConfiguration.S3_BUCKET, ljTrans.ResponseS3Key, true);
                var requestTask = UseCase.SearchS3ByKey<LiensJudgmentsFCRAServiceRequest>(GlobalConfiguration.S3_BUCKET, ljTrans.RedactedRequestS3Key, true);

                List<Task> tasks = new List<Task>()
                {
                    { responseTask }, { requestTask }
                };

                await Task.WhenAll(task.ToList());

                response = responseTask.Result;
                request = requestTask.Result;

                //if accept isn't a valid content type, set accept to content type of response saved in S3
                accept = JODIAssistant.SetValidAcceptType(accept, ljTrans.ResponseS3Key);

                if (response == null)
                    throw new Exception(string.Format("Service Response not found in S3. Key={0},Bucket={1}", ljTrans.ResponseS3Key, GlobalConfiguration.S3_BUCKET));
                else
                {
                    var orderinfo = new Dictionary<string, string>()
                    {
                        { "Name", UseCase?.RequestMetaData?.CompanyName },
                        { "ReferenceNumber", transactionID }
                    };

                    var pdfResponse = await UseCase.ProcessBase64PDF(GlobalConfiguration.PDF_UTILITY_URL, PDFReport.liensandjudgments_fcra.ToString(), orderinfo, response, request);

                    return new JODIResponse()
                    {
                        ContentType = accept,
                        HttpStatus = (int)HttpStatusCode.OK,
                        ResponseBody = JODIAssistant.SerializeBodyToB64(accept, pdfResponse)
                    };
                }
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the GetPdfHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)HttpStatusCode.InternalServerError, accept, UseCase?.RequestMetaData?.TransactionID);
            }
            finally
            {
                FunctionTimer.Stop();

                Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }

        /// <summary>
        /// POST - make request to vendor and map to service response
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. The actual service request is b64 encoded in the  body</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> PostHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            RiskView2ResponseEnvelope lexisResponse = null;
            LiensJudgmentsFCRAServiceResponse serviceResponse = null;

            HttpResponseMessage httpResponse = null;
            VendorCall vendorCall = null;
            bool savingToDB = false;

            TransactionKey ljTrans = new TransactionKey();

            LiensJudgmentsFCRAServiceRequest request = UseCase.GetServiceRequestFromJODI<LiensJudgmentsFCRAServiceRequest>(jodiRequest, FunctionTimer);
            VendorConfiguration vendorConfig = null;
            try
            {

                string serviceFileType = JODIAssistant.GetFileType(jodiRequest.BodyType).ToString().ToLower();
                string vendorFileType = "json";


                ljTrans.TransactionID = UseCase?.RequestMetaData?.TransactionID;

                if (request == null)
                    return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, UseCase?.RequestMetaData?.Accept, UseCase?.RequestMetaData?.TransactionID);

                ljTrans.CompanyName = UseCase?.RequestMetaData?.CompanyName;
                ljTrans.AppPlan = UseCase?.RequestMetaData?.ApplicationPlan;
                ljTrans.RequestorID = request?.RequestorID;
                ljTrans.ClientID = UseCase?.RequestMetaData?.ClientID;
                ljTrans.GlobalID = UseCase?.RequestMetaData?.GlobalID;
                ljTrans.PortalCode = UseCase?.RequestMetaData?.PortalCode;
                ljTrans.ServiceName = GlobalConfiguration.SERVICE_ZONE_NAME;

                ljTrans.RequestS3Key = UseCase.BuildS3Key(GlobalConfiguration.SERVICE_REQUEST_FOLDER, API_VERSION, ljTrans.TransactionID, serviceFileType);
                await UseCase.SaveToS3<LiensJudgmentsFCRAServiceRequest>(request, GlobalConfiguration.S3_BUCKET, ljTrans.RequestS3Key, GlobalConfiguration.KMS_KEY_ID, lifeSpan: LifeSpan.OneHundredEightyDays);

                var validationErrorResponse = UseCase.BuildValidationErrorResponse(request, ljTrans, FunctionTimer);
                if (validationErrorResponse != null)
                    return validationErrorResponse;

                if (UseCase.IsMockRequest(request, UseCase?.RequestMetaData?.ApplicationPlan))
                {
                    ljTrans.DataSource = DataSource.Mock.ToString();

                    //check for mock by mock key
                    lexisResponse = await UseCase.GetMockedResponseFromS3(GlobalConfiguration.S3_BUCKET,
                                                                          UseCase.BuildS3Key(GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, UseCase.ComputeMockKey(request.Person), vendorFileType));

                    //no mock response found(expired or never created)
                    if (lexisResponse == null)
                    {
                        ljTrans.HttpStatus = (int)HttpStatusCode.NotFound;
                        return new JODIResponse()
                        {
                            HttpStatus = (int)HttpStatusCode.NotFound
                        };
                    }
                }
                else
                {
                    RiskView2RequestEnvelope lexisRequest = UseCase.MapServiceRequestToVendorRequest(request, ljTrans.TransactionID, ljTrans.PortalCode, request.IntendedPurpose);
                    ljTrans.CacheKey = UseCase.ComputeCacheKey(ljTrans.GlobalID, request.Person);

                    Dictionary<string, VendorConfiguration> serviceConfig = UseCase.GetVendorConfiguration();

                    if (serviceConfig == null)
                        throw new Exception(string.Format("No service configuration file found. Bucket={0},Folder={1},PortalCode={2}", GlobalConfiguration.S3_BUCKET, GlobalConfiguration.VENDOR_CONFIG_FOLDER, ljTrans.PortalCode));

                    vendorConfig = serviceConfig?.Values?.Where(x => x.Priority == 1)?.FirstOrDefault();
                    await UseCase.GetVendorCredentials(vendorConfig);

                    //check cache
                    var cacheLimit = request.CachePeriod != null ? request.CachePeriod : vendorConfig.CachePeriodDays;

                    lexisResponse = await UseCase.SearchS3ByKey<RiskView2ResponseEnvelope>(GlobalConfiguration.S3_BUCKET, UseCase.BuildS3Key(GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, ljTrans.CacheKey, vendorFileType), false, cacheLimit);

                    //no cache, make vendor call
                    if (lexisResponse == null)
                    {
                        ljTrans.DataSource = DataSource.Vendor.ToString();

                        vendorCall = new VendorCall
                        {
                            Name = vendorConfig.VendorName + " " + vendorConfig.VendorProduct,
                            Sequence = 1,
                            RequestS3Key = UseCase.BuildS3Key(GlobalConfiguration.VENDOR_REQUEST_FOLDER, API_VERSION, ljTrans.CacheKey, vendorFileType),
                            DateTimeUTC = DateTime.UtcNow
                        };

                        await UseCase.SaveToS3<RiskView2RequestEnvelope>(lexisRequest, GlobalConfiguration.S3_BUCKET, vendorCall.RequestS3Key, GlobalConfiguration.KMS_KEY_ID, vendorConfig.CachePeriodDays, null, LifeSpan.NinetyDays);

                        if (!string.IsNullOrWhiteSpace(vendorConfig?.Login) && !string.IsNullOrWhiteSpace(vendorConfig?.Password))
                        {
                            HttpClient client = UseCase.InitializeHttpClient(HttpClients, vendorConfig, UseCase?.RequestMetaData?.PortalCode);
                            httpResponse = await UseCase.CallVendor(client, lexisRequest, vendorConfig.URL, vendorCall);
                            vendorCall.HttpStatus = (int)httpResponse.StatusCode;
                            vendorCall.ResponseS3Key = UseCase.BuildS3Key(GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, ljTrans.CacheKey, vendorFileType);


                            //always save vendor response.
                            string content = await httpResponse?.Content?.ReadAsStringAsync();
                            if (httpResponse.IsSuccessStatusCode)
                            {
                                lexisResponse = SerializationAssistant.DeserializeJson<RiskView2ResponseEnvelope>(content);
                                await UseCase.SaveToS3<RiskView2ResponseEnvelope>(lexisResponse, GlobalConfiguration.S3_BUCKET, vendorCall.ResponseS3Key, GlobalConfiguration.KMS_KEY_ID, vendorConfig.CachePeriodDays, null, LifeSpan.NinetyDays);
                            }
                            else
                            {
                                await UseCase.SaveToS3<string>(content, GlobalConfiguration.S3_BUCKET, vendorCall.ResponseS3Key, GlobalConfiguration.KMS_KEY_ID, vendorConfig.CachePeriodDays, null, LifeSpan.NinetyDays);
                                UseCase.Errors = "Invalid Vendor Response";

                            }
                        }
                    }
                    else //found cached response
                    {
                        ljTrans.DataSource = DataSource.Cache.ToString();
                    }
                }

                //create the service response from vendor or mocked response
                serviceResponse = UseCase.CreateServiceResponse(lexisResponse, ljTrans, vendorConfig, FunctionTimer.ElapsedMilliseconds);

                ljTrans.ResponseS3Key = UseCase.BuildS3Key(GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION, ljTrans.TransactionID, serviceFileType);
                ljTrans.HttpStatus = (int)HttpStatusCode.OK;
                await UseCase.SaveToS3<LiensJudgmentsFCRAServiceResponse>(serviceResponse, GlobalConfiguration.S3_BUCKET, ljTrans.ResponseS3Key, GlobalConfiguration.KMS_KEY_ID);

                //save redacted request to s3. no redacted response as no NPI
                ljTrans.RedactedRequestS3Key = UseCase.BuildS3Key(GlobalConfiguration.REDACTED_SERVICE_REQUEST_FOLDER, API_VERSION, ljTrans.TransactionID, serviceFileType);
                request.Redact();
                await UseCase.SaveToS3<LiensJudgmentsFCRAServiceRequest>(request, GlobalConfiguration.S3_BUCKET, ljTrans.RedactedRequestS3Key, GlobalConfiguration.KMS_KEY_ID);


                //save transaction record to DB
                FunctionTimer.Stop();
                ljTrans.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                ljTrans.DateTimeUTC = DateTime.UtcNow;
                ljTrans.VendorCalls = vendorCall != null ? new List<VendorCall> { vendorCall } : null;

                savingToDB = true;
                await UseCase.SaveDynamoDBTransaction<TransactionKey>(GlobalConfiguration.DYNAMO_TABLE, ljTrans, ljTrans.TransactionID);


                //create JODI response
                return new JODIResponse()
                {
                    ContentType = UseCase?.RequestMetaData?.Accept,
                    HttpStatus = ljTrans.HttpStatus,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsFCRAServiceResponse>(UseCase?.RequestMetaData?.Accept, serviceResponse)
                };
            }
            catch (Exception ex)
            {
                FunctionTimer.Stop();
                ljTrans.HttpStatus = (int)HttpStatusCode.InternalServerError;
                ljTrans.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                ljTrans.DateTimeUTC = DateTime.UtcNow;
                ljTrans.VendorCalls = vendorCall != null ? new List<VendorCall> { vendorCall } : null;

                try
                {
                    //try to save transaction as long as we didnt fail on the save in the original try block
                    if (!savingToDB)
                        await UseCase.SaveDynamoDBTransaction<TransactionKey>(GlobalConfiguration.DYNAMO_TABLE, ljTrans, ljTrans.TransactionID);

                    return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, UseCase?.RequestMetaData?.Accept, ljTrans.TransactionID);
                }
                finally
                {
                    Logger.LogServiceError(ex, "Failure in the PostHandler", FunctionTimer.ElapsedMilliseconds);
                }
            }
            finally
            {
                Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }


        /// <summary>
        /// A simple health check(check S3/Dynamo are active + make echotest call to vendor)
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the health check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse> HealthCheckHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            UseCase.RequestMetaData.SetPortalCode("api");
            string contentType = "application/json";

            try
            {
                HealthCheck healthCheck = await UseCase.RunHealthCheck(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.S3_BUCKET, GlobalConfiguration.DYNAMO_TABLE);

                Dictionary<string, VendorConfiguration> serviceConfig = UseCase.GetVendorConfiguration();

                if (serviceConfig == null)
                    throw new Exception(string.Format("No service configuration file found. Bucket={0},Folder={1},PortalCode={2}", GlobalConfiguration.S3_BUCKET, GlobalConfiguration.VENDOR_CONFIG_FOLDER, UseCase?.RequestMetaData.PortalCode));

                if (serviceConfig.Values != null)
                {
                    foreach (var vendorConfig in serviceConfig.Values)
                    {
                        HealthCheckComponent vendorComponent = new HealthCheckComponent()
                        {
                            Name = vendorConfig.VendorCode,
                            Type = ComponentType.Vendor
                        };


                        await UseCase.GetVendorCredentials(vendorConfig);
                        if (vendorConfig == null)
                        {
                            vendorComponent.Status = ComponentStatus.Red;
                            vendorComponent.Information = new Dictionary<string, string>()
                            {
                                {"Error", $"No vendor configuration found in service config. Bucket={GlobalConfiguration.S3_BUCKET},Folder={GlobalConfiguration.VENDOR_CONFIG_FOLDER},PortalCode={UseCase.RequestMetaData.PortalCode}" }
                            };
                        }
                        else
                        {
                            //vendor test
                            var echoRqstEnvelope = new EchoTestRequestEnvelope()
                            {
                                EchoTestRequest = new EchoTestRequest()
                                {
                                    ValueIn = "ECHO"
                                }
                            };

                            HttpClient client = UseCase.InitializeHttpClient(HttpClients, vendorConfig, UseCase.RequestMetaData.PortalCode);
                            Stopwatch s1 = new Stopwatch();
                            s1.Start();
                            HttpResponseMessage response = await UseCase.CallVendor(client, echoRqstEnvelope, vendorConfig.Configurations["HealthcheckURL"].ToString());
                            s1.Stop();
                            string content = await response.Content.ReadAsStringAsync();

                            vendorComponent.Information = new Dictionary<string, string>()
                                {
                                    {"URL", vendorConfig.Configurations["HealthcheckURL"].ToString() },
                                    {"ResponseStatus", ((int)response.StatusCode).ToString() },
                                    {"ResponseTimeMS", s1.ElapsedMilliseconds.ToString() },
                                };


                            if (!response.IsSuccessStatusCode)
                            {
                                vendorComponent.Status = ComponentStatus.Red;
                                vendorComponent.Information.Add("Error", $"Error communicating with vendor. Status={(int)response.StatusCode},Message={response.ReasonPhrase}");
                            }
                            else
                            {
                                EchoTestResponseEnvelope echoResponse = SerializationAssistant.DeserializeJson<EchoTestResponseEnvelope>(content);

                                string valueOut = echoResponse?.EchoTestResponse?.ValueOut;

                                if (string.IsNullOrEmpty(valueOut) || !valueOut.Equals(echoRqstEnvelope.EchoTestRequest.ValueIn))
                                {
                                    vendorComponent.Status = ComponentStatus.Red;
                                    vendorComponent.Information.Add("Error", $"Echo Test results doesn't match up.ValueIn={echoRqstEnvelope.EchoTestRequest.ValueIn},ValueOut={valueOut}");

                                }
                                else if (echoResponse.EchoTestResponse.ValueOut.Equals(echoRqstEnvelope.EchoTestRequest.ValueIn))
                                    vendorComponent.Status = ComponentStatus.Green;
                            }
                        }

                        healthCheck.Components.TryAdd("VendorCall", vendorComponent);


                        if (vendorComponent.Status == ComponentStatus.Red)
                            healthCheck.ServiceStatus = ComponentStatus.Red;
                    }
                }


                return new JODIResponse()
                {
                    HttpStatus = healthCheck.ServiceStatus == ComponentStatus.Red ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK,
                    ContentType = "application/json",
                    ResponseBody = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, healthCheck)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Health check failed", -1);
                string requestID = string.Empty;
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, requestID);
            }
        }

        /// <summary>
        /// A simple ping check
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the ping check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>An empty JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse> PingHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            return JODIAssistant.SetPingTestResponse();
        }

        /// <summary>
        /// Creates mock vendor responses and returns back the service request to get that mock response.
        /// </summary>
        /// <param name="request">A service mock object containing the service request + mocked vendor response</param>
        /// <param name="context"></param>
        /// <returns>The service request that was passed in. This will be used as the body of the POST request to the service.</returns>
        private async Task<JODIResponse> PostMockHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string requestID = string.Empty;
            jodiRequest?.Context?.TryGetValue("request-id", out requestID);
            string contentType = "application/json";

            LiensJudgmentsFCRAServiceMock request = UseCase.GetServiceRequestFromJODI<LiensJudgmentsFCRAServiceMock>(jodiRequest, FunctionTimer);

            if (request == null)
                return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, contentType, requestID);

            try
            {
                var vendorFileType = "json"; //vendor always json

                string mockKey = UseCase.ComputeMockKey(request.MockServiceRequest.Person);

                //saving as string so we can submit malformed JSON for testing purposes
                var mockVendorResponse = await UseCase.SaveToS3<string>(request.MockVendorResponse,
                                                                        GlobalConfiguration.S3_BUCKET,
                                                                        UseCase.BuildS3Key(GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, mockKey, vendorFileType),
                                                                        GlobalConfiguration.KMS_KEY_ID);

                //create JODI response
                return new JODIResponse()
                {
                    ContentType = contentType,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsFCRAServiceRequest>(contentType, request.MockServiceRequest)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the PostMockHandler", FunctionTimer.ElapsedMilliseconds);
                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, requestID);
            }
            finally
            {
                FunctionTimer.Stop();
            }
        }

        private async Task<JODIResponse> RedactHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string contentType = "application/json";

            LiensJudgmentsFCRAServiceRedaction request = UseCase.GetServiceRequestFromJODI<LiensJudgmentsFCRAServiceRedaction>(jodiRequest, FunctionTimer);

            if (request == null)
                return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, contentType, UseCase.RequestMetaData.TransactionID);

            try
            {
                if (request.IsLatest)
                    await UseCase.LegacyRedact(request.S3Key, request.VersionID);
                else
                    await UseCase.DeleteFromS3(request.S3Key, request.VersionID);

                //create JODI response
                return new JODIResponse()
                {
                    HttpStatus = (int)HttpStatusCode.OK
                };
            }
            catch (Exception ex)
            {
                UseCase.Logger.LogServiceError(ex, "Failure in the RedactHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, UseCase.RequestMetaData.TransactionID);
            }
            finally
            {
                FunctionTimer.Stop();
            }
        }

        public async Task<JODIResponse> DebugHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch functionTimer = new Stopwatch();
            functionTimer.Start();

            JODIResponse response = null;
            string transactionID = string.Empty;

            try
            {
                jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);

                if (string.IsNullOrEmpty(transactionID))
                    return CreateJODIErrorResponse("transactionID is empty in query string.", 400, UseCase.RequestMetaData.Accept, string.Empty);

                TransactionRecord<VendorCall> transactionRecord = await UseCase.GetDynamoDBTransaction<TransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transactionID);
                if (transactionRecord == null)
                    return CreateJODIErrorResponse("Order not found.", 404, UseCase.RequestMetaData.Accept, string.Empty);

                List<Task> taskList = new List<Task>();
                var serviceRequestTask = UseCase.SearchS3ByKey<LiensJudgmentsFCRAServiceRequest>(GlobalConfiguration.S3_BUCKET, transactionRecord.RequestS3Key);
                var serviceResponseTask = UseCase.SearchS3ByKey<LiensJudgmentsFCRAServiceResponse>(GlobalConfiguration.S3_BUCKET, transactionRecord.ResponseS3Key);

                Task<LiensJudgmentsFCRAServiceRequest> redactedServiceRequestTask = null;

                if (!string.IsNullOrEmpty(transactionRecord.RedactedRequestS3Key))
                {
                    redactedServiceRequestTask = UseCase.SearchS3ByKey<LiensJudgmentsFCRAServiceRequest>(GlobalConfiguration.S3_BUCKET, transactionRecord.RedactedRequestS3Key);
                    taskList.Add(redactedServiceRequestTask);
                }

                VendorCall vendorCall = transactionRecord?.VendorCalls?.FirstOrDefault();
                Task<RiskView2RequestEnvelope> vendorRequestTask = null;
                Task<RiskView2ResponseEnvelope> vendorResponseTask = null;

                if (vendorCall?.RequestS3Key != null)
                {
                    vendorRequestTask = UseCase.SearchS3ByKey<RiskView2RequestEnvelope>(GlobalConfiguration.S3_BUCKET, vendorCall.RequestS3Key);
                    taskList.Add(vendorRequestTask);
                }

                if (vendorCall?.ResponseS3Key != null)
                {
                    vendorResponseTask = UseCase.SearchS3ByKey<RiskView2ResponseEnvelope>(GlobalConfiguration.S3_BUCKET, vendorCall.ResponseS3Key);
                    taskList.Add(vendorResponseTask);
                }

                taskList.Add(serviceRequestTask);
                taskList.Add(serviceResponseTask);

                await Task.WhenAll(taskList);

                var debugResponse = new LiensJudgmentsFCRADebug()
                {
                    ServiceRequest = serviceRequestTask?.Result,
                    ServiceResponse = serviceResponseTask?.Result,
                    RedactedServiceRequest = redactedServiceRequestTask?.Result,
                    TransactionRecord = transactionRecord,
                    VendorRequest = vendorRequestTask?.Result,
                    VendorResponse = vendorResponseTask?.Result
                };

                //create JODI response
                return new JODIResponse()
                {
                    ContentType = UseCase.RequestMetaData.Accept,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsFCRADebug>(UseCase.RequestMetaData.Accept, debugResponse)
                };
            }
            catch (Exception ex)
            {
                UseCase.Logger.LogServiceError(ex, $"Failure in the DebugHandler. TransactionID={transactionID}", functionTimer.ElapsedMilliseconds);

                response = CreateJODIErrorResponse("An error has occurred.", 500, UseCase.RequestMetaData.Accept, UseCase.RequestMetaData.TransactionID);
            }
            finally
            {
                UseCase.Logger.LogFunctionExecutionTime(functionTimer.ElapsedMilliseconds);
            }

            return response;
        }




        #endregion

        #region Private Methods
        private void InitializeHttpClient()
        {
            if (HttpClients == null)
            {
                lock (HttpClientLock)
                {
                    if (HttpClients == null)
                    {
                        HttpClients = new ConcurrentDictionary<string, HttpClient>();
                    }
                }
            }
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        MethodLookup = new List<Method>();

                        Method getMethod = new Method
                        {
                            InvokeFunction = GetHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/report$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(getMethod);

                        Method getPdfMethod = new Method
                        {
                            InvokeFunction = GetPdfHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/report/pdf$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(getPdfMethod);

                        Method postMethod = new Method
                        {
                            InvokeFunction = PostHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/order$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(postMethod);

                        Method healthMethod = new Method
                        {
                            InvokeFunction = HealthCheckHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/health$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(healthMethod);

                        Method mockMethod = new Method
                        {
                            InvokeFunction = PostMockHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/mock$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(mockMethod);

                        Method pingMethod = new Method
                        {
                            InvokeFunction = PingHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/ping$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(pingMethod);

                        Method redactMethod = new Method
                        {
                            InvokeFunction = RedactHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/redact", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(redactMethod);

                        Method debugMethod = new Method
                        {
                            InvokeFunction = DebugHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/debug", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(debugMethod);
                    }
                }
            }

        }

        private JODIResponse CreateJODIErrorResponse(string errorMsg, int statusCode, string contentType, string transactionID)
        {
            return new JODIResponse()
            {
                ContentType = contentType,
                ErrorMessage = new JODIErrorResponse()
                {
                    Error = string.Format("{0}  TransactionID={1}", errorMsg, transactionID),
                    HttpStatus = statusCode
                }
            };
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public static  class GlobalConfiguration
    {
        public static readonly string S3_BUCKET = Environment.GetEnvironmentVariable("S3_BUCKET");
        public static readonly string DYNAMO_TABLE = Environment.GetEnvironmentVariable("DYNAMODB_TABLE");
        public static readonly string KMS_KEY_ID = Environment.GetEnvironmentVariable("KMS_KEY_ID");
        public static readonly bool LOG_JODI = Environment.GetEnvironmentVariable("LOG_JODI").Equals("true", StringComparison.OrdinalIgnoreCase) ? true : false;
        public static readonly string SERVICE_ZONE_NAME = Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME");
        public static readonly string KEEP_WARM_CLOUDWATCH_EVENT_RULE = Environment.GetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE");
        public static readonly string ENVIRONMENT = Environment.GetEnvironmentVariable("ENVIRONMENT");
        public static readonly string PDF_UTILITY_URL = Environment.GetEnvironmentVariable("PDF_UTILITY_URL");


        public static readonly string SERVICE_REQUEST_FOLDER = string.Format("{0}/ServiceRequests", SERVICE_ZONE_NAME);
        public static readonly string REDACTED_SERVICE_REQUEST_FOLDER = string.Format("{0}/RedactedServiceRequests", SERVICE_ZONE_NAME);
        public static readonly string SERVICE_RESPONSE_FOLDER = string.Format("{0}/ServiceResponses", SERVICE_ZONE_NAME);
        public static readonly string VENDOR_REQUEST_FOLDER = string.Format("{0}/VendorRequests", SERVICE_ZONE_NAME);
        public static readonly string VENDOR_RESPONSE_FOLDER = string.Format("{0}/VendorResponses", SERVICE_ZONE_NAME);
        public static readonly string MOCK_RESPONSE_FOLDER = string.Format("{0}/MockResponses", SERVICE_ZONE_NAME);
        public static readonly string VENDOR_CONFIG_FOLDER = string.Format("{0}/VendorConfigurations", SERVICE_ZONE_NAME);

        public static readonly string VENDOR_REDACT_LIFESPAN = "90d";
        public static readonly string SERVICE_REDACT_LIFESPAN = "180d";

    }
}

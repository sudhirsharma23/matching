﻿using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.LiensJudgmentsFCRAService.v1.Models.Vendor;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public class LiensJudgmentsFCRAServiceResponse : IAlertResponse
    {
        public string TransactionID { get; set; }
        public string RequestorID { get; set; }
        public ResultType Result { get; set; }
        [XmlArrayItem("Lien")]
        public List<LiensJudgmentsFCRAServiceResponseLien> Liens { get; set; }
        public List<Judgment> Judgments { get; set; }
        public List<LnJAttribute> LnJAttributes { get; set; }
        public List<FAMS.Common.API.Models.Infrastructure.Alert> Alerts { get; set; }
        public string Base64PDF { get; set; }
        public Diagnostic Diagnostics { get; set; }
        public string DeferredTransactionID { get; set; }


    }


    public class LiensJudgmentsFCRAServiceResponseLien
    {
        public string Seq { get; set; }
        public string RecordID { get; set; } //new
        public ParsedDate DateFiled { get; set; }
        public string LienTypeID { get; set; } //new
        public string LienFilingType { get; set; }
        public string Amount { get; set; }
        public ParsedDate ReleaseDate { get; set; }
        public ParsedDate DateLastSeen { get; set; }
        public string Defendant { get; set; }//new
        public LexisAddress DefendantAddress { get; set; } //new
        public string FilingNumber { get; set; }
        public string FilingBook { get; set; }
        public string FilingPage { get; set; }
        public string Agency { get; set; }
        public string AgencyCounty { get; set; }
        public string AgencyState { get; set; }
        public string AgencyID { get; set; } //new
        public string ConsumerStatementId { get; set; } //new
    }
    public class Diagnostic
    {
        public string VendorURL { get; set; }
        public string VendorCode { get; set; }
        public string VendorLogin { get; set; }
        public int? VendorCallStatus { get; set; }

        public long? VendorResponseTime { get; set; }
        public string Message { get; set; }
        public string DataSource { get; set; }
    }
}

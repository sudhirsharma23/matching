﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public enum ResultType
    {
        SubjectNotFound = -1,
        NoRecordsFound = 0,
        RecordsFound = 1,
        StatusRefresh = 2
    }
}

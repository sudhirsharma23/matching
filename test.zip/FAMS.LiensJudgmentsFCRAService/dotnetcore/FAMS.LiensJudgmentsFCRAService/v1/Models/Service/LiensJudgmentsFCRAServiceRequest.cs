﻿using FAMS.Common.API.Models;
using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public class LiensJudgmentsFCRAServiceRequest : IAlertRequest
    {
        public string RequestorID { get; set; }
        public string IntendedPurpose { get; set; }
        public Person Person { get; set; }
        public bool IncludeFiltering { get; set; }
        public int? CachePeriod { get; set; }

        public bool IncludeAnalytics { get; set; }
        public SerializableDictionary<string, object> AnalyticsInput { get; set; }

        public void Redact()
        {
            if (!string.IsNullOrEmpty(Person?.SSN))
                Person.SSN = Mask(Person.SSN);

            if (Person?.DOB != null)
                Person.DOB = MaskDate(Person.DOB);

            if (!string.IsNullOrEmpty(Person?.DriversLicense?.LicenseNumber))
                Person.DriversLicense.LicenseNumber = Mask(Person.DriversLicense.LicenseNumber);
        }

        private ParsedDate MaskDate(ParsedDate dob)
        {
            if (dob == null)
                return null;

            return new ParsedDate()
            {
                Day = null,
                Month = null,
                Year = dob.Year
            };
        }

        private string Mask(string dl)
        {
            if (string.IsNullOrWhiteSpace(dl))
                return null;

            string lastFour = dl.Substring(dl.Length - 4, 4);

            return lastFour.PadLeft(dl.Length, 'X');
        }
    }

    public enum PDFReport
    {
        liensandjudgments_fcra
    }


}

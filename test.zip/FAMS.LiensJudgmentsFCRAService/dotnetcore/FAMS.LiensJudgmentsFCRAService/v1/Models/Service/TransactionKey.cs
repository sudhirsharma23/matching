﻿using FAMS.Common.API.Models.Infrastructure;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public class TransactionKey : TransactionRecord<VendorCall>
    {
        public string DeferredTransactionID { get; set; }
    }
}

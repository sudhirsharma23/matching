﻿using FAMS.Common.API.Models.Infrastructure;
using FAMS.LiensJudgmentsFCRAService.v1.Models.Vendor;
using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public class LiensJudgmentsFCRADebug
    {
        public TransactionRecord<VendorCall> TransactionRecord { get; set; }
        public LiensJudgmentsFCRAServiceRequest ServiceRequest { get; set; }
        public LiensJudgmentsFCRAServiceResponse ServiceResponse { get; set; }
        public LiensJudgmentsFCRAServiceRequest RedactedServiceRequest { get; set; }
        public RiskView2RequestEnvelope VendorRequest { get; set; }
        public RiskView2ResponseEnvelope VendorResponse { get; set; }
    }
}

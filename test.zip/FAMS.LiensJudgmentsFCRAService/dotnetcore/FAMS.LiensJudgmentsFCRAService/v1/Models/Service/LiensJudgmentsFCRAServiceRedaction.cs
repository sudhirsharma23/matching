﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public class LiensJudgmentsFCRAServiceRedaction
    {
        public string S3Key { get; set; }
        public string VersionID { get; set; }
        public bool IsLatest { get; set; }
    }
}

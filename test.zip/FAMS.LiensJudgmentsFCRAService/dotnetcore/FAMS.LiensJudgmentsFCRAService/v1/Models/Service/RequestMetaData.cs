﻿using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.ApplicationLoadBalancerEvents;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.JODI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public class RequestMetaData
    {
        #region Properties
        public string HttpMethod
        {
            get { return _httpMethod; }
        }
        string _httpMethod = null;
        public string Path
        {
            get { return _path; }
        }
        string _path = null;
        public string TransactionID
        {
            get { return _transactionID; }
        }
        string _transactionID = null;
        public string Accept
        {
            get { return _accept; }
        }
        string _accept = null;
        public string ContentType
        {
            get { return _contentType; }
        }
        string _contentType = null;
        public string CompanyName
        {
            get { return _companyName; }
        }
        string _companyName = null;
        public string ClientID
        {
            get { return _clientID; }
        }
        string _clientID = null;
        public string GlobalID
        {
            get { return _globalID; }
        }
        string _globalID = null;
        public string PortalCode
        {
            get { return _portalCode; }
        }
        string _portalCode = null;
        public string CorrelationToken
        {
            get { return _correlationToken; }
        }
        string _correlationToken = null;
        public string ContentFileType
        {
            get { return _contentFileType; }
        }
        string _contentFileType = null;
        public string AcceptFileType
        {
            get { return _acceptFileType; }
        }
        string _acceptFileType = null;
        public string ApplicationPlan
        {
            get { return _appPlan; }
        }
        string _appPlan = null;
        public string IsTestClient
        {
            get { return _isTestClient; }
        }
        string _isTestClient = null;
        public int CachePeriod
        {
            get { return _cachePeriod; }
        }
        int _cachePeriod = 0;

        public string APIVersion
        {
            get { return _apiVersion; }
        }
        string _apiVersion = null;


        private string _datasource = null;
        public string DataSource
        { get { return _datasource; } }

        public Dictionary<string, string> Persona
        {
            get { return _persona; }
        }
        Dictionary<string, string> _persona = null;

        private string _famsid = null;
        public string famsID
        { get { return _famsid; } }

        private bool _configoverride = false;
        public bool ConfigOverride
        { get { return _configoverride; } }

        private bool _diagnostics = false;
        public bool Diagnostics
        { get { return _diagnostics; } }

        private string _vendorUN = null;
        public string VendorUN
        { get { return _vendorUN; } }

        private string _vendorpwd = null;
        public string VendorPWD
        { get { return _vendorpwd; } }

        private string _glbPurpose = null;
        public string GLBPurpose
        { get { return _glbPurpose; } }

        private string _dlPurpose = null;
        public string DLPurpose
        { get { return _dlPurpose; } }
        private string _credsid = null;
        public string CredsID
        { get { return _credsid; } }
        #endregion

        #region "JODI Request"
        public RequestMetaData(JODIRequest request)
        {

            request.Context?.TryGetValue("http-method", out _httpMethod);
            request.Context?.TryGetValue("orig-path", out _path);
            request.Context?.TryGetValue("request-id", out _transactionID);

            Regex regex = new Regex(@"v[0-9]+");
            Match match = regex.Match(_path);
            if (match.Success)
                _apiVersion = match.Value;
            else
                _apiVersion = "v1";

            // throw new System.Exception($"Missing version in Path={_path}");
            request?.Params?.Header?.TryGetValue("fams-id", out _famsid);
            request?.Params?.Header?.TryGetValue("accept", out _accept);
            request?.Params?.Header?.TryGetValue("content-type", out _contentType);
            request?.Params?.Persona?.TryGetValue("companyName", out _companyName);
            request?.Params?.Persona?.TryGetValue("clientID", out _clientID);
            request?.Params?.Persona?.TryGetValue("globalID", out _globalID);
            request?.Params?.Persona?.TryGetValue("portalCode", out _portalCode);
            request?.Params?.Header?.TryGetValue("correlationtoken", out _correlationToken);
            request?.Params?.Header?.TryGetValue("testclient", out _isTestClient);
            request?.Params?.Header?.TryGetValue("datasource", out _datasource);

            _accept = JODIAssistant.SetValidAcceptType(_accept, _contentType);
            _contentType = string.IsNullOrWhiteSpace(_contentType) ? "application/json" : _contentType;
            _contentFileType = JODIAssistant.GetFileType(_contentType).ToString().ToLower();
            _acceptFileType = JODIAssistant.GetFileType(_accept).ToString().ToLower();

            string applicationPlan = string.Empty;
            if (request.Context != null && request.Context.TryGetValue("application-plan", out applicationPlan))
                _appPlan = applicationPlan;
            else if (request.Params != null && request.Params.Header.TryGetValue("application-plan", out applicationPlan))
                _appPlan = applicationPlan;


            string cachePeriod = string.Empty;
            request?.Params?.Header?.TryGetValue("cachePeriod", out cachePeriod);
            if (string.IsNullOrWhiteSpace(cachePeriod))
                _cachePeriod = int.MinValue;
            else
                int.TryParse(cachePeriod, out _cachePeriod);

            string sConfigOverride = null;
            if (request?.Params?.Persona?.TryGetValue("configoverride", out sConfigOverride) ?? false)
            {
                bool.TryParse(sConfigOverride, out _configoverride);
            }

            string sdiagnostics = null;
            if (request?.Params?.Persona?.TryGetValue("diagnostics", out sdiagnostics) ?? false)
            {
                bool.TryParse(sdiagnostics, out _diagnostics);
            }
           

            if (ConfigOverride)
            {
                request?.Params?.Header?.TryGetValue("login", out _vendorUN);
                request?.Params?.Header?.TryGetValue("password", out _vendorpwd);
                request?.Params?.Header?.TryGetValue("glbpurpose", out _glbPurpose);
                request?.Params?.Header?.TryGetValue("dlpurpose", out _dlPurpose);
                string sCredsID = string.Empty;
                if (request?.Params?.Persona?.TryGetValue("credsid", out sCredsID) ?? false)
                {
                    _credsid = sCredsID;
                }
                else if (request?.Params?.Header?.TryGetValue("credsid", out sCredsID) ?? false)
                {
                    _credsid = sCredsID;
                }
            }

            NormalizeFields();
            ConstructPersona();
        }
        #endregion

        #region "APIGATEWAY Request"
        public RequestMetaData(APIGatewayProxyRequest request)
        {
            _httpMethod = request?.HttpMethod;
            _path = request?.Path;
            _transactionID = request?.RequestContext?.RequestId;

            Regex regex = new Regex(@"v[0-9]+");
            Match match = regex.Match(_path);
            if (match.Success)
                _apiVersion = match.Value;
            else
                throw new System.Exception($"Missing version in Path={_path}");

            request?.Headers?.TryGetValue("Accept", out _accept);
            request?.Headers?.TryGetValue("Content-Type", out _contentType);
            request?.Headers?.TryGetValue("px-companyName", out _companyName);
            request?.Headers?.TryGetValue("px-clientID", out _clientID);
            request?.Headers?.TryGetValue("px-globalID", out _globalID);
            request?.Headers?.TryGetValue("px-portalCode", out _portalCode);

            request?.Headers?.TryGetValue("correlationtoken", out _correlationToken);
            request?.Headers?.TryGetValue("testclient", out _isTestClient);
            request?.Headers?.TryGetValue("datasource", out _datasource);

            _accept = JODIAssistant.SetValidAcceptType(_accept, _contentType);
            _contentType = string.IsNullOrWhiteSpace(_contentType) ? "application/json" : _contentType;
            _contentFileType = JODIAssistant.GetFileType(_contentType).ToString().ToLower();
            _acceptFileType = JODIAssistant.GetFileType(_accept).ToString().ToLower();

            if (request?.Headers?.TryGetValue("px-applicationPlan", out _appPlan) != true)
            {
                request?.Headers.TryGetValue("px-applicationPlan", out _appPlan);
            }

            string cachePeriod = string.Empty;
            request?.Headers?.TryGetValue("cacheperiod", out cachePeriod);
            if (string.IsNullOrWhiteSpace(cachePeriod))
                _cachePeriod = int.MinValue;
            else
                int.TryParse(cachePeriod, out _cachePeriod);

            string sConfigOverride = null;
            if (request?.Headers?.TryGetValue("px-configoverride", out sConfigOverride) ?? false)
            {
                bool.TryParse(sConfigOverride, out _configoverride);
            }
            else if (request?.Headers?.TryGetValue("configoverride", out sConfigOverride) ?? false)
            {
                bool.TryParse(sConfigOverride, out _configoverride);
            }

            string sdiagnostics = null;
            if (request?.Headers?.TryGetValue("px-diagnostics", out sdiagnostics) ?? false)
            {
                bool.TryParse(sdiagnostics, out _diagnostics);
            }
            else if (request?.Headers?.TryGetValue("diagnostics", out sdiagnostics) ?? false)
            {
                bool.TryParse(sdiagnostics, out _diagnostics);
            }

            if (ConfigOverride)
            {
                request?.Headers?.TryGetValue("login", out _vendorUN);
                request?.Headers?.TryGetValue("password", out _vendorpwd);
                request?.Headers?.TryGetValue("glbpurpose", out _glbPurpose);
                request?.Headers?.TryGetValue("dlpurpose", out _dlPurpose);
                string sCredsID = string.Empty;
                if (request?.Headers?.TryGetValue("px-credsid", out sCredsID) ?? false)
                {
                    _credsid = sCredsID;
                }
                else if (request?.Headers?.TryGetValue("credsid", out sCredsID) ?? false)
                {
                    _credsid = sCredsID;
                }
            }

            NormalizeFields();
            ConstructPersona();
        }

        #endregion
        #region "ALB Request"
        public RequestMetaData(ApplicationLoadBalancerRequest request)
        {
            _httpMethod = request?.HttpMethod;
            _path = request?.Path;
            _transactionID = Guid.NewGuid().ToString();

            Regex regex = new Regex(@"v[0-9]+");
            Match match = regex.Match(_path);
            if (match.Success)
                _apiVersion = match.Value;
            else
                throw new System.Exception($"Missing version in Path={_path}");

            request?.Headers?.TryGetValue("Accept", out _accept);
            request?.Headers?.TryGetValue("Content-Type", out _contentType);
            request?.Headers?.TryGetValue("px-companyName", out _companyName);
            request?.Headers?.TryGetValue("px-clientid", out _clientID);
            request?.Headers?.TryGetValue("px-globalid", out _globalID);
            request?.Headers?.TryGetValue("px-portalcode", out _portalCode);
            request?.Headers?.TryGetValue("correlationtoken", out _correlationToken);
            request?.Headers?.TryGetValue("testclient", out _isTestClient);
            request?.Headers?.TryGetValue("datasource", out _datasource);

            _accept = JODIAssistant.SetValidAcceptType(_accept, _contentType);
            _contentType = string.IsNullOrWhiteSpace(_contentType) ? "application/json" : _contentType;
            _contentFileType = JODIAssistant.GetFileType(_contentType).ToString().ToLower();
            _acceptFileType = JODIAssistant.GetFileType(_accept).ToString().ToLower();

            if (request?.Headers?.TryGetValue("px-applicationPlan", out _appPlan) != true)
            {
                request?.Headers.TryGetValue("px-applicationPlan", out _appPlan);
            }

            string cachePeriod = string.Empty;
            request?.Headers?.TryGetValue("cacheperiod", out cachePeriod);
            if (string.IsNullOrWhiteSpace(cachePeriod))
                _cachePeriod = int.MinValue;
            else
                int.TryParse(cachePeriod, out _cachePeriod);

            string sConfigOverride = null;
            if (request?.Headers?.TryGetValue("px-configoverride", out sConfigOverride) ?? false)
            {
                bool.TryParse(sConfigOverride, out _configoverride);
            }
            else if (request?.Headers?.TryGetValue("configoverride", out sConfigOverride) ?? false)
            {
                bool.TryParse(sConfigOverride, out _configoverride);
            }


            string sdiagnostics = null;
            if (request?.Headers?.TryGetValue("px-diagnostics", out sdiagnostics) ?? false)
            {
                bool.TryParse(sdiagnostics, out _diagnostics);
            }
            else if (request?.Headers?.TryGetValue("diagnostics", out sdiagnostics) ?? false)
            {
                bool.TryParse(sdiagnostics, out _diagnostics);
            }

            if (ConfigOverride)
            {
                request?.Headers?.TryGetValue("login", out _vendorUN);
                request?.Headers?.TryGetValue("password", out _vendorpwd);
                request?.Headers?.TryGetValue("glbpurpose", out _glbPurpose);
                request?.Headers?.TryGetValue("dlpurpose", out _dlPurpose);
                string sCredsID = string.Empty;
                if (request?.Headers?.TryGetValue("px-credsid", out sCredsID) ?? false)
                {
                    _credsid = sCredsID;
                }
                else if (request?.Headers?.TryGetValue("credsid", out sCredsID) ?? false)
                {
                    _credsid = sCredsID;
                }
            }

            NormalizeFields();
            ConstructPersona();
        }

        #endregion

        private void NormalizeFields()
        {
            if (_companyName != null)
                _companyName = _companyName.ToLower();
            if (_clientID != null)
                _clientID = _clientID.ToLower();
            if (_globalID != null)
                _globalID = _globalID.ToLower();
            if (_portalCode != null)
                _portalCode = _portalCode.ToLower();
            if (_appPlan != null)
                _appPlan = _appPlan.ToLower();
            if (_isTestClient != null)
                _isTestClient = _isTestClient.ToLower();
        }

        private void ConstructPersona()
        {
            _persona = new Dictionary<string, string>();


            if (_companyName != null)
                _persona.Add("companyName", _companyName);
            if (_clientID != null)
                _persona.Add("clientID", _clientID);
            if (_globalID != null)
                _persona.Add("globalID", _globalID);
            if (_portalCode != null)
                _persona.Add("portalCode", _portalCode);
        }

        public void SetPortalCode(string portalCode)
        {
            _portalCode = portalCode;
        }
    }
}

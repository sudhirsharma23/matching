﻿namespace FAMS.LiensJudgmentsFCRAService.v1.Models.Service
{
    public class LiensJudgmentsFCRAServiceMock
    {
        public LiensJudgmentsFCRAServiceRequest MockServiceRequest { get; set; }
        public string MockVendorResponse { get; set; }
    }
}

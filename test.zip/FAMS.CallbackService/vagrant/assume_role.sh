#!/bin/bash

rs=$(aws sts assume-role --role-arn arn:aws:iam::666678657097:role/CrossAccountAdmin  --role-session-name jharris)
echo $rs | jq '.Credentials.SessionToken'
aKey=$(echo $rs | jq '.Credentials.AccessKeyId' -r)
sKey=$(echo $rs | jq '.Credentials.SecretAccessKey' -r)
ses=$(echo $rs | jq '.Credentials.SessionToken' -r)

rm -f /home/vagrant/.aws/credentials
echo "[default]" >> /home/vagrant/.aws/credentials
echo "aws_access_key_id=$aKey" >> /home/vagrant/.aws/credentials
echo "aws_secret_access_key=$sKey" >> /home/vagrant/.aws/credentials
echo "aws_session_token =$ses" >> /home/vagrant/.aws/credentials

if [[ -f "/home/vagrant/.aws/config" ]]; then
    rm -f /home/vagrant/.aws/config
fi

echo "[default]" >> /home/vagrant/.aws/config
echo "region=us-west-2" >> /home/vagrant/.aws/config
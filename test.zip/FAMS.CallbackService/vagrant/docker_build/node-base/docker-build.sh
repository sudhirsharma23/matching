#!/bin/bash

docker build -t node-base:latest .
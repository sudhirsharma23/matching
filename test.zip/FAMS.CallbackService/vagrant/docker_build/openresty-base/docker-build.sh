#!/bin/bash

docker build -t openresty-base:latest .
#!/bin/bash
dn=$(dirname ${BASH_SOURCE[0]})
if [[ $dn = "." ]]; then
	#we are in the directory of the script
    bp=$PWD
	build_name=$(basename "$PWD")
else
    bp=$dn
	build_name=$(basename $dn)
fi
cd $bp
echo "building $build_name..."

zip -r chaperone.zip ./conf/chaperone/* -j

zip -r consul-template-config.zip ./conf/consul-template/* -j

zip -r scripts.zip ./scripts/* -j

cd ./artifacts/lua
zip -r ../../checkups-files.zip ./checkups-files/*
cd ../..



docker rm $(docker ps | grep $build_name| cut -d" " -f1) -f
docker rmi $build_name

#fetch build-packkage s3 url from artifacts.json if present
packagePath=$(cat /vagrant/artifacts.json | jq --arg bn "$build_name" '.[$bn]' -r)
if [[ ! -z  $packagePath ]]; then
    aws s3 cp $packagePath ./$build_name.zip
fi

if [ $# -ne 0 ]; then
   if [ "$1" == "--ecr" ]; then
        
        repo=$(cat /vagrant/ecr.json | jq --arg bn "$build_name" '.[$bn]' -r)
        read -r -d '' json << EOM
        {
        "post-processors": [
                
                [
                    {
                        "type": "docker-tag",
                        "repository": "$repo",
                        "tag" : "cc-0.1.4"
                    },
                    {
                        "type": "docker-push",
                        "ecr_login": true,
                        "login_server": "https://$repo"
                    }
                ]
                
            ]
        }
EOM
        echo $json >>  test.json
        jq -s add machine.json test.json >> temp-ecr-build.json
        packer_io build  temp-ecr-build.json
   fi
else
    packer_io build machine.json

fi

#cd - #return to where ever we were


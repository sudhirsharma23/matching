

local balancer = require "ngx.balancer"

function split(s, delimiter)
  result = {};
  for match in (s..delimiter):gmatch("(.-)"..delimiter) do
      table.insert(result, match);
  end
  return result;
end


if ngx.ctx.next_server == nil or ngx.ctx.next_server == ""  then
  balancer.set_current_peer("127.0.0.1", 65555 )  -- force a 502{{end}}
else
  t = split( ngx.ctx.next_server, ":")
  balancer.set_current_peer(t[1],  t[2])
end



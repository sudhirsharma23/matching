#!/bin/bash

if [ -n "$CONF_S3_PATH" ]; then
    aws s3 cp $CONF_S3_PATH /usr/local/openresty/nginx/conf/nginx.conf
fi


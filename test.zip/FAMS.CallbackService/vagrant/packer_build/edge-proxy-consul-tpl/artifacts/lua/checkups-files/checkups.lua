-- Copyright (C) 2014-2016 UPYUN, Inc.

local api = require "resty.checkups.api"

return api

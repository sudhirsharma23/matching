#!/bin/bash

dn=$(dirname ${BASH_SOURCE[0]})
if [[ $dn = "." ]]; then
	bp=$PWD
else
	bp=$dn
fi
. $bp/packer-build.sh

docker run -d -p 443:443 \
--volume $HOME/.aws:/root/.aws \
--entrypoint /usr/bin/chaperone \
--name edge-proxy-consul-tpl edge-proxy-consul-tpl

# docker run -it -p 443:443 \
# --volume $HOME/.aws:/root/.aws \
# edge-proxy-consul-tpl /bin/sh


# consul agent \
#         -pid-file /var/run/consul.pid \
#         -config-dir /consul/config \
#         -join 172.17.0.2:8301

# consul-template \
#         -pid-file /var/run/consul-template.pid \
# 		-config /etc/consul-template/config.d \
#         -consul-addr 172.17.0.1:8500


#curl http://172.17.0.1:8500/v1/catalog/service/consul -s | jq  ".[0].Address" -r
#!/bin/bash

#set -x
dn=$(dirname ${BASH_SOURCE[0]})
if [[ $dn = "." ]]; then
	bp=$PWD
else
	bp=$dn
fi
. $bp/packer-build.sh

host_ip=$(/sbin/ip route|awk '/default/ { print $3 }')
docker run -d \
    --name=registrator \
    --net=bridge \
    --volume=/var/run/docker.sock:/tmp/docker.sock \
    registrator \
    -internal \
     consul://$host_ip:8500

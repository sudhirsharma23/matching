#!/bin/bash
set -x
set -e

# apk update
# apk --no-cache add -t build-deps build-base go git
# apk --no-cache add ca-certificates

# mkdir /go
# mkdir /go/src
# cd /go/src
# git clone https://github.com/gliderlabs/registrator.git

# cd registrator
# export GOPATH=/go
# git config --global http.https://gopkg.in.followRedirects true
# go get
# go build -ldflags "-X main.Version=$(cat VERSION)" -o /bin/registrator 

# rm -rf /go 
# apk del --purge build-deps

# echo "#!/bin/bash" >> /usr/bin/start.sh
# echo "host_ip=$(/sbin/ip route|awk '/default/ { print $3 }')" >> /usr/bin/start.sh
# echo "exec registrator -internal consul://$host_ip:8500" >> /usr/bin/start.sh

# chmod +x /usr/bin/start.sh











#!/bin/bash


host_ip=$(/sbin/ip route|awk '/default/ { print $3 }')
exec registrator -internal consul://$host_ip:8500
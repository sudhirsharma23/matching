#!/bin/bash
set -x
set -e

#install lambda-proxy node app
mkdir /var/lambda-proxy
cd /tmp
unzip lambda-proxy.zip -d ./lambda-proxy
cd /tmp/lambda-proxy/source
cp * -r /var/lambda-proxy
cd /var/lambda-proxy
npm install







#!/bin/bash


aws s3 cp $MAP_S3_PATH /var/lambda-proxy/lambdaMap.json
#todo: Trap error from aws cli and stop container

cd /var/lambda-proxy/
node /var/lambda-proxy/lambdaProxy.js
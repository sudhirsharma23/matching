﻿using Amazon.DynamoDBv2;
using Amazon.Lambda;
using Amazon.Lambda.Core;
using Amazon.S3;
using FAMS.Callback.v1.Models.Service;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace FAMS.Callback.v1
{
    public class API
    {
        static ConcurrentDictionary<string, HttpClient> HttpClients;
        static object HttpClientLock = new object();

        static List<Method> MethodLookup;
        static object MethodLock = new object();

        LoggingAssistant Logger;
        UseCase UseCase;
        const string API_VERSION = "v1";
        bool IsDebug = false;

        static readonly string S3_BUCKET = System.Environment.GetEnvironmentVariable("S3_BUCKET");
        static readonly string DYNAMO_TABLE = System.Environment.GetEnvironmentVariable("DYNAMODB_TABLE");
        static readonly string KMS_KEY_ID = System.Environment.GetEnvironmentVariable("KMS_KEY_ID");
        static readonly bool LOG_JODI = System.Environment.GetEnvironmentVariable("LOG_JODI").Equals("true", StringComparison.OrdinalIgnoreCase) ? true : false;
        static readonly string SERVICE_ZONE_NAME = System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME");
        static readonly string KEEP_WARM_CLOUDWATCH_EVENT_RULE = System.Environment.GetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE");
        static readonly string ENVIRONMENT = System.Environment.GetEnvironmentVariable("ENVIRONMENT");

        static readonly string TRANSACTIONINFO_FOLDER = string.Format("{0}/TransactionInfo", SERVICE_ZONE_NAME);
        static readonly string MOCK_RESPONSE_FOLDER = string.Format("{0}/MockResponses", SERVICE_ZONE_NAME);
        static readonly string VENDOR_CONFIG_FOLDER = string.Format("{0}/VendorConfigurations", SERVICE_ZONE_NAME);
        static readonly string SERVICE_RESPONSE_FOLDER = string.Format("{0}/ServiceResponses", SERVICE_ZONE_NAME);

        #region Constructors
        public API()
        {
            UseCase = new UseCase();
            InitializeMethodLookup();
            InitializeHttpClient();
        }

        //Used for testing purposes
        public API(IAmazonS3 s3Client, IAmazonDynamoDB dbClient, IAmazonLambda LambdaClient)
        {
            UseCase = new UseCase(s3Client, dbClient, LambdaClient);
            InitializeMethodLookup();
            InitializeHttpClient();
        }
        #endregion

        #region Function Handlers
        /// <summary>
        /// Routing handler for the lambda functions.  This is the one method that the lambda will call directly, then based on HTTP Method and URI, this method will invoke the correct function to call.
        /// </summary>
        /// <param name="jodiRequest">Stream of JODIRequest. Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>Stream of JODI response.  The service response is b64 encoded in the body </returns>
        public async Task<Stream> RouteHandler(Stream jodiRequestStream, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string httpMethod = string.Empty;
            string uri = string.Empty;
            string requestID = string.Empty;

            JODIRequest request = null;
            JODIResponse response = null;
            MemoryStream responseStream = new MemoryStream();

            try
            {
                request = SerializationAssistant.DeserializeJson<JODIRequest>(jodiRequestStream);

                if (request == null)
                    throw new Exception("Unable to deserialize to JODIRequest object.");

                if (request.Params.Header.TryGetValue("debug-log", out string debugLog))
                    IsDebug = debugLog.Equals("true", StringComparison.OrdinalIgnoreCase);
                else
                    IsDebug = false;

                request.Context?.TryGetValue("http-method", out httpMethod);
                request.Context?.TryGetValue("orig-path", out uri);
                request?.Context?.TryGetValue("request-id", out requestID);

                Logger = new LoggingAssistant(context.FunctionName, "FAMS.Callback", requestID, request.Params.Persona);
                UseCase.Logger = Logger;

                Method method = JODIAssistant.FindMethod(MethodLookup, request);

                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},Supported Methods=GET,POST",
                                              uri,
                                              string.Join(",", MethodLookup.Select(a => a.Path)),
                                              httpMethod);
                    throw new Exception(errorMsg);
                }

                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                responseStream.Position = 0;

                return responseStream;
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex,
                                       string.Format("Failure in the RouteHandler. JODIRequest={0}", JODIAssistant.StreamToJson(jodiRequestStream)),
                                       FunctionTimer.ElapsedMilliseconds);

                string accept = string.Empty, contentType = string.Empty;
                request?.Params?.Header?.TryGetValue("accept", out accept);
                request?.Params?.Header?.TryGetValue("content-type", out contentType);
                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                response = UseCase.CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, requestID);
                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                return responseStream;
            }
            finally
            {
                FunctionTimer.Stop();

                //dont want to log to CW for keep warm request
                if (string.IsNullOrEmpty(KEEP_WARM_CLOUDWATCH_EVENT_RULE) || !KEEP_WARM_CLOUDWATCH_EVENT_RULE.Equals(requestID, StringComparison.OrdinalIgnoreCase))
                {
                    if (IsDebug)
                    {
                        Logger.LogJsonObject<JODIRequest>(request);
                        Logger.LogJsonObject<JODIResponse>(response);
                    }

                    Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                }

            }
        }

        /// <summary>
        /// GET - retrieve vendor response by VendorTransactionID or TransactionID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> GetHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string clientID = string.Empty, globalID = string.Empty, API = string.Empty, VendorTransactionid = string.Empty, accept = string.Empty, VendorCode = string.Empty;
            string portalCode = string.Empty, requestID = string.Empty, applicationPlan = string.Empty, contentType = string.Empty;
            //to do PD: clean up
            jodiRequest?.Params?.Persona?.TryGetValue("clientID", out clientID);
            jodiRequest?.Params?.Persona?.TryGetValue("globalID", out globalID);
            jodiRequest.Params?.Persona?.TryGetValue("portalCode", out portalCode);

            jodiRequest?.Context?.TryGetValue("request-id", out requestID);
            jodiRequest?.Context?.TryGetValue("application-plan", out applicationPlan);
            jodiRequest?.Params?.Header?.TryGetValue("accept", out accept);
            jodiRequest?.Params?.Header?.TryGetValue("content-type", out contentType);

            jodiRequest?.Params?.QueryString?.TryGetValue("vendortransactionid", out VendorTransactionid);
            jodiRequest?.Params?.QueryString?.TryGetValue("vendorcode", out VendorCode);
            jodiRequest?.Params?.QueryString?.TryGetValue("api", out API);

            try
            {
                //prakash : This has default of json already
                accept = JODIAssistant.SetValidAcceptType(accept, string.Empty);

                if (string.IsNullOrEmpty(VendorCode) || string.IsNullOrEmpty(VendorTransactionid) || string.IsNullOrEmpty(API))
                {
                    return UseCase.CreateJODIErrorResponse("api, vendortransid and vendorcode are required.", (int)HttpStatusCode.BadRequest, accept, requestID);
                }

                VendorTransactionid = VendorTransactionid.ToUpper();
                VendorCode = VendorCode.ToUpper();
                API = API.ToUpper();

                string TransactionInfoS3Key = UseCase.BuildS3Key(TRANSACTIONINFO_FOLDER, API_VERSION, API + "/" + VendorCode + "/" + VendorTransactionid, "json");

                TransactionInfo transactionInfo = await UseCase.GetS3JSONObject<TransactionInfo>(TransactionInfoS3Key, S3_BUCKET, true);

                if (transactionInfo == null)
                {
                    return UseCase.CreateJODIErrorResponse("TransactionInfo not found.", (int)HttpStatusCode.NotFound, accept, requestID);
                }

                return new JODIResponse()
                {
                    ContentType = accept,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<TransactionInfo>(accept, transactionInfo)
                };
            }
            catch (AmazonS3Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the GetHandler", FunctionTimer.ElapsedMilliseconds);
                return UseCase.CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)ex.StatusCode, accept, requestID);
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the GetHandler", FunctionTimer.ElapsedMilliseconds);

                return UseCase.CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)HttpStatusCode.InternalServerError, accept, requestID);
            }
            finally
            {
                FunctionTimer.Stop();

                Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }

        /// <summary>
        /// Publish TransactionInfo for look up when vendor calls back with updates
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. The actual service request is b64 encoded in the  body</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> RegisterTransactionHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            ServiceResponse serviceResponse = null;
            TransactionInfo request = UseCase.GetServiceRequestFromJODI<TransactionInfo>(jodiRequest, FunctionTimer);

            string clientID = null, globalID = null, portalCode = null, requestID = null, accept = null, contentType = null, applicationPlan = null;

            try
            {
                string RequestContentType = JODIAssistant.GetFileType(jodiRequest.BodyType).ToString().ToLower();

                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                jodiRequest?.Context?.TryGetValue("application-plan", out applicationPlan);
                jodiRequest?.Params?.Header?.TryGetValue("accept", out accept);
                jodiRequest?.Params?.Header?.TryGetValue("content-type", out contentType);

                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                if (request == null)
                    return UseCase.CreateJODIErrorResponse("Invalid request", (int)HttpStatusCode.BadRequest, accept, requestID);

                //Get Persona Info
                jodiRequest.Params?.Persona?.TryGetValue("clientID", out clientID);
                jodiRequest.Params?.Persona?.TryGetValue("globalID", out globalID);
                jodiRequest.Params?.Persona?.TryGetValue("portalCode", out portalCode);

                JODIResponse validationErrorResponse = UseCase.BuildValidationErrorResponse(request, FunctionTimer, accept, requestID);
                if (validationErrorResponse != null)
                    return validationErrorResponse;

                string TRANSACTIONINFOS3Key = UseCase.BuildS3Key(TRANSACTIONINFO_FOLDER, API_VERSION, request.API.ToUpper() + "/" + request.VendorCode.ToUpper() + "/" + request.VendorTransactionID, RequestContentType);
                await UseCase.SaveToS3<TransactionInfo>(request, S3_BUCKET, TRANSACTIONINFOS3Key, KMS_KEY_ID);

                if (UseCase.IsMockRequest(request, applicationPlan))
                {
                    //check for mock by mock key
                    serviceResponse = await UseCase.GetMockedResponseFromS3(S3_BUCKET, UseCase.BuildS3Key(MOCK_RESPONSE_FOLDER, API_VERSION, request.VendorTransactionID, RequestContentType));

                    //no mock response found(expired or never created)
                    if (serviceResponse == null)
                    {
                        return new JODIResponse()
                        {
                            HttpStatus = (int)HttpStatusCode.NotFound
                        };
                    }
                }
                else
                {
                    serviceResponse = UseCase.CreatePublishResponse(true);
                }

                FunctionTimer.Stop();

                //create JODI response
                return new JODIResponse()
                {
                    ContentType = accept,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<ServiceResponse>(accept, serviceResponse)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the PublishHandler", FunctionTimer.ElapsedMilliseconds);

                return UseCase.CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, requestID);
            }
            finally
            {
                try
                {
                    FunctionTimer.Stop();
                }
                finally
                {
                    Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                }
            }
        }

        private async Task<JODIResponse> PingHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            return JODIAssistant.SetPingTestResponse();
        }

        /// <summary>
        /// A simple health check(check S3/Dynamo are active)
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the health check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse> HealthCheckHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();
            string contentType = "application/json";
            string requestID = string.Empty;

            try
            {
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);

                HealthCheck healthCheck = await UseCase.RunHealthCheck(SERVICE_ZONE_NAME, S3_BUCKET, DYNAMO_TABLE);

                return new JODIResponse()
                {
                    HttpStatus = healthCheck.ServiceStatus == ComponentStatus.Red ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK,
                    ContentType = contentType,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, healthCheck)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Health check failed", FunctionTimer.ElapsedMilliseconds);

                return UseCase.CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, requestID);
            }
        }
        #endregion


        #region Private Methods
        private void InitializeHttpClient()
        {
            if (HttpClients == null)
            {
                lock (HttpClientLock)
                {
                    if (HttpClients == null)
                    {
                        HttpClients = new ConcurrentDictionary<string, HttpClient>();
                    }
                }
            }
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        MethodLookup = new List<Method>();

                        Method getMethod = new Method
                        {
                            InvokeFunction = GetHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/report$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(getMethod);

                        Method postMethod = new Method
                        {
                            InvokeFunction = RegisterTransactionHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/order$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(postMethod);

                        Method healthMethod = new Method
                        {
                            InvokeFunction = HealthCheckHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/health$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(healthMethod);

                        Method pingMethod = new Method
                        {
                            InvokeFunction = PingHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/ping", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(pingMethod);
                    }
                }
            }
        }
        #endregion
    }
}
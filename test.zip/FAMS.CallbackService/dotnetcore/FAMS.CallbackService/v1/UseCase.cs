﻿using Amazon.Lambda;
using Amazon.Lambda.Model;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Amazon.S3;
using Amazon.S3.Model;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Enums;
using FAMS.Common.API.Models.JODI;
using FAMS.Callback.v1.Models.Service;
using ServiceConfiguration = FAMS.Callback.v1.Models.Service.ServiceConfiguration;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.Infrastructure;

namespace FAMS.Callback.v1
{
    public class UseCase
    {
        private IAmazonLambda _lambdaClient;
        private IAmazonS3 _s3Client;
        private IAmazonDynamoDB _dbClient;
        private IDynamoDBContext _dbContext;
        private LoggingAssistant _logger;

        public LoggingAssistant Logger
        {
            get
            {
                return this._logger;
            }
            set
            {
                this._logger = value;
            }
        }

        public UseCase()
        {
            _s3Client = new AmazonS3Client();
            _dbClient = new AmazonDynamoDBClient();
            _dbContext = new DynamoDBContext(_dbClient);
            _lambdaClient = new AmazonLambdaClient(new AmazonLambdaConfig() { Timeout = new TimeSpan(0, 2, 0) });
        }

        public UseCase(IAmazonS3 s3Client, IAmazonDynamoDB dynamoClient, IAmazonLambda LambdaClient)
        {
            _lambdaClient = LambdaClient;
            _s3Client = s3Client;
            _dbClient = dynamoClient;
            _dbContext = new DynamoDBContext(_dbClient);
        }

        public T GetServiceRequestFromJODI<T>(JODIRequest jodiRequest, Stopwatch functionTimer) where T : class
        {
            T request = null;

            try
            {
                request = JODIAssistant.DeserializeB64Body<T>(jodiRequest.BodyType, jodiRequest.Body);
            }
            catch (Exception ex)
            {
                string requestID = string.Empty;
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);

                _logger.LogServiceError(ex, string.Format("Failure to deserialize b64 body. Body={0}", jodiRequest.Body), functionTimer.ElapsedMilliseconds);
            }

            return request;
        }

        public ServiceResponse CreatePublishResponse(bool success)
        {
            if (success)
                return new ServiceResponse
                {
                    Status = StatusType.Submitted,
                    StatusMessage = "Success"
                };
            else
                return new ServiceResponse
                {
                    Status = StatusType.Error,
                    StatusMessage = "Fail"
                };
        }

        public JODIResponse BuildValidationErrorResponse(TransactionInfo request, Stopwatch functionTimer, string accept, string transactionID)
        {
            JODIResponse response = null;
            StringBuilder sb = new StringBuilder();

            //**Required Fields for Vendor**
            var VendorTransactionID = request?.VendorTransactionID;
            var ARN = request?.ARN;
            var SQS = request?.SQS;
            var PostingEndPoint = request?.PostingEndPoint;

            if ((string.IsNullOrEmpty(ARN) || string.IsNullOrEmpty(PostingEndPoint)) && string.IsNullOrEmpty(SQS))
            {
                sb.Append("ARN+PostingEndPoint OR SQS name is required.");
            }

            if (string.IsNullOrEmpty(request?.VendorTransactionID) || string.IsNullOrEmpty(request?.VendorCode) || string.IsNullOrEmpty(request?.API))
                sb.Append("API, VendorTransactionID and VendorCode are required.");

            string message = sb.ToString().Trim();

            if (!string.IsNullOrEmpty(message))
            {
                response = CreateJODIErrorResponse(message, (int)HttpStatusCode.BadRequest, accept, transactionID);

                _logger.LogServiceError(new Exception(message), "Request failed validation.", functionTimer.ElapsedMilliseconds);
            }

            return response;
        }

        public JODIResponse CreateJODIErrorResponse(string errorMsg, int statusCode, string contentType, string transactionID)
        {
            return new JODIResponse()
            {
                ContentType = contentType,
                ErrorMessage = new JODIErrorResponse()
                {
                    Error = errorMsg,
                    HttpStatus = statusCode
                }
            };
        }

        public async Task<ServiceResponse> GetMockedResponseFromS3(string bucket, string key)
        {
            ServiceResponse cachedResponse = null;
            try
            {
                var s3Response = await AWSAssistant.SearchS3ByKey<string>(_s3Client, bucket, key);
                cachedResponse = SerializationAssistant.DeserializeJson<ServiceResponse>(s3Response);
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex, "Failure retrieving mocked vendor response from S3", bucket, key);
            }

            return cachedResponse;
        }

        public async Task<T> GetS3JSONObject<T>(string key, string bucket, bool log404Error = false, int? cacheLimit = null)
        {
            try
            {
                return await AWSAssistant.SearchS3ByKey<T>(_s3Client, bucket, key);

            }
            catch (AmazonS3Exception ex)
            {
                //Some cases 404 is OK like when we are just searching for a key
                if (log404Error || ex.StatusCode != HttpStatusCode.NotFound)
                {
                    _logger.LogS3Error(ex,
                                       cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                       bucket,
                                       key);
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex,
                                   cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                   bucket,
                                   key);
                throw;
            }
            return default(T);
        }

        public string BuildS3Key(string folder, string version, string name, string fileType)
        {
            if (string.IsNullOrEmpty(fileType))
                return string.Format("{0}/{1}/{2}", folder, version, name);
            else
                return string.Format("{0}/{1}/{2}.{3}", folder, version, name, fileType);
        }

        public async Task<ServiceConfiguration> GetServiceConfiguration(string bucket, string folder, string portalCode, string environment)
        {
            string s3Key = string.Format("{0}/{1}.json", folder, portalCode);


            bool b1 = await _s3Client.DoesS3BucketExistAsync(bucket);

            var s1 = await _s3Client.ListObjectsV2Async(new ListObjectsV2Request()
            {
                BucketName = bucket,
                Prefix = folder,
                MaxKeys = 1
            });

            return await ServiceAssistant.GetServiceConfig<ServiceConfiguration>(_s3Client, bucket, s3Key, environment, portalCode);
        }

        public async Task<HealthCheck> RunHealthCheck(string service, string bucket, string table)
        {
            HealthCheck healthCheck = new HealthCheck(service);

            await healthCheck.VerifyS3AndDynamo(_s3Client, bucket, _dbClient, table);

            return healthCheck;
        }

        public bool IsMockRequest(TransactionInfo request, string applicationPlan)
        {
            var ARN = request?.ARN;
            if (ARN == "ARN")
                return true;
            else if (!string.IsNullOrEmpty(applicationPlan) && applicationPlan.ToLower().StartsWith("mock"))
                return true;
            else
                return false;
        }

        public async Task<PutObjectResponse> SaveToS3<T>(T document, string bucket, string key, string kmsKeyId, int cacheDays = 0)
        {
            PutObjectResponse response = null;

            try
            {
                response = await AWSAssistant.SaveToS3<T>(_s3Client, document, bucket, key, kmsKeyId, cacheDays);
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex, "Failure saving to S3", bucket, key);
                throw;
            }

            return response;
        }

        public async Task<DescribeTableResponse> GetDynamoDBTableInfo(string table)
        {
            DescribeTableResponse response = null;

            try
            {
                response = await _dbClient.DescribeTableAsync(table);
            }
            catch (Exception ex)
            {
                Logger.LogDynamoError(ex, "Failure getting table info from DynamoDB", table);

                throw;
            }

            return response;
        }
    }
}

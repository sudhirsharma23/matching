﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.ELSAPI.v1
{
    public enum Statuses { submitted, completed, cancelled, pdfrevised, datarevised}

    public class SeedMockRequest : Dictionary<string, string>
    {
    }
}

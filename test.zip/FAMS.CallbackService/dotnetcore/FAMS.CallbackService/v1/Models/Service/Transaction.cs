﻿using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.HomeEquityService.Models.Service
{
    public class Transaction
    {
        public Transaction()
        {
            Headers = new Dictionary<string, string>();
            VendorCalls = new List<VendorCall>();
        }

        [DynamoDBHashKey]
        public string TransactionID { get; set; }
        public string DataSource { get; set; }
        public DateTime DateTimeUTC { get; set; }
        public string CacheKey { get; set; }
        public string RequestorID { get; set; }
        public string PortalCode { get; set; }
        public string ClientID { get; set; }
        public string Endpoint { get; set; }
        public string GlobalID { get; set; }
        public string BranchID { get; set; }
        public string CompanyName { get; set; }
        public string ApplicationPlan { get; set; }
        public Dictionary<string, string> Headers { get; set; }
        public List<VendorCall> VendorCalls { get; set; }
        public string SvcReqS3Key { get; set; }
        public string SvcRespS3Key { get; set; }
        public int SvcRespStatus { get; set; }
        public long SvcRespTimeMS { get; set; }
    }

    public class VendorCall
    {
        public VendorCall()
        {
            MetaData = new Dictionary<string, string>();
        }
        public string Name { get; set; }
        public int Sequence { get; set; }
        public DateTime DateTimeUTC { get; set; }
        public int Count { get; set; }
        public string Source { get; set; }
        public long AvgVendRespTimeMS { get; set; }
        public long MaxVendRespTimeMS { get; set; }
        public string MaxVendRespS3Key { get; set; }
        public Dictionary<string, string> MetaData { get; set; }
    }

    public enum OwnershipServiceDataSource
    {
        Vendor,
        Cache,
        Mock
    }
}


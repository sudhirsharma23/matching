﻿using System.Collections.Generic;

namespace FAMS.Callback.v1.Models.Service
{
    public class ServiceConfiguration
    {
        public Dictionary<string, VendorConfiguration> Vendors { get; set; }
    }

    public class VendorConfiguration
    {
        public string VendorName { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
    }
}

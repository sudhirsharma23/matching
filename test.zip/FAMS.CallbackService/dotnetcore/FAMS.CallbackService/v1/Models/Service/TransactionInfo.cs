﻿using Amazon.DynamoDBv2.DataModel;
using FAMS.Callback.v1.Models.Service;
using System;
using System.Collections.Generic;

namespace FAMS.Callback.v1.Models.Service
{
    //this same class is referenced in calling API
    public class TransactionInfo
    {
        public string VendorCode { get; set; }
        public string VendorTransactionID { get; set; }
        public string API { get; set; }
        public string APITransactionID { get; set; }//optional
        public string ARN { get; set; }
        public string SQS { get; set; }
        public string PostingEndPoint { get; set; }//API EndPoint to post vendor post to (optional)
    }

    public class ServiceResponse
    {
        public StatusType Status { get; set; }
        public string StatusMessage { get; set; }
    }

    public enum StatusType
    {
        Error = 0,
        Submitted = 1
    }
}
using Amazon.Lambda;
using Amazon.Lambda.Model;
using Amazon.DynamoDBv2;
using Amazon.Lambda.TestUtilities;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using FAMS.Callback.v1;
using FAMS.Callback.v1.Models.Service;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Xunit;

namespace FAMS.ELSCallback.Tests
{
    public class APITest
    {
        AWSCredentials credentials;
        IAmazonS3 s3Client;
        IAmazonDynamoDB dbClient;
        IAmazonLambda LambdaClient;

        private string aws_generated_name = "sbx-callback-api-w2-boss-bedbug";

        public APITest()
        {
            System.Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:666678657097:key/c6bf8ddb-5a4f-488a-b569-fa56202c3752");
            System.Environment.SetEnvironmentVariable("SERVICE_ZONE_NAME", "callback");

            credentials = GetAWSCredentialsFromProfile("sbx");
            System.Environment.SetEnvironmentVariable("ENVIRONMENT", "sbx");

            s3Client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USWest2);
            dbClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.USWest2);
            LambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.USWest2);

            System.Environment.SetEnvironmentVariable("S3_BUCKET", aws_generated_name);

            System.Environment.SetEnvironmentVariable("DYNAMODB_TABLE", string.Format("{0}-{1}-transactions", aws_generated_name, System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME")));
            System.Environment.SetEnvironmentVariable("LOG_JODI", "true");
            //System.Environment.SetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE", "KeepWarmHealthCheck");
        }

        [Fact]
        public async void TestRouteHandlerPOSTELSMOCK()
        {
            string fileName = "999111111_ELS.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = aws_generated_name,
                Body = ConvertServiceRequestToBase64("FAMS.CallbackService.Tests.SampleMock", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/mock", System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function 
            var api = new API(s3Client, dbClient, LambdaClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerPOST()
        {
            string fileName=string.Empty;
            fileName = "ElsRequest.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = aws_generated_name,
                Body = ConvertServiceRequestToBase64("FAMS.CallbackService.Tests.SampleRequests", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/order", System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "*/*" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, dbClient, LambdaClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerPOSTMOCK()
        {
            string fileName = "999111111_ELS-XML-LTX.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = aws_generated_name,
                Body = ConvertServiceRequestToBase64("FAMS.CallbackService.Tests.SampleMock", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/mock", System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, dbClient, LambdaClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }
        [Fact]
        public async void TestRouteHandlerGET()
        {
            string transID = "1234";
            string vendorcode = "LTX";
            string API = "ELS3";

            JODIRequest jr = new JODIRequest
            {
                Lambda = aws_generated_name,
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/report", System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    {"stage", "sbx"},
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    },
                    QueryString = new SerializableDictionary<string, string>()
                    {
                        {"vendortransactionid", transID },
                        {"api", API },
                        {"vendorcode", vendorcode }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);
            
            // Invoke the lambda function
            var api = new API(s3Client, dbClient, LambdaClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerHEALTH()
        {
            JODIRequest jr = new JODIRequest
            {
                Lambda = aws_generated_name,
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/health", System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    {"request-id", "d0354377-f9a6-450a-a614-ec81b1150bae" },
                    {"stage", "sbx"}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient, LambdaClient);
            var context = new TestLambdaContext();
            context.FunctionName = aws_generated_name;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        private AWSCredentials GetAWSCredentialsFromProfile(string profile)
        {
            var credentialProfileStoreChain = new CredentialProfileStoreChain();

            if (credentialProfileStoreChain.TryGetAWSCredentials(profile, out AWSCredentials credentials))
                return credentials;
            else
                throw new AmazonClientException("Unable to find a " + profile + " profile in CredentialProfileStoreChain.");
        }

        private string ConvertServiceRequestToBase64(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);

            return Convert.ToBase64String(ms.ToArray());
        }
        
        private string GetContentTypeFromFile(string extension)
        {
            if (extension.Equals(".json"))
                return "application/json";
            else if (extension.Equals(".xml"))
                return "text/xml";
            else
                return string.Empty;
        }

        private Random random = new Random();
        public string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}

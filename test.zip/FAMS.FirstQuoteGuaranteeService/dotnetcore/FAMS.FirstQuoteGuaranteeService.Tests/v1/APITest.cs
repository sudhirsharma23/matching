using Amazon.DynamoDBv2;
using Amazon.Lambda;
using Amazon.Lambda.TestUtilities;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.S3;
using FAMS.FirstQuoteGuaranteeService.v1;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using System;
using System.IO;
using System.Reflection;
using Xunit;
using System.Net;
using System.Net.Http;
using FAMS.FirstQuoteGuaranteeService.v1.Models.Service;
using System.Text;
using Newtonsoft.Json.Linq;

namespace FAMS.FirstQuoteGuaranteeService.Tests
{
    public class APITest
    {
        AWSCredentials credentials;
        IAmazonS3 s3Client;
        IAmazonDynamoDB dbClient;
        IAmazonLambda lambdaClient;

        private const string LAMBDA_NAME = "firstquoteguarantee-lambda";

        public APITest()
        {
            //YOU WILL NEED TO CONFIGURE THIS FOR YOUR ENVIRONMENT
            credentials = GetAWSCredentialsFromProfile("sbx");
            s3Client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USWest2);
            lambdaClient = new AmazonLambdaClient(credentials, Amazon.RegionEndpoint.USWest2);
            dbClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.USWest2);
            
            Environment.SetEnvironmentVariable("DYNAMODB_TABLE", "sbx-firstquoteguarantee-api-w2-saved-hagfish-firstquoteguarantee-transactions");
            Environment.SetEnvironmentVariable("ENVIRONMENT", "sbx");
            Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:666678657097:key/b854b8c0-b066-4048-b34e-087d43be5bb2");
            Environment.SetEnvironmentVariable("LOG_JODI", "false");
            Environment.SetEnvironmentVariable("S3_BUCKET", "sbx-firstquoteguarantee-api-w2-saved-hagfish");
            Environment.SetEnvironmentVariable("SERVICE_ZONE_NAME", "firstquoteguarantee");
            Environment.SetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE", "KeepWarmHealthCheck");
        }
       
        [Fact]
        public async void TestRouteHandlerPOST()
        {
            string fileName = "";
            fileName = "PostWithPropIDWithListingData.json";
            //fileName = "PostWithPropIDDatatreeNoHit.json";
            //fileName = "PostWithPropID.json";
           fileName = "PostNoPropID.json";
            //fileName = "PostDPLNoHit.json";
            //fileName = "PostNoPropValueOrDate.json";
             //fileName = "MOCK.json";


           

           
            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = ConvertServiceRequestToBase64("FAMS.FirstQuoteGuaranteeService.Tests.v1.SampleRequests", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/order", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    { "request-id", Guid.NewGuid().ToString() }
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                        //{"accept", "application/xml" },
                        //{"content-type", "application/xml" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, lambdaClient, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }
        
        [Fact]
        public async void TestRouteHandlerGET()
        {



            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/report", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "*" },
                        {"content-type", "application/json" },
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    },
                    QueryString = new SerializableDictionary<string, string>()
                    {
                        {"transactionID", "65cddca3-e62c-4896-9d0c-cfc175d20e4a" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, lambdaClient, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerHEALTH()
        {
            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/health", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" },
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, lambdaClient, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerPOSTMOCK()
        {
            string fileName = "MOCK.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = ConvertServiceRequestToBase64("FAMS.FirstQuoteGuaranteeService.Tests.v1.SampleMock", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/mock", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);

            // Invoke the lambda function
            var api = new API(s3Client, lambdaClient, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        //Unit Test for Calculation Updates
        [Fact]
        public async void TestRouteHandlerPOST_withCoefficient()
        {
            string fileName = "";
            //fileName = "PostWithPropIDWithListingData.json";
            //fileName = "PostWithPropIDDatatreeNoHit.json";
            //fileName = "PostWithPropID.json";
            fileName = "PostNoPropID.json";
            //fileName = "PostDPLNoHit.json";
            //fileName = "PostNoPropValueOrDate.json";
            //fileName = "MOCK.json";

            //Coefficient json - This is ComplexityScore in serviceResponse
            string source = ConvertServiceRequestToString("FAMS.FirstQuoteGuaranteeService.Tests.v1.SampleRequests", fileName.Replace(".json","-Coefficient.json"));
            dynamic data = JObject.Parse(source);
            string coef = data.Coefficient;
            string logicalQuote = data.LogicalQuote;

            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = ConvertServiceRequestToBase64("FAMS.FirstQuoteGuaranteeService.Tests.v1.SampleRequests", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/order", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    { "request-id", Guid.NewGuid().ToString() }
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                        //{"accept", "application/xml" },
                        //{"content-type", "application/xml" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, lambdaClient, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            JODIResponse response = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);

            FirstQuoteGuaranteeServiceResponse serviceResponse = JODIAssistant.DeserializeB64Body<FirstQuoteGuaranteeServiceResponse>(response.ContentType, response.ResponseBody);

            Assert.Equal(coef, serviceResponse.ComplexityScore);
            Assert.Equal(logicalQuote, serviceResponse.LogicalModelQuote);
        }

        private AWSCredentials GetAWSCredentialsFromProfile(string profile)
        {
            var credentialProfileStoreChain = new CredentialProfileStoreChain();

            if (credentialProfileStoreChain.TryGetAWSCredentials(profile, out AWSCredentials credentials))
                return credentials;
            else
                throw new AmazonClientException("Unable to find a " + profile + " profile in CredentialProfileStoreChain.");
        }

        private string ConvertServiceRequestToBase64(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);

            return Convert.ToBase64String(ms.ToArray());
        }

        private string ConvertServiceRequestToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);
            ms.Position = 0;

            var sr = new StreamReader(ms);
            return sr.ReadToEnd();
        }

        private MemoryStream ConvertServiceRequestToStream(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);
            ms.Position = 0;

            return ms;
        }

        private string GetContentTypeFromFile(string extension)
        {
            if (extension.Equals(".json"))
                return "application/json";
            else if (extension.Equals(".xml"))
                return "text/xml";
            else
                return string.Empty;
        }





        
    }
}

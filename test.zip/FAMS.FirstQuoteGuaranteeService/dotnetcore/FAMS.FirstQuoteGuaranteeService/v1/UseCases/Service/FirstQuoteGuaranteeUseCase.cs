﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda;
using Amazon.Lambda.Model;
using Amazon.S3;
using Amazon.S3.Model;
using FAMS.FirstQuoteGuaranteeService.v1.Models;
using FAMS.FirstQuoteGuaranteeService.v1.Models.Service;
using FAMS.FirstQuoteGuaranteeService.v1.Models.Vendor;
using FAMS.FirstQuoteGuaranteeService.v1.UseCases.Vendor;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.JODI;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using FAMS.FirstQuoteGuaranteeService.v1.Models.Common;
using System.Reflection;
using System.IO;
using FAMS.Common.API.Models.Infrastructure;

namespace FAMS.FirstQuoteGuaranteeService.v1.UseCases.Service
{
    public class FirstQuoteGuaranteeUseCase
    {
        private IAmazonS3 _s3Client;
        private IAmazonDynamoDB _dbClient;
        private IAmazonLambda _lambdaClient;
        private IDynamoDBContext _dbContext;
        private LoggingAssistant _logger;
        private IVendorUseCase _vendorSpecific;
        private VendorConfiguration _vendorConfig;

        private const Decimal DEFAULT_LOT_LIMIT = 217800; // 5 acres


        private VendorUseCaseFactory _vendorUseCaseFactory = new VendorUseCaseFactory();

        public VendorConfiguration VendorConfig
        {
            get
            {
                return this._vendorConfig;
            }
            set
            {
                this._vendorConfig = value;
            }
        }

        public LoggingAssistant Logger
        {
            get
            {
                return this._logger;
            }
            set
            {
                this._logger = value;
            }
        }

        public IVendorUseCase VendorSpecific
        {
            get
            {
                return this._vendorSpecific;
            }
        }

        public FirstQuoteGuaranteeUseCase()
        {
            _s3Client = new AmazonS3Client();
            _dbClient = new AmazonDynamoDBClient();
            _lambdaClient = new AmazonLambdaClient();
            _dbContext = new DynamoDBContext(_dbClient);
        }

        public FirstQuoteGuaranteeUseCase(IAmazonS3 s3Client, IAmazonLambda lambdaClient, IAmazonDynamoDB dynamoClient)
        {
            _s3Client = s3Client;
            _lambdaClient = lambdaClient;
            _dbClient = dynamoClient;
            _dbContext = new DynamoDBContext(_dbClient);
        }

        public void SetVendor(string vendor, string vendorProduct)
        {
            this._vendorSpecific = _vendorUseCaseFactory.CreateVendorUseCase(vendor, vendorProduct, _s3Client, _lambdaClient, _logger);
        }        

        public HttpClient InitializeHttpClient(ConcurrentDictionary<string, HttpClient> clients, VendorConfiguration config, string portalCode, VendorProduct vendorProduct)
        {
            HttpClient client = null;

           
            string key = string.Format("{0}-{1}", config.VendorName, config.VendorProduct);

            if (!clients.TryGetValue(key, out client))
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(config.RequestContentType));
                
                if (!string.IsNullOrEmpty((string)config.Configurations["apiKey"]))
                {
                    client.DefaultRequestHeaders.Add("x-api-key", (string)config.Configurations["apiKey"]);
                }

                client.Timeout = new TimeSpan(0, 0, config.TimeoutMS / 1000);
                clients.TryAdd(key, client);
            }

            return client;
        }

        public async Task<Object> CallVendor(IVendorRequest vendorRequest, VendorConfiguration config, VendorCall vendorCall, HttpClient client)
        {
           
            Stopwatch VendorWatch = new Stopwatch();
            VendorWatch.Start();

            try
            {
                HttpResponseMessage response = (HttpResponseMessage)await this._vendorSpecific.CallVendor(vendorRequest, config, client);
                return response;
            }
            catch
            {
                Logger.LogVendorCall(vendorCall.Name, "Error calling Vendor (likely timeout). Exception caught in PostHandler", VendorWatch.ElapsedMilliseconds);
                throw;
            }
            finally //always log vendor call even if call throws exception
            {
                VendorWatch.Stop();

                if (vendorCall != null)
                {
                    Logger.LogVendorCall(vendorCall.Name,
                                                   string.Format("Calling Vendor.  URL={0},RequestS3Key={1}", config.URL, vendorCall.RequestS3Key),
                                                   VendorWatch.ElapsedMilliseconds);


                    vendorCall.Elapsedms = VendorWatch.ElapsedMilliseconds;
                }
            }
        }

        public T GetServiceRequestFromJODI<T>(JODIRequest jodiRequest, Stopwatch functionTimer) where T : class
        {
            T request = null;

            try
            {
                request = JODIAssistant.DeserializeB64Body<T>(jodiRequest.BodyType, jodiRequest.Body);
            }
            catch (Exception ex)
            {
                _logger.LogServiceError(ex,
                                        string.Format("Failure to deserialize b64 body. Body={0}", jodiRequest.Body),
                                        functionTimer.ElapsedMilliseconds);
            }

            return request;
        }        

        public List<VendorConfiguration> GetVendorConfiguration(string environment)
        {
            var assembly = typeof(FirstQuoteGuaranteeUseCase).GetTypeInfo().Assembly;

            string file = string.Format("FAMS.FirstQuoteGuaranteeService.v1.Configs.Config.json");
            string resp = string.Empty;

            using (Stream resource = assembly.GetManifestResourceStream(file))
            {
                using (var reader = new StreamReader(resource))
                {
                    resp = reader.ReadToEnd();
                }
            }

            var vendorConfig = JObject.Parse(resp);
            var vendorConfigs = vendorConfig[environment].ToObject<List<VendorConfiguration>>();
            var defaultConfig = vendorConfig["default"].ToObject<List<VendorConfiguration>>()[0];

            if (vendorConfigs.Count > 0)
            {
                foreach (var configcode in vendorConfigs)
                {
                    configcode.Coefficients = defaultConfig.Coefficients;
                    configcode.LogicalModelCoefficients = defaultConfig.LogicalModelCoefficients;
                    configcode.FormType = defaultConfig.FormType;
                }
            }

            return vendorConfigs;
        }

        public JODIResponse BuildValidationErrorResponse(FirstQuoteGuaranteeServiceRequest request, FirstQuoteGuaranteeTransaction transaction, Stopwatch functionTimer)
        {
            JODIResponse response = null;

            string message = this._vendorSpecific.BuildValidationErrorMessage(request, transaction, this._vendorConfig);
            
            if (!string.IsNullOrEmpty(message))
            {
                response = new JODIResponse()
                {
                    ErrorMessage = new JODIErrorResponse()
                    {
                        HttpStatus = (int)HttpStatusCode.BadRequest,
                        Error = message,
                    }
                };

                _logger.LogServiceError(new Exception(message),
                                                 "Request failed validation.",
                                                 functionTimer.ElapsedMilliseconds);
            }

            return response;
        }

        public string ComputeCacheKey(string requestorID, string companyID, FirstQuoteGuaranteeServiceRequest request)
        {
            if (request == null)
                return null;

            byte[] hashValue = null;
            string key = string.Format("{0}|{1}|{2}", requestorID, companyID, SerializationAssistant.SerializeJson(request));
            key = new string(key.ToLower().ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());  //lowercase + remove whitespace

            UTF8Encoding enc = new UTF8Encoding();

            using (var sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(enc.GetBytes(key));
            }

            return BitConverter.ToString(hashValue).Replace("-", "");
        }

        public string ComputeMockKey(FirstQuoteGuaranteeServiceRequest request)
        {
            if (request == null)
                return null;

            byte[] hashValue = null;
            string key = SerializationAssistant.SerializeJson(request.Address);
            key = new string(key.ToLower().ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());
            UTF8Encoding enc = new UTF8Encoding();

            using (var sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(enc.GetBytes(key));
            }

            return BitConverter.ToString(hashValue).Replace("-", "");
        }

        public string BuildS3Key(string folder, string version, string name, string fileType)
        {
            if (string.IsNullOrEmpty(fileType))
                return string.Format("{0}/{1}/{2}", folder, version, name);
            else
                return string.Format("{0}/{1}/{2}.{3}", folder, version, name, fileType);
        }

        public async Task<ServiceConfiguration> GetServiceConfiguration(string bucket, string folder, string portalCode, string environment)
        {
            string s3Key = string.Format("{0}/{1}.json", folder, portalCode);
            return await ServiceAssistant.GetServiceConfig<ServiceConfiguration>(_s3Client, bucket, s3Key, environment, portalCode);
        }

        public bool IsMockRequest(FirstQuoteGuaranteeServiceRequest request, string applicationPlan)
        {
            if (!string.IsNullOrEmpty(request.Address.State) &&  (request.Address.State.StartsWith("Z") || request.Address.State.StartsWith("z")))
                return true;
            else if (!string.IsNullOrEmpty(applicationPlan) && applicationPlan.ToLower().StartsWith("mock "))
                return true;
            else
                return false;
        }

        public async Task<PutObjectResponse> SaveToS3<T>(T document, string bucket, string key, string kmsKeyId, int cacheDays = 0)
        {
            PutObjectResponse response = null;

            try
            {
               response = await AWSAssistant.SaveToS3<T>(_s3Client, document, bucket, key, kmsKeyId, cacheDays);
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex, "Failure saving to S3", bucket, key);
                throw;
            }

            return response;
        }

        public async Task<T> SearchS3ByKey<T>(string bucket, string key, bool log404Error = false, int? cacheLimit = null)
        {
            T document = default(T);

            try
            {
                document = await AWSAssistant.SearchS3ByKey<T>(_s3Client, bucket, key, log404Error, cacheLimit);
            }
            catch (AmazonS3Exception ex)
            {
                //Some cases 404 is OK like when we are just searching for a key
                if (log404Error || ex.StatusCode != HttpStatusCode.NotFound)
                {
                    _logger.LogS3Error(ex,
                                       cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                       bucket,
                                       key);

                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex,
                                   cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                   bucket,
                                   key);

                throw;
            }

            return document;
        }

        public async Task<IVendorResponse> GetMockedResponseFromS3(string bucket, string key, VendorProduct vendorProduct)
        {
            IVendorResponse cachedResponse = null;

            try
            {
                var s3Response = await AWSAssistant.SearchS3ByKey<string>(_s3Client, bucket, key);
                cachedResponse = this._vendorSpecific.MapToVendorResponse(s3Response);
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex, "Failure retrieving mocked vendor response from S3", bucket, key);
            }

            return cachedResponse;
        }

        public async Task SaveDynamoDBTransaction<T>(string table, T trans, string hashKey)
        {
            try
            {
                await AWSAssistant.SaveToDynamoDB<T>(_dbContext, table, trans, hashKey);
            }
            catch (Exception ex)
            {
                _logger.LogDynamoError(ex, "Failure saving transaction to DynamoDB", hashKey, table);
                _logger.LogJsonObject<T>(trans);

                throw;
            }
        }

        public async Task<T> GetDynamoDBTransaction<T>(string table, string hashKey)
        {
            T transaction = default(T);

            try
            {
                transaction = await AWSAssistant.GetFromDynamoDB<T>(_dbContext, table, hashKey);
            }
            catch (Exception ex)
            {
                _logger.LogDynamoError(ex, "Failure retrieving transaction from DynamoDB", table);

                throw;
            }

            return transaction;
        }

        public async Task<DescribeTableResponse> GetDynamoDBTableInfo(string table)
        {
            DescribeTableResponse response = null;

            try
            {
                response = await _dbClient.DescribeTableAsync(table);
            }
            catch (Exception ex)
            {
                _logger.LogDynamoError(ex, "Failure getting table info from DynamoDB", table);

                throw;
            }

            return response;
        }

        public async Task<HealthCheck> RunHealthCheck(string service, string bucket, string table)
        {
            HealthCheck healthCheck = new HealthCheck(service);
            await healthCheck.VerifyS3AndDynamo(_s3Client, bucket, _dbClient, table);
            return healthCheck;
        }

        public bool IsPersonaValid(FirstQuoteGuaranteeTransaction aTrans)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if (string.IsNullOrEmpty(aTrans.ClientID))
                sb.Append("ClientID is a required field.");

            if (string.IsNullOrEmpty(aTrans.PortalCode))
                sb.Append("PortalCode is a required field.");

            if (string.IsNullOrEmpty(aTrans.GlobalID))
                sb.Append("GlobalID is a required field.");

            string msg = sb.ToString();

            if (!string.IsNullOrEmpty(msg))
            {
                _logger.LogServiceError(new Exception("Persona is missing/invalid"), sb.ToString(), -1);
                valid = false;
            }

            return valid;
        }
        public void CalculateScore(FirstQuoteGuaranteeServiceResponse serviceResponse, VendorConfiguration vendorConfig, string formType,
            out decimal complexityScore, out Int16 quote, out decimal logicalModelComplexityScore, out Int16 logicalModelQuote)
        {
            complexityScore = 0.0M;
            quote = 0;
            logicalModelComplexityScore = 0.0M;
            logicalModelQuote = 0;

            complexityScore = CalculateComplexityScore(serviceResponse, vendorConfig, formType);                
            quote = CalculateQuote(vendorConfig, complexityScore);

            logicalModelComplexityScore = CalculateLogicalModelComplexityScore(serviceResponse, vendorConfig, formType);
            logicalModelQuote = CalculateLogicalModelQuote(serviceResponse,vendorConfig, logicalModelComplexityScore);

        }

        private decimal CalculateComplexityScore(FirstQuoteGuaranteeServiceResponse serviceResponse, VendorConfiguration vendorConfig, string formType)
        {
            decimal returnValue = 0.0M;
            decimal preReturnValue = returnValue;

            Decimal confidenceScore;
            Decimal gla;
            Decimal avm;
            Decimal siteSQFT;
            Boolean hasView = false;
            Decimal LotLimit = DEFAULT_LOT_LIMIT;

            StringBuilder sbLog = new StringBuilder();
            
            var state = serviceResponse.Property.State;
            var propertyType = serviceResponse.Property.PropertyType;
            var coefficientValues = vendorConfig.Coefficients;
            var ValidformType = vendorConfig.FormType;

            if (coefficientValues.TryGetValue("lot_limit", out JToken JLot))
            {
                LotLimit = (decimal)coefficientValues["lot_limit"];
            }
            sbLog.Append("Property Type = " + propertyType.ToString());
            sbLog.Append(" | ");
            if (propertyType.ToUpper().Equals("SFR") && coefficientValues.TryGetValue("sfr", out JToken keySFR))
                returnValue += (decimal)coefficientValues["sfr"];
            else if ((propertyType.ToUpper().Equals("CONDO") || propertyType.ToUpper().Equals("CONDOMINIUM")) && coefficientValues.TryGetValue("condo", out JToken keyCondo))
                returnValue += (decimal)coefficientValues["condo"];
            else if (coefficientValues.TryGetValue("other", out JToken keyOther))
                returnValue += (decimal)coefficientValues["other"];

            sbLog.Append("PropertyType Coefficient = " + (returnValue-preReturnValue).ToString());
            sbLog.Append(" | ");
            preReturnValue = returnValue;

            sbLog.Append("Form Type = " + formType.ToString());
            sbLog.Append(" | ");

            if (ValidformType.ContainsKey(formType.ToUpper()) && (coefficientValues.TryGetValue(ValidformType[formType.ToUpper()].ToUpper(), out JToken keyFormType)))
            returnValue += (decimal)coefficientValues[ValidformType[formType.ToUpper()]];

            sbLog.Append("FormType Coefficient = " + (returnValue - preReturnValue).ToString());
            sbLog.Append(" | ");
            preReturnValue = returnValue;

            Decimal.TryParse(serviceResponse.PropertyAVM.AvmConfidenceScore, out confidenceScore);
            if (coefficientValues.TryGetValue("score", out JToken keyScore))
            {
                returnValue += (decimal)coefficientValues["score"] * confidenceScore;
                sbLog.Append("score Coefficient = " + coefficientValues["score"].ToString()); sbLog.Append(" | ");
                sbLog.Append("confidenceScore Coefficient = " + confidenceScore.ToString()); sbLog.Append(" | ");
                sbLog.Append("score * confidenceScore  Coefficient = " + (returnValue - preReturnValue).ToString());
                sbLog.Append(" | ");
                preReturnValue = returnValue;
            }
            Decimal.TryParse(serviceResponse.Property.GLA, out gla);
            sbLog.Append("GLA = " + gla.ToString());
            sbLog.Append(" | ");

            if (coefficientValues.TryGetValue("rule_GLA", out JToken keyGLA))
            {
                if (gla >= 0 && gla < 3000) returnValue += keyGLA.Value<decimal>("bin_0_3000");
                else if (gla >= 3000 && gla < 4500) returnValue += keyGLA.Value<decimal>("bin_3000_4500");
                else if (gla >= 4500 && gla < 6000) returnValue += keyGLA.Value<decimal>("bin_4500_6000");
                else if (gla >= 6000 && gla < 7500) returnValue += keyGLA.Value<decimal>("bin_6000_7500");
                else if (gla >= 7500 && gla < 9000) returnValue += keyGLA.Value<decimal>("bin_7500_9000");
                else if (gla >= 9000) returnValue += keyGLA.Value<decimal>("bin_9000_inf");
            }

            Decimal.TryParse(serviceResponse.Property.SiteSQFT, out siteSQFT);

            sbLog.Append("rule_GLA Coefficient = " + (returnValue - preReturnValue).ToString());
            sbLog.Append(" | ");
            preReturnValue = returnValue;

            if (siteSQFT >= LotLimit && coefficientValues.TryGetValue("rule_SiteSQFT", out JToken keySiteSQFT))
                returnValue += (decimal)coefficientValues["rule_SiteSQFT"];

            sbLog.Append("rule_SiteSQFT Coefficient = " + (returnValue - preReturnValue).ToString());
            sbLog.Append(" | ");
            preReturnValue = returnValue;

            if (!String.IsNullOrEmpty(serviceResponse.Property.HasView))
            {
                hasView = Convert.ToBoolean(Convert.ToInt16(serviceResponse.Property.HasView));
                if (hasView && coefficientValues.TryGetValue("rule_view", out JToken keyView))
                    returnValue += (decimal)coefficientValues["rule_view"];
            }

            sbLog.Append("rule_view Coefficient = " + (returnValue - preReturnValue).ToString());
            sbLog.Append(" | ");
            preReturnValue = returnValue;

            Decimal.TryParse(serviceResponse.PropertyAVM.AvmValue, out avm);

            sbLog.Append("AVM = " + avm.ToString()); sbLog.Append(" | ");

            if (coefficientValues.TryGetValue(state, out JToken keyState))
            {
                returnValue += keyState.Value<decimal>("coef");

                sbLog.Append("State Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;

                if (avm >= 0 && avm < 800000) returnValue += keyState.Value<decimal>("rule_AVM_0_800000");
                else if (avm >= 800000 && avm < 1000000) returnValue += keyState.Value<decimal>("rule_AVM_800000_1000000");
                else if (avm >= 1000000 && avm < 1500000) returnValue += keyState.Value<decimal>("rule_AVM_1000000_1500000");
                else if (avm >= 1500000 && avm < 3000000) returnValue += keyState.Value<decimal>("rule_AVM_1500000_3000000");
                else if (avm >= 3000000 && avm < 5000000) returnValue += keyState.Value<decimal>("rule_AVM_3000000_5000000");
                else if (avm >= 5000000 ) returnValue += keyState.Value<decimal>("rule_AVM_5000000_inf");
                sbLog.Append("rule_AVM Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }
            this._logger.LogMessage("Complexity Score [ " + sbLog.ToString() + " ]", 0, "API", "", "", 0);
            return returnValue;
        }

        private Int16 CalculateQuote(VendorConfiguration vendorConfig, decimal complexityScore)
        {
            var coefficientValues = vendorConfig.Coefficients;

            var x = (double)coefficientValues["Intercept"];

            var feeAdjustment =  Math.Round((Math.Exp(x + (double)complexityScore) - 1));
            var additionalBuffer = 20;

            return Convert.ToInt16( feeAdjustment + additionalBuffer);
        }





        private decimal CalculateLogicalModelComplexityScore(FirstQuoteGuaranteeServiceResponse serviceResponse, VendorConfiguration vendorConfig, string formType)
        {
            decimal returnValue = 0.0M;
            decimal preReturnValue = returnValue;

            Decimal confidenceScore;
            Decimal gla;
            Decimal avm;
            Decimal siteSQFT;
            Boolean hasView = false;
            Decimal LotLimit = DEFAULT_LOT_LIMIT;
            StringBuilder sbLog = new StringBuilder();

            var coefficientValues = vendorConfig.LogicalModelCoefficients;

            if (coefficientValues.TryGetValue("lot_limit", out JToken JLot))
            {
                LotLimit = (decimal)coefficientValues["lot_limit"];
            }

            Decimal.TryParse(serviceResponse.Property.GLA, out gla);
            sbLog.Append("GLA = " + gla.ToString()); sbLog.Append(" | ");
            if (gla >= 7500 && gla < 9000 && coefficientValues.TryGetValue("rule_GLA_Tier1", out JToken keyGLA1))
            {
                returnValue += (decimal)coefficientValues["rule_GLA_Tier1"];
                sbLog.Append("rule_GLA_Tier1 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }

            else if (gla >= 6000 && gla < 7500 && coefficientValues.TryGetValue("rule_GLA_Tier2", out JToken keyGLA2))
            {
                returnValue += (decimal)coefficientValues["rule_GLA_Tier2"];
                sbLog.Append("rule_GLA_Tier2 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }

            else if (gla >= 4500 && gla < 6000 && coefficientValues.TryGetValue("rule_GLA_Tier3", out JToken keyGLA3))
            {
                returnValue += (decimal)coefficientValues["rule_GLA_Tier3"];
                sbLog.Append("rule_GLA_Tier3 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }

            else if (gla >= 3000 && gla < 4500 && coefficientValues.TryGetValue("rule_GLA_Tier4", out JToken keyGLA4))
            {
                returnValue += (decimal)coefficientValues["rule_GLA_Tier4"];
                sbLog.Append("rule_GLA_Tier4 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }



            Decimal.TryParse(serviceResponse.PropertyAVM.AvmValue, out avm);
            sbLog.Append("AVM = " + avm.ToString()); sbLog.Append(" | ");
            if (avm >= 3000000 && avm < 5000000 && coefficientValues.TryGetValue("rule_AVM_Tier1", out JToken keyAVM1))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_Tier1"];
                sbLog.Append("rule_AVM_Tier1 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }

            else if (avm >= 1500000 && avm < 3000000 && coefficientValues.TryGetValue("rule_AVM_Tier2", out JToken keyAVM2))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_Tier2"];
                sbLog.Append("rule_AVM_Tier1 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }

            else if (avm >= 1000000 && avm < 1500000 && coefficientValues.TryGetValue("rule_AVM_Tier3", out JToken keyAVM3))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_Tier3"];
                sbLog.Append("rule_AVM_Tier3 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }

            else if (avm >= 800000 && avm < 1000000 && coefficientValues.TryGetValue("rule_AVM_Tier4", out JToken keyAVM4))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_Tier4"];
                sbLog.Append("rule_AVM_Tier4 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }



            Decimal.TryParse(serviceResponse.PropertyAVM.AvmConfidenceScore, out confidenceScore);
            sbLog.Append("confidenceScore = " + confidenceScore.ToString()); sbLog.Append(" | ");
            if (avm >= 1000000 && avm < 1500000 && confidenceScore >= 90 && coefficientValues.TryGetValue("rule_AVM_CS_Tier1", out JToken rule_AVM_CS_Tier1))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_CS_Tier1"];
                sbLog.Append("rule_AVM_CS_Tier1 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }
            else if (avm >= 1500000 && avm < 3000000 && confidenceScore >= 90 && coefficientValues.TryGetValue("rule_AVM_CS_Tier2", out JToken rule_AVM_CS_Tier2))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_CS_Tier2"];
                sbLog.Append("rule_AVM_CS_Tier2 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }
            else if (avm < 1000000 && confidenceScore < 80 && confidenceScore >= 70 && coefficientValues.TryGetValue("rule_AVM_CS_Tier3", out JToken rule_AVM_CS_Tier3))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_CS_Tier3"];
                sbLog.Append("rule_AVM_CS_Tier3 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }
            else if (avm < 1000000 && confidenceScore < 70 && confidenceScore >= 60 && coefficientValues.TryGetValue("rule_AVM_CS_Tier4", out JToken rule_AVM_CS_Tier4))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_CS_Tier4"];
                sbLog.Append("rule_AVM_CS_Tier4 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }
            else if (avm < 1000000 && confidenceScore < 60 && coefficientValues.TryGetValue("rule_AVM_CS_Tier5", out JToken rule_AVM_CS_Tier5))
            {
                returnValue += (decimal)coefficientValues["rule_AVM_CS_Tier5"];
                sbLog.Append("rule_AVM_CS_Tier5 Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                preReturnValue = returnValue;
            }



                Decimal.TryParse(serviceResponse.Property.SiteSQFT, out siteSQFT);
            if (siteSQFT >= LotLimit && coefficientValues.TryGetValue("rule_SiteSQFT", out JToken keySiteSQFT))
                returnValue += (decimal)coefficientValues["rule_SiteSQFT"];

            sbLog.Append("rule_SiteSQFT Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
            preReturnValue = returnValue;

            if (!String.IsNullOrEmpty(serviceResponse.Property.HasView))
            {
                hasView = Convert.ToBoolean(Convert.ToInt16(serviceResponse.Property.HasView));
                if (hasView && coefficientValues.TryGetValue("rule_view", out JToken keyView))
                {
                    returnValue += (decimal)coefficientValues["rule_view"];
                    sbLog.Append("rule_view Coefficient = " + (returnValue - preReturnValue).ToString()); sbLog.Append(" | ");
                    preReturnValue = returnValue;
                }
            }
            this._logger.LogMessage("Logical Model Complexity Score [ " + sbLog.ToString() + " ]", 0, "API", "", "", 0);

            return returnValue;
        }

        private Int16 CalculateLogicalModelQuote(FirstQuoteGuaranteeServiceResponse serviceResponse,VendorConfiguration vendorConfig, decimal logicalModelComplexityScore)
        {
            decimal finalPrice = 0.0M;

            decimal manualQuote = 0.0M;

            StringBuilder sbLog = new StringBuilder();

            var coefficientValues = vendorConfig.LogicalModelCoefficients;

            var state = serviceResponse.Property.State;

            decimal threshold = 0;

            if ((coefficientValues.TryGetValue(state, out JToken keyState)) && (coefficientValues.TryGetValue("score_threshold", out JToken jThreshold)) && Decimal.TryParse(jThreshold.ToString(), out threshold))
            {
                decimal originalPrice = keyState.Value<decimal>("originalPrice");

                sbLog.Append("State Original Price = " + originalPrice.ToString());

                finalPrice = (logicalModelComplexityScore < threshold) ? ((originalPrice + (originalPrice * logicalModelComplexityScore))) : manualQuote;
            }

            this._logger.LogMessage("Logical Model Quote [ " + sbLog.ToString() + " ]", 0, "API", "", "", 0);

            return Convert.ToInt16(Math.Round(finalPrice));
        }
    }
}

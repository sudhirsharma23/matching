﻿using FAMS.Common.API.Models.Entities;
using System.ComponentModel;

namespace FAMS.FirstQuoteGuaranteeService.v1.Models.Common
{

    public class PropertyAddress : Address
    {
        public string PropertyId { get; set; }
        public string PropertyType { get; set; }
        public string PropertyValue { get; set; }
        public ParsedDate AvmAsOfDate { get; set; }
        public string YearBuilt { get; set; }
        public string GLA { get; set; }
        public string SiteSQFT { get; set; }
        public string HasView { get; set; }
    }
 
    public class PropertyAddressAVM : AddressAvm
    {

    }

    public enum VendorProduct
    {
        DetailedPropertyLocator, PropertyReport
    }

}

﻿using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace FAMS.FirstQuoteGuaranteeService.v1.Models
{
    public class ServiceConfiguration
    {
        public Dictionary<string, VendorConfiguration> Vendors { get; set; }
    }

    public class VendorConfiguration
    {
        public string VendorCode { get; set; }
        public string VendorName { get; set; }
        public string VendorProduct { get; set; }
        public int Priority { get; set; } //if we have cascade
        public string Login { get; set; }
        public string Password { get; set; }
        public string URL { get; set; }
        public int TimeoutMS { get; set; }
        public int CachePeriodDays { get; set; }
        public string RequestContentType { get; set; }
        public string ResponseContentType { get; set; }
        public JObject Coefficients { get; set; }
        public JObject LogicalModelCoefficients { get; set; }
        public JObject Configurations { get; set; }
        public Dictionary<string,string> FormType { get; set; }
    }
}
    

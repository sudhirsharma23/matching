﻿using Amazon.DynamoDBv2.DataModel;
using FAMS.Common.API.Models.Infrastructure;
using System;
using System.Collections.Generic;

namespace FAMS.FirstQuoteGuaranteeService.v1.Models
{
    public class FirstQuoteGuaranteeTransaction
    {
        [DynamoDBHashKey]
        public string TransactionID { get; set; }
        public string DataSource { get; set; }
        public DateTime DateTimeUTC { get; set; }
        public string CacheKey { get; set; }
        public string RequestorID { get; set; }
        public string PortalCode { get; set; }
        public string ClientID { get; set; }
        public string GlobalID { get; set; }
        public List<VendorCall> VendorCalls { get; set; }
        public string ServiceRequestS3Key { get; set; }
        public string ServiceResponseS3Key { get; set; }
        public int ServiceResponseHttpStatusCode { get; set; }
        public long ServiceResponseTimeMS { get; set; }
    }

    //DynamoDB converts enums to ints so saving TransactionType as string
    public enum DataSource
    {
        Vendor,
        Cache,
        Mock
    }
}

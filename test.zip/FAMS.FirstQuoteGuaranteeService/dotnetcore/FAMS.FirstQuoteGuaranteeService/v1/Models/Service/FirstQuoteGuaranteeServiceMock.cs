﻿
namespace FAMS.FirstQuoteGuaranteeService.v1.Models.Service
{
    public class FirstQuoteGuaranteeServiceMock
    {
        public string VendorCode { get; set; }
        public FirstQuoteGuaranteeServiceRequest MockServiceRequest { get; set; }
        public string MockVendorResponse { get; set; }
    }
}

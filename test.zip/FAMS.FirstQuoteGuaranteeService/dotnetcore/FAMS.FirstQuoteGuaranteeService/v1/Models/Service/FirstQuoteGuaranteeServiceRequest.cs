﻿using FAMS.FirstQuoteGuaranteeService.v1.Models.Common;

namespace FAMS.FirstQuoteGuaranteeService.v1.Models.Service
{
    public class FirstQuoteGuaranteeServiceRequest
    {
        public string RequestorID { get; set; }
        public PropertyAddress Address { get; set; }
        public string FormType { get; set; }
    }
}

﻿using FAMS.FirstQuoteGuaranteeService.v1.Models.Common;
using FAMS.Common.API.Models.JODI;

namespace FAMS.FirstQuoteGuaranteeService.v1.Models.Service
{
    public class FirstQuoteGuaranteeServiceResponse
    {
        public string TransactionID { get; set; }
        public string RequestorID { get; set; }
        public string Status { get; set; }
        public string StatusMessage { get; set; }
        public PropertyAddress Property { get; set; }
        public PropertyAddressAVM PropertyAVM { get; set; }
        public string Quote { get; set; }
        public string ComplexityScore { get; set; }
        public string LogicalModelQuote { get; set; }
        public string LogicalModelComplexityScore { get; set; }
    }

    //wrapper to hold either a jodi error or valid service response
    public class FirstQuoteGuaranteeMappedResponse
    {
        public FirstQuoteGuaranteeServiceResponse ServiceResponse { get; set; }
        public JODIResponse ErrorResponse { get; set; }
    }

    public enum ServiceStatusCode
    {
        Success, Failure, NoHit
    }

}

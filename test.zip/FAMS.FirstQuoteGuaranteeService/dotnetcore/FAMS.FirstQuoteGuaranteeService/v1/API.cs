using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda;
using Amazon.Lambda.Core;
using Amazon.Lambda.Model;
using Amazon.S3;
using FAMS.FirstQuoteGuaranteeService.v1.Models;
using FAMS.FirstQuoteGuaranteeService.v1.Models.Service;
using FAMS.FirstQuoteGuaranteeService.v1.Models.Vendor;
using FAMS.FirstQuoteGuaranteeService.v1.UseCases.Service;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using FAMS.FirstQuoteGuaranteeService.v1.Models.Common;

namespace FAMS.FirstQuoteGuaranteeService.v1
{
    public class API
    {
        #region Vars
       
        static ConcurrentDictionary<string, HttpClient> HttpClients;
        static object HttpClientLock = new object();

        static List<Method> MethodLookup;
        static object MethodLock = new object();

        FirstQuoteGuaranteeUseCase UseCase;
        LoggingAssistant Logger;

        const string API_VERSION = "v1";
        static readonly string S3_BUCKET = System.Environment.GetEnvironmentVariable("S3_BUCKET");
        static readonly string DYNAMO_TABLE = System.Environment.GetEnvironmentVariable("DYNAMODB_TABLE");
        static readonly string KMS_KEY_ID = System.Environment.GetEnvironmentVariable("KMS_KEY_ID");
        static readonly bool LOG_JODI = System.Environment.GetEnvironmentVariable("LOG_JODI").Equals("true", StringComparison.OrdinalIgnoreCase) ? true : false;
        static readonly string SERVICE_ZONE_NAME = System.Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME");
        static readonly string KEEP_WARM_CLOUDWATCH_EVENT_RULE = System.Environment.GetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE");
        static readonly string ENVIRONMENT = System.Environment.GetEnvironmentVariable("ENVIRONMENT");

        static readonly string SERVICE_REQUEST_FOLDER = string.Format("{0}/ServiceRequests", SERVICE_ZONE_NAME);
        static readonly string SERVICE_RESPONSE_FOLDER = string.Format("{0}/ServiceResponses", SERVICE_ZONE_NAME);
        static readonly string VENDOR_REQUEST_FOLDER = string.Format("{0}/VendorRequests", SERVICE_ZONE_NAME);
        static readonly string VENDOR_RESPONSE_FOLDER = string.Format("{0}/VendorResponses", SERVICE_ZONE_NAME);
        static readonly string MOCK_RESPONSE_FOLDER = string.Format("{0}/MockResponses", SERVICE_ZONE_NAME);
        static readonly string VENDOR_CONFIG_FOLDER = string.Format("{0}/VendorConfigurations", SERVICE_ZONE_NAME);

        #endregion

        #region Constructors
        public API()
        {
            UseCase = new FirstQuoteGuaranteeUseCase();

            InitializeMethodLookup();
            InitializeHttpClient();
        }


        //Used for testing purposes
        public API(IAmazonS3 s3Client, IAmazonLambda lambdaClient, IAmazonDynamoDB dbClient)
        {
            UseCase = new FirstQuoteGuaranteeUseCase(s3Client, lambdaClient, dbClient);

            InitializeMethodLookup();
            InitializeHttpClient();
        }
        #endregion

        #region Function Handlers
        /// <summary>
        /// Routing handler for the lambda functions.  This is the one method that the lambda will call directly, then based on HTTP Method and URI, this method will invoke the correct function to call.
        /// </summary>
        /// <param name="jodiRequest">Stream of JODIRequest. Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>Stream of JODI response.  The service response is b64 encoded in the body </returns>
        public async Task<Stream> RouteHandler(Stream jodiRequestStream, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string httpMethod = string.Empty;
            string uri = string.Empty;
            string requestID = string.Empty;

            JODIRequest request = null;
            JODIResponse response = null;
            MemoryStream responseStream = new MemoryStream();

            try
            {
                request = SerializationAssistant.DeserializeJson<JODIRequest>(jodiRequestStream);

                if (request == null)
                    throw new Exception("Unable to deserialize to JODIRequest object.");

                request.Context?.TryGetValue("http-method", out httpMethod);
                request.Context?.TryGetValue("orig-path", out uri);
                request?.Context?.TryGetValue("request-id", out requestID);

                Logger = new LoggingAssistant(context.FunctionName, "FAMS.FirstQuoteGuaranteeService", requestID, request.Params.Persona);
                UseCase.Logger = Logger;

                Method method = JODIAssistant.FindMethod(MethodLookup, request);

                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},Supported Methods=GET,POST",
                                              uri,
                                              string.Join(",", MethodLookup.Select(a => a.Path)),
                                              httpMethod);
                    throw new Exception(errorMsg);
                }

                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                responseStream.Position = 0;

                return responseStream;
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex,
                                       string.Format("Failure in the RouteHandler. JODIRequest={0}", JODIAssistant.StreamToJson(jodiRequestStream)),
                                       FunctionTimer.ElapsedMilliseconds);

                string accept = string.Empty, contentType = string.Empty;
                request?.Params?.Header?.TryGetValue("accept", out accept);
                request?.Params?.Header?.TryGetValue("content-type", out contentType);
                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                response = CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, requestID);
                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                return responseStream;
            }
            finally
            {
                FunctionTimer.Stop();

                //dont want to log to CW for keep warm request
                if (!KEEP_WARM_CLOUDWATCH_EVENT_RULE.Equals(requestID, StringComparison.OrdinalIgnoreCase))
                {
                    if (LOG_JODI)
                    {
                        Logger.LogJsonObject<JODIRequest>(request);
                        Logger.LogJsonObject<JODIResponse>(response);
                    }

                    Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                }
            }
        }

        /// <summary>
        /// GET - retrieve vendor response by Company ID & Transaction ID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> GetHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string clientID = string.Empty, globalID = string.Empty, transactionID = string.Empty, accept = string.Empty, requestID = string.Empty;
            Guid newGuid;

            jodiRequest?.Context?.TryGetValue("request-id", out requestID);
            jodiRequest?.Params?.Persona?.TryGetValue("clientID", out clientID);
            jodiRequest?.Params?.Persona?.TryGetValue("globalID", out globalID);
            jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);
            jodiRequest?.Params?.Header?.TryGetValue("accept", out accept);

            FirstQuoteGuaranteeServiceResponse serviceResponse = null;

            try
            {
                accept = JODIAssistant.SetValidAcceptType(accept, string.Empty);

                if (!Guid.TryParse(transactionID, out newGuid) || string.IsNullOrEmpty(transactionID))
                {                    
                    return new JODIResponse() { HttpStatus = (int)HttpStatusCode.BadRequest };
                }

                var aTrans = await UseCase.GetDynamoDBTransaction<FirstQuoteGuaranteeTransaction>(DYNAMO_TABLE, transactionID);

                if (aTrans == null ||
                    string.IsNullOrEmpty(aTrans.ServiceResponseS3Key) ||
                    !aTrans.GlobalID.Equals(globalID, StringComparison.OrdinalIgnoreCase)
                    || aTrans.ServiceResponseHttpStatusCode != 200)
                {
                    return new JODIResponse() { HttpStatus = (int)HttpStatusCode.NotFound };
                }                

                serviceResponse = await UseCase.SearchS3ByKey<FirstQuoteGuaranteeServiceResponse>(S3_BUCKET, aTrans.ServiceResponseS3Key, true);

                //if accept isn't a valid content type, set accept to content type of response saved in S3
                accept = JODIAssistant.SetValidAcceptType(accept, aTrans.ServiceResponseS3Key);

                if (serviceResponse == null)
                    throw new Exception(string.Format("Service Response not found in S3. Key={0},Bucket={1}", aTrans.ServiceResponseS3Key, S3_BUCKET));
                else
                    return new JODIResponse()
                    {
                        ContentType = accept,
                        HttpStatus = (int)HttpStatusCode.OK,
                        ResponseBody = JODIAssistant.SerializeBodyToB64<FirstQuoteGuaranteeServiceResponse>(accept, serviceResponse)
                    };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the GetHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)HttpStatusCode.InternalServerError, accept, requestID);
            }
            finally
            {
                FunctionTimer.Stop();

                Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }


        /// <summary>
        /// POST - make request to vendor and map to service response
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. The actual service request is b64 encoded in the  body</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> PostHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            IVendorResponse vendorResponse = null;

            HttpResponseMessage httpResponse = null;
            ConcurrentBag<VendorCall> vendorCalls = new ConcurrentBag<VendorCall>();

            VendorCall vendorCall = null;
            VendorConfiguration vendorConfig = null;
            IVendorRequest vendorRequest = null;
            JODIResponse validationErrorResponse = null;

            FirstQuoteGuaranteeTransaction aTrans = new FirstQuoteGuaranteeTransaction();
            FirstQuoteGuaranteeServiceRequest serviceRequest = UseCase.GetServiceRequestFromJODI<FirstQuoteGuaranteeServiceRequest>(jodiRequest, FunctionTimer);
            string vendor = "DataTree";

            HttpClient clientAAP= null, clientDATATREE = null;
            VendorProduct vendorProduct = VendorProduct.PropertyReport;

            string clientID = null, globalID = null, portalCode = null, requestID = null, accept = null, contentType = null, applicationPlan = null, content = null, propertyID = null;
            var vendorCallResults = new Dictionary<string, IVendorResponse>();

            try
            {
                string serviceFileType = JODIAssistant.GetFileType(jodiRequest.BodyType).ToString().ToLower();
                string vendorFileType = "";

                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                jodiRequest?.Context?.TryGetValue("application-plan", out applicationPlan);
                aTrans.TransactionID = requestID;

                jodiRequest?.Params?.Header?.TryGetValue("accept", out accept);
                jodiRequest?.Params?.Header?.TryGetValue("content-type", out contentType);

                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                if (serviceRequest == null)
                    return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, accept, aTrans.TransactionID);

                //Get Persona Info
                jodiRequest.Params?.Persona?.TryGetValue("clientID", out clientID);
                jodiRequest.Params?.Persona?.TryGetValue("globalID", out globalID);
                jodiRequest.Params?.Persona?.TryGetValue("portalCode", out portalCode);

                aTrans.RequestorID = serviceRequest?.RequestorID;
                aTrans.ClientID = clientID;
                aTrans.GlobalID = globalID;
                aTrans.PortalCode = portalCode;

                if (!UseCase.IsPersonaValid(aTrans))
                    return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, aTrans.TransactionID);

                aTrans.ServiceRequestS3Key = UseCase.BuildS3Key(SERVICE_REQUEST_FOLDER, API_VERSION, aTrans.TransactionID, serviceFileType);
                await UseCase.SaveToS3<FirstQuoteGuaranteeServiceRequest>(serviceRequest, S3_BUCKET, aTrans.ServiceRequestS3Key, KMS_KEY_ID);
                
                var configs = UseCase.GetVendorConfiguration(ENVIRONMENT);                

                if (configs.Count == 0)
                    throw new Exception("No vendor configuration found in service config.");                

                 if (UseCase.IsMockRequest(serviceRequest, applicationPlan))
                {
                    vendorFileType = "xml";
                    vendorConfig = configs.Where(x => x.VendorCode == vendor && x.VendorProduct == VendorProduct.PropertyReport.ToString())?.FirstOrDefault();
                    if (vendorConfig == null)
                        throw new Exception("No vendor configuration found in service config.");

                    aTrans.DataSource = Models.DataSource.Mock.ToString();
                    UseCase.SetVendor(vendorConfig.VendorCode, vendorConfig.VendorProduct);
                    vendorProduct = VendorProduct.PropertyReport;                    
                    
                    //check for mock by mock key
                    vendorResponse = await UseCase.GetMockedResponseFromS3(S3_BUCKET,
                                                                           UseCase.BuildS3Key(MOCK_RESPONSE_FOLDER,
                                                                                              API_VERSION, vendorConfig.VendorCode + "/" + UseCase.ComputeMockKey(serviceRequest),
                                                                                              vendorFileType), vendorProduct);

                    //no mock response found(expired or never created)
                    if (vendorResponse == null)
                    {
                        aTrans.ServiceResponseHttpStatusCode = (int)HttpStatusCode.NotFound;
                        return new JODIResponse()
                        {
                            HttpStatus = (int)HttpStatusCode.NotFound
                        };
                    }
                }
                else
                {
                    //If PropertyID is not passed in; need to call Detailed Property Locator to get PropertyID
                    if (string.IsNullOrEmpty(serviceRequest.Address.PropertyId))
                    {
                        vendorFileType =  "json";
                        vendorConfig = configs.Where(x => x.VendorCode == vendor && x.VendorProduct == VendorProduct.DetailedPropertyLocator.ToString())?.FirstOrDefault();
                        if (vendorConfig == null)
                            throw new Exception("No vendor configuration found in service config.");

                        UseCase.SetVendor(vendorConfig.VendorCode, vendorConfig.VendorProduct);
                        vendorProduct = VendorProduct.DetailedPropertyLocator;

                        //validate request
                        UseCase.VendorConfig = vendorConfig;
                        validationErrorResponse = UseCase.BuildValidationErrorResponse(serviceRequest, aTrans, FunctionTimer);
                        if (validationErrorResponse != null)
                            return validationErrorResponse;

                        aTrans.DataSource = Models.DataSource.Vendor.ToString();
                        vendorRequest = UseCase.VendorSpecific.MapServiceRequestToVendorRequest(serviceRequest, vendorConfig);

                        vendorCall = new VendorCall
                        {
                            Name = vendorConfig.VendorName + " " + vendorConfig.VendorProduct,
                            Sequence = 1,
                            RequestS3Key = UseCase.BuildS3Key(VENDOR_REQUEST_FOLDER, API_VERSION, aTrans.TransactionID, vendorFileType),
                            DateTimeUTC = DateTime.UtcNow
                        };

                        await UseCase.VendorSpecific.SaveRequestToS3(vendorRequest, S3_BUCKET, vendorCall.RequestS3Key, KMS_KEY_ID);

                        clientAAP = UseCase.InitializeHttpClient(HttpClients, vendorConfig, portalCode, vendorProduct);                        
                        httpResponse = (HttpResponseMessage)await UseCase.CallVendor(vendorRequest, vendorConfig, vendorCall, clientAAP);

                        vendorCall.HttpStatus = (int)httpResponse.StatusCode;
                        vendorCall.ResponseS3Key = UseCase.BuildS3Key(VENDOR_RESPONSE_FOLDER, API_VERSION, aTrans.TransactionID, vendorFileType);
                        vendorCalls.Add(vendorCall);

                        //always save vendor response.
                        content = await httpResponse.Content.ReadAsStringAsync();
                        if (httpResponse.IsSuccessStatusCode)
                        {
                            vendorResponse = UseCase.VendorSpecific.MapToVendorResponse(content);
                            await UseCase.VendorSpecific.SaveResponseToS3(vendorResponse, S3_BUCKET, vendorCall.ResponseS3Key, KMS_KEY_ID, vendorConfig.CachePeriodDays);
                        }
                        else
                        {
                            await UseCase.SaveToS3<string>(content, S3_BUCKET, vendorCall.ResponseS3Key, KMS_KEY_ID, vendorConfig.CachePeriodDays);

                            //throw exception if vendor call fails
                            throw new Exception(string.Format("Failure when calling {0}: {1}({2})", vendorCall.Name, (int)httpResponse.StatusCode, httpResponse.ReasonPhrase));
                        }
                        
                        propertyID = UseCase.VendorSpecific.RetrieveProperty(vendorResponse);
                    }

                    else
                    {
                        propertyID = serviceRequest.Address.PropertyId;
                    }

                    if (!string.IsNullOrEmpty(propertyID) && int.Parse(propertyID) > 0)
                    {
                        serviceRequest.Address.PropertyId = propertyID;
                        //Calling DATATREE
                        vendorFileType = "xml";
                        vendorConfig = configs.Where(x => x.VendorCode == vendor && x.VendorProduct == VendorProduct.PropertyReport.ToString())?.FirstOrDefault();
                        if (vendorConfig == null)
                            throw new Exception("No vendor configuration found in service config.");

                        UseCase.SetVendor(vendorConfig.VendorCode, vendorConfig.VendorProduct);
                        vendorProduct = VendorProduct.PropertyReport;

                        UseCase.VendorConfig = vendorConfig;
                        validationErrorResponse = UseCase.BuildValidationErrorResponse(serviceRequest, aTrans, FunctionTimer);
                        if (validationErrorResponse != null)
                            return validationErrorResponse;

                        vendorRequest = UseCase.VendorSpecific.MapServiceRequestToVendorRequest(serviceRequest, vendorConfig);
                        aTrans.DataSource = Models.DataSource.Vendor.ToString();

                        vendorCall = new VendorCall
                        {
                            Name = vendorConfig.VendorName + " " + vendorConfig.VendorProduct,
                            Sequence = 1,
                            RequestS3Key = UseCase.BuildS3Key(VENDOR_REQUEST_FOLDER, API_VERSION, aTrans.TransactionID, vendorFileType),
                            DateTimeUTC = DateTime.UtcNow
                        };

                        await UseCase.VendorSpecific.SaveRequestToS3(vendorRequest, S3_BUCKET, vendorCall.RequestS3Key, KMS_KEY_ID);

                        clientDATATREE = UseCase.InitializeHttpClient(HttpClients, vendorConfig, portalCode, vendorProduct);
                        
                        httpResponse = (HttpResponseMessage)await UseCase.CallVendor(vendorRequest, vendorConfig, vendorCall, clientDATATREE);

                        vendorCall.HttpStatus = (int)httpResponse.StatusCode;
                        vendorCall.ResponseS3Key = UseCase.BuildS3Key(VENDOR_RESPONSE_FOLDER, API_VERSION, aTrans.TransactionID, vendorFileType);
                        vendorCalls.Add(vendorCall);

                        //always save vendor response.
                        content = await httpResponse.Content.ReadAsStringAsync();
                        if (httpResponse.IsSuccessStatusCode)
                        {
                            vendorResponse = UseCase.VendorSpecific.MapToVendorResponse(content);
                            await UseCase.VendorSpecific.SaveResponseToS3(vendorResponse, S3_BUCKET, vendorCall.ResponseS3Key, KMS_KEY_ID, vendorConfig.CachePeriodDays);
                        }
                        else
                        {
                            await UseCase.SaveToS3<string>(content, S3_BUCKET, vendorCall.ResponseS3Key, KMS_KEY_ID, vendorConfig.CachePeriodDays);

                            //throw exception if vendor call fails
                            throw new Exception(string.Format("Failure when calling {0}: {1}({2})", vendorCall.Name, (int)httpResponse.StatusCode, httpResponse.ReasonPhrase));
                        }
                    }
                }

                //create the service response from vendor or mocked response                
                FirstQuoteGuaranteeMappedResponse mappedResponse = UseCase.VendorSpecific.CreateServiceResponseFromVendorResponse(vendorResponse, serviceRequest, vendorConfig, aTrans.RequestorID, aTrans.TransactionID);

                FirstQuoteGuaranteeServiceResponse serviceResponse = mappedResponse.ServiceResponse;                 
                
                JODIResponse jodiResponse;

                if (serviceResponse != null)
                {
                    
                    //Only do calculation if there was a HIT; and only continue processing score if Status is Success and Status Message is empty 
                    //When processing data, if the data doesn't meet the requirements to create a score/quote, Status will will be Success and a message will be supplied.
                    if (serviceResponse.Status.Equals(ServiceStatusCode.Success.ToString()) && serviceResponse.StatusMessage == null)
                    {
                        UseCase.CalculateScore(serviceResponse, vendorConfig, serviceRequest.FormType, out decimal complexityScore, out Int16 quote, out decimal logicalModelComplexityScore, out Int16 localModelQuote);

                        if (quote >= 0)
                        {
                            serviceResponse.Status = ServiceStatusCode.Success.ToString();
                            serviceResponse.StatusMessage = "Successfully created a score";
                            serviceResponse.ComplexityScore = complexityScore.ToString();
                            serviceResponse.Quote = quote.ToString();

                            serviceResponse.LogicalModelComplexityScore = logicalModelComplexityScore.ToString();
                            serviceResponse.LogicalModelQuote = localModelQuote.ToString();
                        }
                        else
                        {
                            serviceResponse.Status = ServiceStatusCode.Failure.ToString();
                            serviceResponse.StatusMessage = string.Format("{0}  TransactionID={1}", "Unable to create a valid score", aTrans.TransactionID);
                        }
                    }

                    aTrans.ServiceResponseS3Key = UseCase.BuildS3Key(SERVICE_RESPONSE_FOLDER, API_VERSION, aTrans.TransactionID, serviceFileType);
                    aTrans.ServiceResponseHttpStatusCode = (int)HttpStatusCode.OK;
                    await UseCase.SaveToS3<FirstQuoteGuaranteeServiceResponse>(serviceResponse, S3_BUCKET, aTrans.ServiceResponseS3Key, KMS_KEY_ID);

                    jodiResponse = new JODIResponse()
                    {
                        ContentType = accept,
                        HttpStatus = aTrans.ServiceResponseHttpStatusCode,
                        ResponseBody = JODIAssistant.SerializeBodyToB64<FirstQuoteGuaranteeServiceResponse>(accept, serviceResponse)
                    };
                }
                else
                {
                    jodiResponse = mappedResponse.ErrorResponse;
                    jodiResponse.ContentType = accept;                    
                }

                return jodiResponse;
            }
            catch (Exception ex)
            {
                //update status and log error
                aTrans.ServiceResponseHttpStatusCode = (int)HttpStatusCode.InternalServerError;
                Logger.LogServiceError(ex, "Failure in the PostHandler", FunctionTimer.ElapsedMilliseconds);
                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, aTrans.TransactionID);
            }
            finally
            {
                try
                {
                    FunctionTimer.Stop();
                    aTrans.ServiceResponseTimeMS = FunctionTimer.ElapsedMilliseconds;
                    aTrans.DateTimeUTC = DateTime.UtcNow;
                    aTrans.VendorCalls = vendorCalls.Count > 0 ? vendorCalls.ToList() : null;
                    await UseCase.SaveDynamoDBTransaction<FirstQuoteGuaranteeTransaction>(DYNAMO_TABLE, aTrans, aTrans.TransactionID);    
                }
                finally
                {
                    Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                }
            }
        }


        /// <summary>
        /// A simple health check(check S3/Dynamo are active + make echotest call to vendor)
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the health check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse> HealthCheckHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            string contentType = "application/json";

            try
            {
                HealthCheck healthCheck = await UseCase.RunHealthCheck(SERVICE_ZONE_NAME, S3_BUCKET, DYNAMO_TABLE);

                return new JODIResponse()
                {
                    HttpStatus = healthCheck.ServiceStatus == ComponentStatus.Red ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK,
                    ContentType = contentType,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, healthCheck)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Health check failed", -1);
                string requestID = string.Empty;
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, requestID);
            }
        }


        private async Task<JODIResponse> PingHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            return JODIAssistant.SetPingTestResponse();
        }


        /// <summary>
        /// Creates mock vendor responses and returns back the service request to get that mock response.
        /// </summary>
        /// <param name="request">A service mock object containing the service request + mocked vendor response</param>
        /// <param name="context"></param>
        /// <returns>The service request that was passed in. This will be used as the body of the POST request to the service.</returns>
        private async Task<JODIResponse> PostMockHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string contentType = "application/json";

            FirstQuoteGuaranteeServiceMock request = UseCase.GetServiceRequestFromJODI<FirstQuoteGuaranteeServiceMock>(jodiRequest, FunctionTimer);

            if (request == null)
                return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, contentType, "mock");

            try
            {
                var vendorFileType = request.MockVendorResponse.StartsWith('<') ? "xml" : "json";

                if (!UseCase.IsMockRequest(request.MockServiceRequest, string.Empty))
                {
                    throw new Exception("State must start with a z/Z.");
                }
                string mockKey = UseCase.ComputeMockKey(request.MockServiceRequest);

                //saving as string so we can submit malformed XML for testing purposes
                var mockVendorResponse = await UseCase.SaveToS3<string>(request.MockVendorResponse,
                                                                        S3_BUCKET,
                                                                        UseCase.BuildS3Key(MOCK_RESPONSE_FOLDER, API_VERSION, (request.VendorCode + "/" + mockKey), vendorFileType),
                                                                        KMS_KEY_ID);

                //create JODI response
                return new JODIResponse()
                {
                    ContentType = contentType,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<FirstQuoteGuaranteeServiceRequest>(contentType, request.MockServiceRequest)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the PostMockHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, "mock");
            }
            finally
            {
                FunctionTimer.Stop();
            }
        }

        #endregion

        #region Private Initializers

        private void InitializeHttpClient()
        {
            if (HttpClients == null)
            {
                lock (HttpClientLock)
                {
                    if (HttpClients == null)
                    {
                        HttpClients = new ConcurrentDictionary<string, HttpClient>();
                    }
                }
            }
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        MethodLookup = new List<Method>();

                        Method getMethod = new Method
                        {
                            InvokeFunction = GetHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/report$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(getMethod);

                        Method postMethod = new Method
                        {
                            InvokeFunction = PostHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/order$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(postMethod);

                        Method healthMethod = new Method
                        {
                            InvokeFunction = HealthCheckHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/health$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(healthMethod);

                        Method pingMethod = new Method
                        {
                            InvokeFunction = PingHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/ping$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(pingMethod);

                        Method mockMethod = new Method
                        {
                            InvokeFunction = PostMockHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/mock$", SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(mockMethod);
                    }
                }
            }

        }

        private JODIResponse CreateJODIErrorResponse(string errorMsg, int statusCode, string contentType, string transactionID)
        {
            return new JODIResponse()
            {
                ContentType = contentType,
                ErrorMessage = new JODIErrorResponse()
                {
                    Error = string.Format("{0}  TransactionID={1}", errorMsg, transactionID),
                    HttpStatus = statusCode
                }
            };
        }

        #endregion


        
    }
}

param(
	$options 
)

$s = @{
	Name = "LiensJudgmentsService"
	Target = "../"
	Include = @{ 
		"FAMS.LiensJudgmentsService" = @("**/**")		
		".cb" = @(@{
			"." = "buildspec.yml"
		})
	}
	AWS = @{
        s3 = @{
			Zip = $true
			Bucket = "fams-deployment-packages-w2"
			KeyPrefix = "codebuild/source/"
			Key = "3f1be3f4-cec2-434f-96af-b9883ff0b9f0"
		}
		CodeBuild= @{
			Region = "us-west-2"
		}
	}
}

#requireps boot-stap
$Base64 = "JHRlbXBQYXRoID0gSm9pbi1QYXRoIChbU3lzdGVtLklPLlBhdGhdOjpHZXRUZW1wUGF0aCgpKSAtQ2hpbGRQYXRoICI1MjI1Zjk2MWRiMjM0ZjNjYWEyNWZmMGViYjE4MGQxMC9yZXF1aXJlLnBzMSINCiRkaXIgPSBbc3lzdGVtLmlvLlBhdGhdOjpHZXREaXJlY3RvcnlOYW1lKCAkdGVtcFBhdGggKQ0KaWYoIC1ub3QgKFRlc3QtUGF0aCAtUGF0aCAkZGlyICkgKSB7IG1rZGlyICRkaXIgfQ0KSW52b2tlLVdlYlJlcXVlc3QgLVVyaSAJImh0dHBzOi8vaXR4Y2RuLnMzLmFtYXpvbmF3cy5jb20vZ2xpYi9wcy9yZXF1aXJlLnBzMSIgLU91dEZpbGUgJHRlbXBQYXRoIC1Qcm94eSAkcHJveHkNCi4gJHRlbXBQYXRo"
Invoke-Expression ([System.Text.Encoding]::ASCII.GetString([System.Convert]::FromBase64String($Base64))) | Out-Null
.  (_requireps "kissdeploy.ps1") 

kiss-deploy $s $options --whatif
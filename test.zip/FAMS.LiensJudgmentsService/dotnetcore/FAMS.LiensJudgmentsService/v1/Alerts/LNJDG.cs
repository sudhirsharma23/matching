﻿using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.Enums;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.LiensJudgmentsService.v1.Models.Service;
using FAMS.LiensJudgmentsService.v1.UseCases.Analytics;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;

namespace FAMS.LiensJudgmentsService.v1.Alerts
{
    public class LNJDG : AlertRule
    {
        private const string ALERT_CODE = "LNJDG";
        private const string ALERT_DESC = "POTENTIAL CREDIT RISK - Borrower(s) may have an open judgement or outstanding tax lien.";
        private Alert AlertResult;

        public LNJDG()
        {
            AlertResult = new Alert()
            {
                Code = ALERT_CODE,
                Description = ALERT_DESC,
                Status = Status.NotEvaluated,
                Evidence = new List<SerializableDictionary<string, object>>()
            };
        }

        public override void ExecuteLogic(LiensJudgmentsServiceRequest serviceRequest, LiensJudgmentsServiceResponse serviceResponse, LoggingAssistant logger)
        {
            List<SerializableDictionary<string, object>> evidenceList = new List<SerializableDictionary<string, object>>();
            List<dynamic> facts = new List<dynamic>();
            AlertResult.Status = Status.NotFired;

            if (serviceResponse != null && serviceResponse.Records != null && serviceResponse.Records.Count > 0)
            {
                foreach (var result in serviceResponse.Records)
                {
                    if (result != null)
                    {
                        SerializableDictionary<string, object> evidence = new SerializableDictionary<string, object>();
                        dynamic alertFacts = new ExpandoObject();

                        try
                        {
                            alertFacts.LogicStep = 1;
                            alertFacts.LogicExp = "Get Origin Filing Date.";
                            alertFacts.ExternalScoreCode = ALERT_CODE;

                            string odate = string.Format("{0}/{1}/{2}", result.OriginFilingDate.Month, result.OriginFilingDate.Day, result.OriginFilingDate.Year);
                            DateTime.TryParse(odate, out DateTime originFilingDate);

                            int.TryParse(result.Amount, out int amount);

                            alertFacts.LogicStep = 2;
                            alertFacts.LogicExp = "Check for null release date and amount >= $1.";

                            if (result.ReleaseDate == null && amount >= 1)
                            {
                                alertFacts.Status = AlertResult.Status = Status.Fired;
                                alertFacts.Reason = string.Format("The release date did not have a value and amount was >= $1 ({0}).", amount);

                                evidence.Add("OriginFilingType", result.OriginFilingType);
                                evidence.Add("OriginFilingNumber", result.OriginFilingNumber);
                                evidence.Add("OriginFilingDate", originFilingDate.ToShortDateString());
                                evidence.Add("Amount", result.Amount);
                                evidenceList.Add(evidence);
                            }
                            else
                            {
                                string rDate = string.Format("{0}/{1}/{2}", result.ReleaseDate.Month, result.ReleaseDate.Day, result.ReleaseDate.Year);
                                DateTime.TryParse(rDate, out DateTime releaseDate);

                                alertFacts.Reason = string.Format("The release date was present ({0}) and the amount was >= $1 ({1})", releaseDate.ToShortDateString(), result.Amount);
                            }
                        }
                        catch (Exception ex)
                        {
                            alertFacts.Error = ex.Message;
                            string msg = string.Format("Error running Liens & Judgments alert, {0}.", ALERT_CODE);
                            logger.LogServiceError(ex, msg, 0);
                        }
                        finally
                        {
                            alertFacts.Status = AlertResult.Status;
                            facts.Add(alertFacts);
                            AnalyticsAssistant.EmitAlertFacts(alertFacts, logger, ALERT_CODE);
                        }
                    }
                }

                AlertResult.Evidence = (evidenceList.Count > 0) ? evidenceList : null;
                serviceResponse.Alerts.Add(AlertResult);
            }
        }
    }
}

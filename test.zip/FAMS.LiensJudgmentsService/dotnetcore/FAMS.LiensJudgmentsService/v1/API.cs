using Amazon.DynamoDBv2;
using Amazon.Lambda.Core;
using Amazon.S3;
using Amazon.SecretsManager.Extensions.Caching;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.LiensJudgmentsService.v1.Models.Service;
using FAMS.LiensJudgmentsService.v1.Models.Vendor;
using FAMS.LiensJudgmentsService.v1.UseCases.Analytics;
using FAMS.LiensJudgmentsService.v1.UseCases.Service;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace FAMS.LiensJudgmentsService.v1
{
    public class API
    {
        static ConcurrentDictionary<string, HttpClient> HttpClients;
        static object HttpClientLock = new object();

        static List<Method> MethodLookup;
        static object MethodLock = new object();

        AlertUseCase AlertUseCase;
        ServiceUseCase ServiceUseCase;
        const string API_VERSION = "v1";



        #region Constructors
        public API()
        {
            ServiceUseCase = new ServiceUseCase();
            AlertUseCase = new AlertUseCase();

            InitializeMethodLookup();
            InitializeHttpClient();
        }


        //Used for testing purposes
        public API(IAmazonS3 s3Client, IAmazonDynamoDB dbClient, SecretsManagerCache secretsClient)
        {
            ServiceUseCase = new ServiceUseCase(s3Client, dbClient, secretsClient);
            AlertUseCase = new AlertUseCase();

            InitializeMethodLookup();
            InitializeHttpClient();
        }
        #endregion

        #region Function Handlers
        /// <summary>
        /// Routing handler for the lambda functions.  This is the one method that the lambda will call directly, then based on HTTP Method and URI, this method will invoke the correct function to call.
        /// </summary>
        /// <param name="jodiRequest">Stream of JODIRequest. Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>Stream of JODI response.  The service response is b64 encoded in the body </returns>
        public async Task<Stream> RouteHandler(Stream jodiRequestStream, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            JODIRequest request = null;
            JODIResponse response = null;
            MemoryStream responseStream = new MemoryStream();


            try
            {
                request = SerializationAssistant.DeserializeJson<JODIRequest>(jodiRequestStream);
                ServiceUseCase.InitializeUseCase(context, request);
                AlertUseCase.Logger = ServiceUseCase.Logger;

                if (request == null)
                    throw new Exception("Unable to deserialize to JODIRequest object.");


                Method method = JODIAssistant.FindMethod(MethodLookup, request);

                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},Supported Methods=GET,POST",
                                              ServiceUseCase.RequestMetaData.Path,
                                              string.Join(",", MethodLookup.Select(a => a.Path)),
                                              ServiceUseCase.RequestMetaData.HttpMethod);
                    throw new Exception(errorMsg);
                }

                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                responseStream.Position = 0;

                return responseStream;
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex,
                                                 string.Format("Failure in the RouteHandler. JODIRequest={0}", JODIAssistant.StreamToJson(jodiRequestStream)),
                                                 FunctionTimer.ElapsedMilliseconds);


                response = CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, ServiceUseCase.RequestMetaData.Accept, ServiceUseCase.RequestMetaData.TransactionID);
                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                return responseStream;
            }
            finally
            {
                FunctionTimer.Stop();

                if (GlobalConfiguration.LOG_JODI)
                {
                    ServiceUseCase.Logger.LogJsonObject<JODIRequest>(request);
                    ServiceUseCase.Logger.LogJsonObject<JODIResponse>(response);
                }

                ServiceUseCase.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }

        /// <summary>
        /// GET - retrieve vendor response by Company ID & Transaction ID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> GetHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string transactionID = string.Empty;

            jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);
            try
            {
                var ljTrans = await ServiceUseCase.GetDynamoDBTransaction<LnJTransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transactionID);

                if (ljTrans == null ||
                    string.IsNullOrEmpty(ljTrans.ResponseS3Key) ||
                    !ljTrans.GlobalID.Equals(ServiceUseCase.RequestMetaData.GlobalID, StringComparison.OrdinalIgnoreCase)
                    || ljTrans.HttpStatus != 200)
                {
                    return new JODIResponse() { HttpStatus = (int)HttpStatusCode.NotFound };
                }

                LiensJudgmentsServiceResponse response = await ServiceUseCase.GetResponse(ljTrans.ResponseS3Key);

                if (!ServiceUseCase.RequestMetaData.Diagnostics)
                {
                    response.Diagnostics = null;
                }

                //if accept isn't a valid content type, set accept to content type of response saved in S3
                string accept = JODIAssistant.SetValidAcceptType(ServiceUseCase.RequestMetaData.Accept, ljTrans.ResponseS3Key);

                if (response == null)
                    throw new Exception(string.Format("Service Response not found in S3. Key={0},Bucket={1}", ljTrans.ResponseS3Key, GlobalConfiguration.S3_BUCKET));
                else
                    return new JODIResponse()
                    {
                        ContentType = accept,
                        HttpStatus = (int)HttpStatusCode.OK,
                        ResponseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsServiceResponse>(accept, response)
                    };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, "Failure in the GetHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)HttpStatusCode.InternalServerError, ServiceUseCase.RequestMetaData.Accept, transactionID);
            }
            finally
            {
                FunctionTimer.Stop();

                ServiceUseCase.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }

        /// <summary>
        /// GET - retrieve pdf vendor response by Company ID & Transaction ID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> GetPdfHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string transactionID = string.Empty;


            jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);
            try
            {
                var ljTrans = await ServiceUseCase.GetDynamoDBTransaction<LnJTransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transactionID);

                if (ljTrans == null ||
                    string.IsNullOrEmpty(ljTrans.ResponseS3Key) ||
                    !ljTrans.GlobalID.Equals(ServiceUseCase.RequestMetaData.GlobalID, StringComparison.OrdinalIgnoreCase)
                    || ljTrans.HttpStatus != 200)
                {
                    return new JODIResponse() { HttpStatus = (int)HttpStatusCode.NotFound };
                }

                List<Task> task = new List<Task>();

                var responseTask = ServiceUseCase.SearchS3ByKey<LiensJudgmentsServiceResponse>(GlobalConfiguration.S3_BUCKET, ljTrans.RedactedResponseS3Key, true);
                var requestTask = ServiceUseCase.SearchS3ByKey<LiensJudgmentsServiceRequest>(GlobalConfiguration.S3_BUCKET, ljTrans.RedactedRequestS3Key, true);

                List<Task> tasks = new List<Task>()
                {
                    { responseTask }, { requestTask }
                };

                await Task.WhenAll(task.ToList());

                LiensJudgmentsServiceResponse response = responseTask.Result;
                LiensJudgmentsServiceRequest request = requestTask.Result;

                //if accept isn't a valid content type, set accept to content type of response saved in S3
                string accept = JODIAssistant.SetValidAcceptType(ServiceUseCase.RequestMetaData.Accept, ljTrans.ResponseS3Key);

                if (response == null)
                    throw new Exception(string.Format("Service Response not found in S3. Key={0},Bucket={1}", ljTrans.ResponseS3Key, GlobalConfiguration.S3_BUCKET));
                else
                {
                    var orderinfo = new Dictionary<string, string>()
                    {
                        { "Name", ServiceUseCase.RequestMetaData.CompanyName },
                        { "ReferenceNumber", transactionID }
                    };

                    string pdfResponse = await ServiceUseCase.ProcessBase64PDF(GlobalConfiguration.PDF_UTILITY_URL, PDFReport.liensandjudgments.ToString(), orderinfo, response, request);

                    return new JODIResponse()
                    {
                        ContentType = accept,
                        HttpStatus = (int)HttpStatusCode.OK,
                        ResponseBody = JODIAssistant.SerializeBodyToB64(accept, pdfResponse)
                    };
                }
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, "Failure in the GetPdfHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)HttpStatusCode.InternalServerError, ServiceUseCase.RequestMetaData.Accept, transactionID);
            }
            finally
            {
                FunctionTimer.Stop();

                ServiceUseCase.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }


        /// <summary>
        /// POST - make request to vendor and map to service response
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. The actual service request is b64 encoded in the  body</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> PostHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            LienJudgmentSearchResponseEnvelope lexisResponse = null;
            LiensJudgmentsServiceResponse serviceResponse = null;

            HttpResponseMessage httpResponse = null;
            VendorCall vendorCall = null;
            bool savingToDB = false;

            LnJTransactionRecord<VendorCall> ljTrans = new LnJTransactionRecord<VendorCall>();
            List<string> addOns = new List<string>();
            LiensJudgmentsServiceRequest serviceRequest = ServiceUseCase.GetServiceRequestFromJODI<LiensJudgmentsServiceRequest>(jodiRequest, FunctionTimer);
            VendorConfiguration vendorConfig = null;
            try
            {
                string vendorFileType = "json";

                ljTrans.TransactionID = ServiceUseCase.RequestMetaData.TransactionID;

                if (serviceRequest == null)
                    return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, ServiceUseCase.RequestMetaData.Accept, ServiceUseCase.RequestMetaData.TransactionID);

                //Get Persona Info
                ljTrans.CompanyName = ServiceUseCase.RequestMetaData.CompanyName;
                ljTrans.RequestorID = serviceRequest?.RequestorID;
                ljTrans.ClientID = ServiceUseCase.RequestMetaData.ClientID;
                ljTrans.GlobalID = ServiceUseCase.RequestMetaData.GlobalID;
                ljTrans.PortalCode = ServiceUseCase.RequestMetaData.PortalCode;
                ljTrans.AppPlan = ServiceUseCase.RequestMetaData.ApplicationPlan;
                ljTrans.ServiceName = GlobalConfiguration.SERVICE_ZONE_NAME;


                var validationErrorResponse = ServiceUseCase.BuildValidationErrorResponse(serviceRequest, ljTrans, FunctionTimer);
                if (validationErrorResponse != null)
                    return validationErrorResponse;

                ljTrans.RequestS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.SERVICE_REQUEST_FOLDER, API_VERSION, ljTrans.TransactionID, ServiceUseCase.RequestMetaData.ContentFileType);
                await ServiceUseCase.SaveToS3<LiensJudgmentsServiceRequest>(serviceRequest, ljTrans.RequestS3Key);

                if (ServiceUseCase.IsMockRequest(serviceRequest, ljTrans.AppPlan))
                {
                    ljTrans.DataSource = DataSource.Mock.ToString();

                    //check for mock by mock key
                    lexisResponse = await ServiceUseCase.GetMockedResponseFromS3(GlobalConfiguration.S3_BUCKET,
                                                                          ServiceUseCase.BuildS3Key(GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, ServiceUseCase.ComputeMockKey(serviceRequest.Person), vendorFileType));

                    //no mock response found(expired or never created)
                    if (lexisResponse == null)
                    {
                        ljTrans.HttpStatus = (int)HttpStatusCode.NotFound;
                        return new JODIResponse()
                        {
                            HttpStatus = (int)HttpStatusCode.NotFound
                        };
                    }
                }
                else
                {
                    LienJudgmentSearchRequestEnvelope lexisRequest = ServiceUseCase.MapServiceRequestToVendorRequest(serviceRequest, ljTrans.TransactionID, ljTrans.PortalCode);
                    ljTrans.CacheKey = ServiceUseCase.ComputeCacheKey(ljTrans.GlobalID, serviceRequest.Person);
                    ljTrans.SubjectFirstName = serviceRequest?.Person?.Name?.First;
                    ljTrans.SubjectLastOrCompanyName = serviceRequest?.Person?.Name?.Last;
                    Dictionary<string, VendorConfiguration> serviceConfig = ServiceUseCase.GetVendorConfiguration();
                    if (serviceConfig == null)
                        throw new Exception(string.Format("No service configuration file found. PortalCode={0}", ljTrans.PortalCode));

                    vendorConfig = serviceConfig?.Values?.Where(x => x.Priority == 1)?.FirstOrDefault();
                    await ServiceUseCase.GetVendorCredentials(vendorConfig);
                    ljTrans.Product = vendorConfig.VendorProduct;

                    //check cache
                    var cacheLimit = serviceRequest.CachePeriod != null ? serviceRequest.CachePeriod : vendorConfig.CachePeriodDays;

                    lexisResponse = await ServiceUseCase.SearchS3ByKey<LienJudgmentSearchResponseEnvelope>(GlobalConfiguration.S3_BUCKET,
                                                                                                    ServiceUseCase.BuildS3Key(GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, ljTrans.CacheKey, vendorFileType),
                                                                                                    false,
                                                                                                    cacheLimit);

                    if (lexisResponse == null) //no cache
                    {
                        ljTrans.DataSource = DataSource.Vendor.ToString();

                        vendorCall = new VendorCall
                        {
                            Name = vendorConfig.VendorCode,
                            Product = vendorConfig.VendorProduct,
                            Sequence = 1,
                            RequestS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.VENDOR_REQUEST_FOLDER, API_VERSION, ljTrans.CacheKey, vendorFileType),
                            DateTimeUTC = DateTime.UtcNow
                        };

                        await ServiceUseCase.SaveToS3<LienJudgmentSearchRequestEnvelope>(lexisRequest, vendorCall.RequestS3Key, vendorConfig.CachePeriodDays, null, LifeSpan.NinetyDays);

                        if (!string.IsNullOrWhiteSpace(vendorConfig?.Login) && !string.IsNullOrWhiteSpace(vendorConfig?.Password))
                        {
                            HttpClient client = ServiceUseCase.InitializeHttpClient(HttpClients, vendorConfig, ServiceUseCase.RequestMetaData.PortalCode);
                            httpResponse = await ServiceUseCase.CallVendor(client, lexisRequest, vendorConfig.URL, vendorCall);
                            vendorCall.HttpStatus = (int)httpResponse.StatusCode;
                            vendorCall.ResponseS3Key = ServiceUseCase.BuildS3Key(GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, ljTrans.CacheKey, vendorFileType);
                            ljTrans.VendorCalls = new List<VendorCall> { vendorCall };

                            //always save vendor response.
                            string content = await httpResponse.Content.ReadAsStringAsync();
                            if (httpResponse.IsSuccessStatusCode)
                            {
                                lexisResponse = SerializationAssistant.DeserializeJson<LienJudgmentSearchResponseEnvelope>(content);
                                await ServiceUseCase.SaveToS3<LienJudgmentSearchResponseEnvelope>(lexisResponse, vendorCall.ResponseS3Key, vendorConfig.CachePeriodDays, null, LifeSpan.NinetyDays);
                            }
                            else
                            {
                                await ServiceUseCase.SaveToS3<string>(content, vendorCall.ResponseS3Key, vendorConfig.CachePeriodDays, null, LifeSpan.NinetyDays);

                                ServiceUseCase.Errors = "Invalid Vendor Response";

                            }
                        }
                    }
                    else //found cache
                    {
                        ljTrans.OriginalTransactionID = lexisResponse?.LienJudgmentSearchResponseEx?.response?.Header?.QueryId;
                        ljTrans.DataSource = DataSource.Cache.ToString();
                    }
                }

                //create the service response from vendor or mocked response
                serviceResponse = ServiceUseCase.CreateServiceResponse(serviceRequest, lexisResponse, ljTrans, vendorConfig, FunctionTimer.ElapsedMilliseconds);

                if (serviceResponse != null && serviceRequest.IncludeAnalytics)
                {
                    addOns.Add(AddOns.Analytics.ToString());
                    serviceResponse.Alerts = new List<Alert>();
                    AlertUseCase.ExecuteAlerts(serviceRequest, serviceResponse);
                }

                //do this before redaction
                string responseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsServiceResponse>(ServiceUseCase.RequestMetaData.Accept, serviceResponse);

                await ServiceUseCase.RedactAndSaveToS3(serviceRequest, serviceResponse, ljTrans);

                //save transaction record to DB
                FunctionTimer.Stop();
                ljTrans.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                ljTrans.DateTimeUTC = DateTime.UtcNow;
                ljTrans.AddOns = addOns;
                ljTrans.HttpStatus = (int)HttpStatusCode.OK;

                savingToDB = true;
                await ServiceUseCase.SaveDynamoDBTransaction<LnJTransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, ljTrans, ljTrans.TransactionID);

                //create JODI response
                return new JODIResponse()
                {
                    ContentType = ServiceUseCase.RequestMetaData.Accept,
                    HttpStatus = ljTrans.HttpStatus,
                    ResponseBody = responseBody
                };
            }
            catch (Exception ex)
            {
                FunctionTimer.Stop();
                ljTrans.HttpStatus = (int)HttpStatusCode.InternalServerError;
                ljTrans.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                ljTrans.DateTimeUTC = DateTime.UtcNow;
                ljTrans.VendorCalls = vendorCall != null ? new List<VendorCall> { vendorCall } : null;

                try
                {
                    //try to save transaction as long as we didnt fail on the save in the original try block
                    if (!savingToDB)
                        await ServiceUseCase.SaveDynamoDBTransaction<LnJTransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, ljTrans, ljTrans.TransactionID);

                    return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, ServiceUseCase.RequestMetaData.Accept, ljTrans.TransactionID);
                }
                finally
                {
                    ServiceUseCase.Logger.LogServiceError(ex, "Failure in the PostHandler", FunctionTimer.ElapsedMilliseconds);
                }
            }
            finally
            {
                ServiceUseCase.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }


        /// <summary>
        /// A simple health check(check S3/Dynamo are active + make echotest call to vendor)
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the health check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse> HealthCheckHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            string contentType = "application/json";

            try
            {
                HealthCheck healthCheck = await ServiceUseCase.RunHealthCheck(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.S3_BUCKET, GlobalConfiguration.DYNAMO_TABLE);

                string portalCode = ServiceUseCase.RequestMetaData.PortalCode;
                //ServiceConfiguration config = ServiceUseCase.GetServiceConfiguration(portalCode, GlobalConfiguration.ENVIRONMENT);
                Dictionary<string, VendorConfiguration> config = ServiceUseCase.GetVendorConfiguration();
                if (config == null)
                    throw new Exception(string.Format("No service configuration file found. PortalCode={0}", portalCode));

                if (config.Keys != null)
                {
                    foreach (var vendor in config)
                    {
                        HealthCheckComponent vendorComponent = new HealthCheckComponent()
                        {
                            Name = vendor.Key,
                            Type = ComponentType.Vendor
                        };


                        VendorConfiguration vendorConfig = vendor.Value;

                        if (vendorConfig == null)
                        {
                            vendorComponent.Status = ComponentStatus.Red;
                            vendorComponent.Information = new Dictionary<string, string>()
                            {
                                {"Error", $"No vendor configuration found in service config. PortalCode={portalCode}" }
                            };
                        }
                        else
                        {
                            await ServiceUseCase.GetVendorCredentials(vendorConfig);
                            //vendor test
                            var echoRqstEnvelope = new EchoTestRequestEnvelope()
                            {
                                EchoTestRequest = new EchoTestRequest()
                                {
                                    ValueIn = "ECHO"
                                }
                            };

                            HttpClient client = ServiceUseCase.InitializeHttpClient(HttpClients, vendorConfig, portalCode);
                            Stopwatch s1 = new Stopwatch();
                            s1.Start();
                            HttpResponseMessage response = await ServiceUseCase.CallVendor(client, echoRqstEnvelope, vendorConfig.Configurations["HealthcheckURL"].ToString());
                            s1.Stop();
                            string content = await response.Content.ReadAsStringAsync();

                            vendorComponent.Information = new Dictionary<string, string>()
                                {
                                    {"URL", vendorConfig.Configurations["HealthcheckURL"].ToString()},
                                    {"ResponseStatus", ((int)response.StatusCode).ToString() },
                                    {"ResponseTimeMS", s1.ElapsedMilliseconds.ToString()}
                                };


                            if (!response.IsSuccessStatusCode)
                            {
                                vendorComponent.Status = ComponentStatus.Red;
                                vendorComponent.Information.Add("Error", $"Error communicating with vendor. Status={(int)response.StatusCode},Message={response.ReasonPhrase}");
                            }
                            else
                            {
                                EchoTestResponseEnvelope echoResponse = SerializationAssistant.DeserializeJson<EchoTestResponseEnvelope>(content);

                                string valueOut = echoResponse?.EchoTestResponse?.ValueOut;

                                if (string.IsNullOrEmpty(valueOut) || !valueOut.Equals(echoRqstEnvelope.EchoTestRequest.ValueIn))
                                {
                                    vendorComponent.Status = ComponentStatus.Red;
                                    vendorComponent.Information.Add("Error", $"Echo Test results doesn't match up.ValueIn={echoRqstEnvelope.EchoTestRequest.ValueIn},ValueOut={valueOut}");

                                }
                                else if (echoResponse.EchoTestResponse.ValueOut.Equals(echoRqstEnvelope.EchoTestRequest.ValueIn))
                                    vendorComponent.Status = ComponentStatus.Green;
                            }
                        }

                        healthCheck.Components.TryAdd("VendorCall", vendorComponent);


                        if (vendorComponent.Status == ComponentStatus.Red)
                            healthCheck.ServiceStatus = ComponentStatus.Red;
                    }
                }


                return new JODIResponse()
                {
                    HttpStatus = healthCheck.ServiceStatus == ComponentStatus.Red ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK,
                    ContentType = "application/json",
                    ResponseBody = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, healthCheck)
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, "Health check failed", -1);
                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, ServiceUseCase.RequestMetaData.TransactionID);
            }
        }

        private async Task<JODIResponse> PingHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            return JODIAssistant.SetPingTestResponse();
        }

        /// <summary>
        /// Creates mock vendor responses and returns back the service request to get that mock response.
        /// </summary>
        /// <param name="request">A service mock object containing the service request + mocked vendor response</param>
        /// <param name="context"></param>
        /// <returns>The service request that was passed in. This will be used as the body of the POST request to the service.</returns>
        private async Task<JODIResponse> PostMockHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string contentType = "application/json";

            LiensJudgmentsServiceMock request = ServiceUseCase.GetServiceRequestFromJODI<LiensJudgmentsServiceMock>(jodiRequest, FunctionTimer);

            if (request == null)
                return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, contentType, ServiceUseCase.RequestMetaData.TransactionID);

            try
            {
                var vendorFileType = "json";

                string mockKey = ServiceUseCase.ComputeMockKey(request.MockServiceRequest.Person);

                //saving as string so we can submit malformed JSON for testing purposes
                if (request.MockVendorResponseJson != null)//otherwise save as json as its easier to modify
                {
                    await ServiceUseCase.SaveToS3<LienJudgmentSearchResponseEnvelope>(request.MockVendorResponseJson,
                                                                       ServiceUseCase.BuildS3Key(GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, mockKey, vendorFileType));
                }
                else
                {
                    throw new Exception("MockVendorResponseJson is null. Nothing to mock.");
                }


                //create JODI response
                return new JODIResponse()
                {
                    ContentType = contentType,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsServiceRequest>(contentType, request.MockServiceRequest)
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, "Failure in the PostMockHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, ServiceUseCase.RequestMetaData.TransactionID);
            }
            finally
            {
                FunctionTimer.Stop();
            }
        }

        public async Task<JODIResponse> DebugHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch functionTimer = new Stopwatch();
            functionTimer.Start();

            JODIResponse response = null;
            string transactionID = string.Empty;

            try
            {
                jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);

                if (string.IsNullOrEmpty(transactionID))
                    return CreateJODIErrorResponse("transactionID is empty in query string.", 400, ServiceUseCase.RequestMetaData.Accept, string.Empty);

                LnJTransactionRecord<VendorCall> transactionRecord = await ServiceUseCase.GetDynamoDBTransaction<LnJTransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transactionID);
                if (transactionRecord == null)
                    return CreateJODIErrorResponse("Order not found.", 404, ServiceUseCase.RequestMetaData.Accept, string.Empty);

                List<Task> taskList = new List<Task>();
                var serviceRequestTask = ServiceUseCase.GetFromS3<LiensJudgmentsServiceRequest>(GlobalConfiguration.S3_BUCKET, transactionRecord.RequestS3Key);
                var serviceResponseTask = ServiceUseCase.GetFromS3<LiensJudgmentsServiceResponse>(GlobalConfiguration.S3_BUCKET, transactionRecord.ResponseS3Key);

                Task<LiensJudgmentsServiceRequest> redactedServiceRequestTask = null;
                Task<LiensJudgmentsServiceResponse> redactedServiceResponseTask = null;

                if (!string.IsNullOrEmpty(transactionRecord.RedactedRequestS3Key))
                {
                    redactedServiceRequestTask = ServiceUseCase.GetFromS3<LiensJudgmentsServiceRequest>(GlobalConfiguration.S3_BUCKET, transactionRecord.RedactedRequestS3Key);
                    taskList.Add(redactedServiceRequestTask);
                }
                if (!string.IsNullOrEmpty(transactionRecord.RedactedResponseS3Key))
                {
                    redactedServiceResponseTask = ServiceUseCase.GetFromS3<LiensJudgmentsServiceResponse>(GlobalConfiguration.S3_BUCKET, transactionRecord.RedactedResponseS3Key);
                    taskList.Add(redactedServiceResponseTask);
                }

                VendorCall vendorCall = transactionRecord?.VendorCalls?.FirstOrDefault();
                Task<LienJudgmentSearchRequestEnvelope> vendorRequestTask = null;
                Task<LienJudgmentSearchResponseEnvelope> vendorResponseTask = null;

                if (vendorCall != null)
                {
                    vendorRequestTask = ServiceUseCase.GetFromS3<LienJudgmentSearchRequestEnvelope>(GlobalConfiguration.S3_BUCKET, vendorCall.RequestS3Key);
                    vendorResponseTask = ServiceUseCase.GetFromS3<LienJudgmentSearchResponseEnvelope>(GlobalConfiguration.S3_BUCKET, vendorCall.ResponseS3Key);
                    taskList.Add(vendorRequestTask);
                    taskList.Add(vendorResponseTask);
                }

                taskList.Add(serviceRequestTask);
                taskList.Add(serviceResponseTask);

                await Task.WhenAll(taskList);

                var debugResponse = new LiensJudgmentsServiceDebug()
                {
                    ServiceRequest = serviceRequestTask?.Result,
                    ServiceResponse = serviceResponseTask?.Result,
                    RedactedServiceRequest = redactedServiceRequestTask?.Result,
                    RedactedServiceResponse = redactedServiceResponseTask?.Result,
                    TransactionRecord = transactionRecord,
                    VendorRequest = vendorRequestTask?.Result,
                    VendorResponse = vendorResponseTask?.Result
                };

                //create JODI response
                return new JODIResponse()
                {
                    ContentType = ServiceUseCase.RequestMetaData.Accept,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<LiensJudgmentsServiceDebug>(ServiceUseCase.RequestMetaData.Accept, debugResponse)
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, $"Failure in the DebugHandler. TransactionID={transactionID}", functionTimer.ElapsedMilliseconds);

                response = CreateJODIErrorResponse("An error has occurred.", 500, ServiceUseCase.RequestMetaData.Accept, ServiceUseCase.RequestMetaData.TransactionID);
            }
            finally
            {
                ServiceUseCase.Logger.LogFunctionExecutionTime(functionTimer.ElapsedMilliseconds);
            }

            return response;
        }

        public async Task<JODIResponse> RedactHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string contentType = "application/json";

            LiensJudgmentsRedaction request = ServiceUseCase.GetServiceRequestFromJODI<LiensJudgmentsRedaction>(jodiRequest, FunctionTimer);

            if (request == null)
                return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, contentType, ServiceUseCase.RequestMetaData.TransactionID);

            try
            {
                if (request.IsLatest)
                    await ServiceUseCase.LegacyRedact(request.S3Key, request.VersionID);
                else
                    await ServiceUseCase.DeleteFromS3(request.S3Key, request.VersionID);

                //create JODI response
                return new JODIResponse()
                {
                    HttpStatus = (int)HttpStatusCode.OK
                };
            }
            catch (Exception ex)
            {
                ServiceUseCase.Logger.LogServiceError(ex, "Failure in the RedactHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, ServiceUseCase.RequestMetaData.TransactionID);
            }
            finally
            {
                FunctionTimer.Stop();
            }
        }




        #endregion

        #region Private Initializers

        private void InitializeHttpClient()
        {
            if (HttpClients == null)
            {
                lock (HttpClientLock)
                {
                    if (HttpClients == null)
                    {
                        HttpClients = new ConcurrentDictionary<string, HttpClient>();
                    }
                }
            }
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        MethodLookup = new List<Method>();

                        Method getMethod = new Method
                        {
                            InvokeFunction = GetHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/{0})?/{1}/report$", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(getMethod);

                        Method getPdfMethod = new Method
                        {
                            InvokeFunction = GetPdfHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/{0})?/{1}/report/pdf$", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(getPdfMethod);

                        Method postMethod = new Method
                        {
                            InvokeFunction = PostHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/{0})?/{1}/order$", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(postMethod);

                        Method healthMethod = new Method
                        {
                            InvokeFunction = HealthCheckHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/{0})?/{1}/health$", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(healthMethod);

                        Method pingMethod = new Method
                        {
                            InvokeFunction = PingHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/{0})?/{1}/ping", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(pingMethod);

                        Method mockMethod = new Method
                        {
                            InvokeFunction = PostMockHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/{0})?/{1}/mock$", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(mockMethod);

                        Method debugMethod = new Method
                        {
                            InvokeFunction = DebugHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/{0})?/{1}/debug", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(debugMethod);

                        Method redactMethod = new Method
                        {
                            InvokeFunction = RedactHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/{0})?/{1}/redact", API_VERSION, GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(redactMethod);
                    }
                }
            }

        }

        private JODIResponse CreateJODIErrorResponse(string errorMsg, int statusCode, string contentType, string transactionID)
        {
            return new JODIResponse()
            {
                ContentType = contentType,
                ErrorMessage = new JODIErrorResponse()
                {
                    Error = string.Format("{0}  TransactionID={1}", errorMsg, transactionID),
                    HttpStatus = statusCode
                }
            };
        }

        #endregion
    }
}

﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using Amazon.S3;
using Amazon.S3.Model;
using FAMS.Common.API.Assistants;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;


[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]
namespace FAMS.LiensJudgmentsService.Redact
{
    public class Redaction
    {
        private IAmazonS3 _s3Client;
        private IAmazonDynamoDB _dbClient;
        private LoggingAssistant _logger;

        public Redaction()
        {
            _s3Client = new AmazonS3Client();
            _dbClient = new AmazonDynamoDBClient();
        }

        public Redaction(IAmazonS3 s3Client, IAmazonDynamoDB dbClient)
        {
            _s3Client = s3Client;
            _dbClient = dbClient;
        }


        private const string REDACT_LIFESPAN = "1d";

        public readonly string S3_BUCKET = Environment.GetEnvironmentVariable("S3_BUCKET");
        public readonly string DYNAMODB_TABLE = Environment.GetEnvironmentVariable("DYNAMODB_TABLE");
        public readonly string KMS_KEY_ID = Environment.GetEnvironmentVariable("KMS_KEY_ID");
        public readonly string SERVICE_REQUEST_FOLDER = "/ServiceRequests";
        public readonly string SERVICE_RESPONSE_FOLDER = "/ServiceResponses";
        public readonly string REDACTED_SERVICE_REQUEST_FOLDER = "/RedactedServiceRequests";
        public readonly string REDACTED_SERVICE_RESPONSE_FOLDER = "/RedactedServiceResponses";

        public async Task<BatchResponse> ProcessBatchEvent(BatchRequest batchEvent)
        {
            _logger = new LoggingAssistant("Redaction", "FAMS.LiensJudgmentsService", string.Empty, null);
            List<Result> taskResults = new List<Result>();

            foreach (var task in batchEvent.tasks)
            {
                try
                {
                    string s3Key = System.Web.HttpUtility.UrlDecode(task.s3Key);

                    string transactionID = Path.GetFileNameWithoutExtension(s3Key);

                    PutObjectResponse s3Response = null;
                    UpdateItemResponse dbResponse = null;


                    if (s3Key.Contains($"{SERVICE_REQUEST_FOLDER}/v1"))
                    {
                        await UpdateTag(s3Key, REDACT_LIFESPAN);

                        var rqst = await AWSAssistant.SearchS3ByKey<v1.Models.Service.LiensJudgmentsServiceRequest>(_s3Client, S3_BUCKET, s3Key);

                        rqst.Redact();

                        s3Key = s3Key.Replace(SERVICE_REQUEST_FOLDER, REDACTED_SERVICE_REQUEST_FOLDER);

                        s3Response = await AWSAssistant.SaveToS3(_s3Client, rqst, S3_BUCKET, s3Key, KMS_KEY_ID, 0, lifeSpan: LifeSpan.SevenYears);
                        dbResponse = await UpdateDynamo(transactionID, s3Key, "RedactedRequestS3Key");
                    }
                    else if (s3Key.Contains($"{SERVICE_REQUEST_FOLDER}/v2"))
                    {
                        await UpdateTag(s3Key, REDACT_LIFESPAN);

                        var getResponse = await _s3Client.GetObjectAsync(new GetObjectRequest
                        {
                            BucketName = S3_BUCKET,
                            Key = s3Key
                        });

                        v2.Models.Service.LiensJudgmentsServiceRequest rqst = null;

                        using (StreamReader sr = new StreamReader(getResponse.ResponseStream))
                        {
                            string type = getResponse?.Headers?.ContentType ?? string.Empty;

                            if (s3Key.Contains("json") || type.Contains("json"))
                            {
                                string s1 = sr.ReadToEnd();
                                rqst = SerializationAssistant.DeserializeJson<v2.Models.Service.LiensJudgmentsServiceRequest>(sr);
                            }
                            else if(s3Key.EndsWith("xml") || type.Contains("xml"))
                            {
                                rqst = SerializationAssistant.DeserializeXml<v2.Models.Service.LiensJudgmentsServiceRequest>(sr);
                            }
                        }

                        rqst.Redact();

                        s3Key = s3Key.Replace(SERVICE_REQUEST_FOLDER, REDACTED_SERVICE_REQUEST_FOLDER);

                        s3Response = await AWSAssistant.SaveToS3(_s3Client, rqst, S3_BUCKET, s3Key, KMS_KEY_ID, 0, lifeSpan: LifeSpan.SevenYears);
                        dbResponse = await UpdateDynamo(transactionID, s3Key, "RedactedRequestS3Key");
                    }
                    else if (s3Key.Contains($"{SERVICE_RESPONSE_FOLDER}/v1"))
                    {
                        await UpdateTag(s3Key, REDACT_LIFESPAN);

                        var response = await AWSAssistant.SearchS3ByKey<v1.Models.Service.LiensJudgmentsServiceResponse>(_s3Client, S3_BUCKET, s3Key);

                        response.Redact();

                        s3Key = s3Key.Replace(SERVICE_RESPONSE_FOLDER, REDACTED_SERVICE_RESPONSE_FOLDER);

                        s3Response = await AWSAssistant.SaveToS3(_s3Client, response, S3_BUCKET, s3Key, KMS_KEY_ID, 0, lifeSpan: LifeSpan.SevenYears);
                        dbResponse = await UpdateDynamo(transactionID, s3Key, "RedactedResponseS3Key");
                    }
                    else if (s3Key.Contains($"{SERVICE_RESPONSE_FOLDER}/v2"))
                    {
                        await UpdateTag(s3Key, REDACT_LIFESPAN);

                        var response = await AWSAssistant.SearchS3ByKey<v2.Models.Service.LiensJudgmentsServiceResponse>(_s3Client, S3_BUCKET, s3Key);

                        response.Redact();

                        s3Key = s3Key.Replace(SERVICE_RESPONSE_FOLDER, REDACTED_SERVICE_RESPONSE_FOLDER);

                        s3Response = await AWSAssistant.SaveToS3(_s3Client, response, S3_BUCKET, s3Key, KMS_KEY_ID, 0, lifeSpan: LifeSpan.SevenYears);
                        dbResponse = await UpdateDynamo(transactionID, s3Key, "RedactedResponseS3Key");
                    }

                    if (s3Response.HttpStatusCode != System.Net.HttpStatusCode.OK)
                        throw new Exception($"Failed to save redacted document to s3. s3key={s3Key}");

                    if (dbResponse.HttpStatusCode != System.Net.HttpStatusCode.OK)
                        throw new Exception($"Failed to save redacted key to dynamo. s3key={s3Key}");


                    taskResults.Add(new Result()
                    {
                        resultCode = "Succeeded",
                        resultString = s3Key,
                        taskId = task.taskId
                    });
                }
                catch (Exception ex)
                {
                    _logger.LogServiceError(ex, "Error for s3Key=" + task.s3Key, -1);

                    taskResults.Add(new Result()
                    {
                        resultCode = "PermanentFailure",
                        resultString = ex.Message,
                        taskId = task.taskId
                    });
                }

            }

            return new BatchResponse()
            {
                invocationId = batchEvent.invocationId,
                invocationSchemaVersion = batchEvent.invocationSchemaVersion,
                results = taskResults.ToArray()
            };
        }

        private async Task<UpdateItemResponse> UpdateDynamo(string transactionID, string s3Key, string fieldName)
        {
            var request = new UpdateItemRequest
            {
                TableName = DYNAMODB_TABLE,
                Key = new Dictionary<string, AttributeValue>() { { "TransactionID", new AttributeValue { S = transactionID } } },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>()
                {
                    {":rsk",new AttributeValue {S = s3Key}},
                },

                UpdateExpression = "SET " + fieldName + " = :rsk"
            };

            return await _dbClient.UpdateItemAsync(request);
        }

        private async Task<PutObjectTaggingResponse> UpdateTag(string s3Key, string lifespan)
        {
            List<Amazon.S3.Model.Tag> tag = new List<Amazon.S3.Model.Tag>()
            {
                new Amazon.S3.Model.Tag()
                {
                    Key = "LifeSpan",
                    Value = lifespan
                }
            };

            return await _s3Client.PutObjectTaggingAsync(new PutObjectTaggingRequest()
            {
                BucketName = S3_BUCKET,
                Key = s3Key,
                Tagging = new Tagging() { TagSet = tag }
            });
        }


    }

    public class BatchRequest
    {
        public string invocationSchemaVersion { get; set; }
        public string invocationId { get; set; }
        public Job job { get; set; }
        public Task[] tasks { get; set; }
    }

    public class Job
    {
        public string id { get; set; }
    }

    public class Task
    {
        public string taskId { get; set; }
        public string s3Key { get; set; }
        public string s3VersionId { get; set; }
        public string s3BucketArn { get; set; }
    }



    public class BatchResponse
    {
        public string invocationSchemaVersion { get; set; }
        public string treatMissingKeysAs { get; set; }
        public string invocationId { get; set; }
        public Result[] results { get; set; }
    }

    public class Result
    {
        public string taskId { get; set; }
        public string resultCode { get; set; }
        public string resultString { get; set; }
    }
}

var inc003 = require("../alerts/INC003.js");
var inc004 = require("../alerts/INC004.js");
var inc015 = require("../alerts/INC015.js");

module.exports.buildAlertResponseData = function (state) {
    state._tag = "alertUseCase";
    state._traceLog._className = "alertUseCase.js";
    state._traceLog._function = "execute all alert logic";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;

    return new Promise(function (resolve, reject) {

        let request = typeof state.canonicalServiceRequest === "string" ?
            JSON.parse(state.canonicalServiceRequest) :
            state.canonicalServiceRequest;

        if (request.IncludeAnalytics !== null
            && typeof request.IncludeAnalytics !== "undefined"
            && request.IncludeAnalytics === true) {

            state.canonicalServiceResponse.Alerts = [];
            inc003.ExecuteLogic(state);
            inc004.ExecuteLogic(state);
            inc015.ExecuteLogic(state);      
        }       
        else {
            if (typeof state.canonicalServiceResponse.Alerts !== "undefined") {
                delete state.canonicalServiceResponse.Alerts;
            }
        }

        resolve(state);
    });   
};


var xml2js = require('xml2js');
var parser1 = new xml2js.Parser({explicitRoot: false, explicitArray: false, mergeAttrs: true, valueProcessors: [xml2js.processors.parseNumbers] });
const S3Client = require("aws-sdk/clients/s3");
var awsAssistant = require("../Assistants/awsAssistant.js");

exports.redact = (state) => {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push("Redaction");
    state._traceLog._className = "redactUseCase.js";
    state._traceLog._function = "exports.redact";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    return new Promise((resolve, reject) =>{
        try{
            if(state.rawServiceRequest){
                if (state._requestHeaders["content-type"].includes('xml')){
                    parser1.parseString(state.rawServiceRequest, function (er, jsonRequest){
                        redactServiceRequest(jsonRequest);
                        var builder = new xml2js.Builder({explicitRoot: false, rootName : "IncomeEstimateRequest"});
                        var xml = builder.buildObject(jsonRequest);
                        state.redactedRawServiceRequest = xml;
                    });
                }
                else{
                    var jsonRequest = JSON.parse(state.rawServiceRequest);
                    redactServiceRequest(jsonRequest);
                    state.redactedRawServiceRequest = JSON.stringify(jsonRequest);
                }
            }
            resolve(state);
        }
        catch(err){
            let error = `Fail to redact. ${err.message}`;
            state._traceLog._type = "Error";
            state._traceLog._msg = error;
            reject(error);
        }
    });
}

function redactServiceRequest(request){
    if(request && request.Individual && request.Individual.DateOfBirth){
        let redactedDob = redactDateOfBirth(request.Individual.DateOfBirth);
        if(redactedDob){
            request.Individual.DateOfBirth = redactedDob;
        }
    }
}

function redactDateOfBirth(dob){
    if(dob){
        let year = dob.substring(dob.length - 4, dob.length);
        return `XX/XX/${year}`;
    }
    else{
        return null;
    }
}

exports.legacyRedact = (state) => {

    state._traceLog._tags = [];
    state._traceLog._ts = new Date();
    state._traceLog._tags.push("LegacyRedact");
    state._traceLog._className = "redactUseCase.js";
    state._traceLog._function = "LegacyRedact";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;


    return new Promise((resolve, reject) => {
        try{

            if(state.rawServiceRequest){

                var redactionRequest = JSON.parse(state.rawServiceRequest);
                var awsConfiguration = state["awsConfiguration"];
                var serviceLifeSpanTagValue = "180d";
                var serviceNoNPIDataLifespanTagValue = "7y";
                var vendorLifespanTagValue = "90d";
                var promises = [];

                if(redactionRequest.IsLatest){
                    if(redactionRequest.S3Key.includes("ServiceRequests")){
                        var transactionID = redactionRequest.S3Key.substring(redactionRequest.S3Key.lastIndexOf("/") + 1, redactionRequest.S3Key.length);
                        promises.push(awsAssistant.putS3ObjectTagging(redactionRequest.S3Key, awsConfiguration, "LifeSpan", serviceLifeSpanTagValue));

                        //Redact and save
                        var redactedRequest = "";
                        

                        GetResponseFromS3(redactionRequest.S3Key, awsConfiguration)
                        .then(s3Result => {                           
                            var contentType = s3Result.ContentType.toString();

                            if(contentType.includes("xml")){
                                parser1.parseString(s3Result.Body.toString(), function (er, jsonRequest){
                                    redactServiceRequest(jsonRequest);
                                    var builder = new xml2js.Builder({explicitRoot: false, rootName : "IncomeEstimateRequest"});
                                    var xml = builder.buildObject(jsonRequest);
                                    redactedRequest = xml;
                                });
                            }
                            else{
                                var jsonRequest = JSON.parse(s3Result.Body.toString());
                                redactServiceRequest(jsonRequest);
                                redactedRequest = JSON.stringify(jsonRequest);
                            }
                           
                            var redactedS3Key = redactionRequest.S3Key.replace(awsConfiguration.serviceRequestFolder, awsConfiguration.redactedServiceRequestFolder);
                            var tags = [{Key:"LifeSpan", Value: serviceNoNPIDataLifespanTagValue}];
                            promises.push(awsAssistant.uploadFiletoS3WithTagging(redactedRequest, redactedS3Key, contentType, awsConfiguration, tags));
    
                            //promises.push(awsAssistant.updateDataInDynamoDBWithRedaction(transactionID,awsConfiguration, "RedactedRequestS3Key",  redactedS3Key));
                        });

                        Promise.all(promises).then((data) => {
                            state._responseObject = {
                                httpStatus: 200,
                                responseBody: "Redaction Success",
                                "content-type": "application/json",
                                "isBase64Encoded": true
                            };
                            resolve(state);
                        }).catch(() => reject(state));

                    }
                    else if(redactionRequest.S3Key.includes("ServiceResponses"))
                    {
                        promises.push(awsAssistant.putS3ObjectTagging(redactionRequest.S3Key, awsConfiguration, "LifeSpan", serviceNoNPIDataLifespanTagValue));
                        Promise.all(promises).then((data) => {
                            state._responseObject = {
                                httpStatus: 200,
                                responseBody: "Redaction Success",
                                "content-type": "application/json",
                                "isBase64Encoded": true
                            };
                            resolve(state);
                        }).catch(() => reject(state));
                    }
                    else if(redactionRequest.S3Key.includes("VendorRequests"))
                    {
                        promises.push(awsAssistant.putS3ObjectTagging(redactionRequest.S3Key, awsConfiguration, "LifeSpan", vendorLifespanTagValue));
                        Promise.all(promises).then((data) => {
                            state._responseObject = {
                                httpStatus: 200,
                                responseBody: "Redaction Success",
                                "content-type": "application/json",
                                "isBase64Encoded": true
                            };
                            resolve(state);
                        }).catch(() => reject(state));
                    }
                    else if(redactionRequest.S3Key.includes("VendorResponses"))
                    {
                        promises.push(awsAssistant.putS3ObjectTagging(redactionRequest.S3Key, awsConfiguration, "LifeSpan", vendorLifespanTagValue));
                        Promise.all(promises).then((data) => {
                            state._responseObject = {
                                httpStatus: 200,
                                responseBody: "Redaction Success",
                                "content-type": "application/json",
                                "isBase64Encoded": true
                            };
                            resolve(state);
                        }).catch(() => reject(state));
                    }
    
                    
                }
                else{
                    awsAssistant.deleteObjectFromS3(redactionRequest.S3Key, redactionRequest.VersionID, awsConfiguration)
                    .then(() => {
                        state._responseObject = {
                            httpStatus: 200,
                            responseBody: "Redaction Success",
                            "content-type": "application/json",
                            "isBase64Encoded": true
                        };
                        resolve(state);
                    }).catch(() => reject(state));
                }         
            }
            else{
                reject(state);
            }
        }
        catch(er){
            state._responseObject = {
                httpStatus: 500
            };
            reject(er);
        }
        
    });
};

async function GetResponseFromS3(s3key, awsConfiguration) {
    var S3result = await awsAssistant.getFileFromS3(s3key, awsConfiguration);
    return S3result;
}




var cryptoHash = require('crypto');

exports.buildMockKey = (request) =>{
    var mockKey = request.Employer.Title;

    if (request.Employer.EmployerName != null)
        mockKey = mockKey + request.Employer.EmployerName;

    if (request.Location.State != null)
        mockKey = mockKey + request.Location.State;

    var hashValue = cryptoHash.createHash('sha512').update(mockKey).digest("hex");

    return hashValue;
}

exports.isMockRequst= (request) => {
    var isMock = false;


    if (request.Employer.Title.toLowerCase().startsWith("zz"))
        isMock = true;

    if ((request.Location)
         && request.Location.State != null
            && request.Location.State.toLowerCase().startsWith("z"))
        isMock = true;

    return isMock;

}


var serviceModels = require("../models/serviceModels.js");
var jsonConverter = require("../Assistants/jsonConverterAssistant.js");


var responseObject = serviceModels.responseObject;
var canonicalResponse = serviceModels.canonicalResponse;

exports.buildResponseData = buildResponseData;
function buildResponseData (state) {

    var errMSG;
    responseObject.httpStatus = 200;
    responseObject.isBase64Encoded = true;

    if (state._requestHeaders["accept"].includes('xml')) {
        state.context = state.canonicalServiceResponse;

        var err_JsonConverter = jsonConverter.JsontoXML(state, "IncomeEstimateResponse");
        responseObject["content-type"] = "application/xml";

        if (err_JsonConverter != null) {
            state._responseObject = buildErrorResponse("Error Processing Request TransactionID : " + state._transactionID, "application/xml", 500);
            errMSG = err_JsonConverter;
        }
        else {
            state.rawServiceResponse = state.responseContext;

            state._responseObject = {
                httpStatus: 200,
                responseBody: Buffer.from(state.rawServiceResponse).toString('base64'),
                "content-type": "application/xml",
                "isBase64Encoded": true
            };
        }
    }
    else {
        state.rawServiceResponse = JSON.stringify(state.context);

        state._responseObject = {
            httpStatus: 200,
            responseBody: Buffer.from(state.rawServiceResponse).toString('base64'),
            "content-type": "application/json",
            "isBase64Encoded": true
        };
    }

    return errMSG;

}

exports.buildResponse = function (message, contenttype, statusCode) {

    responseObject = {
        httpStatus: statusCode,
        responseBody: Buffer.from(message).toString('base64'),
        "content-type": contenttype,
        "isBase64Encoded": true
    };

    return responseObject;

}

exports.buildErrorResponse = buildErrorResponse;
function buildErrorResponse(message, headers, statusCode) {

    responseObject = {
        errorMessage: {
            httpStatus: statusCode,
            error: message
        },
        isBase64Encoded: false
    };

    if (headers.accept && headers.accept.includes('xml'))
        responseObject["content-type"] = "application/xml";
    else
        responseObject["content-type"] = "application/json";

    return responseObject;

}

exports.BuildGenericTitleResponse = function BuildGenericTitleResponse(state) {
    var startTime = new Date();

    var errMSG;
    state._tag = "responseBuilderUseCase";
    state._traceLog._className = "index.js";
    state._traceLog._function = "BuildGenericTitleResponse";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    canonicalResponse.Result.MatchingJobs = [];

    try {
        var genericTitles = state.context;
        canonicalResponse.TransactionID = state._transactionID;
        canonicalResponse.RequestorID = state.canonicalServiceRequest != null ? state.canonicalServiceRequest.RequestorID : state._requestorID;



        canonicalResponse.Status.StatusCode = "JobFoundOnGenericList";
        canonicalResponse.Status.StatusDescription = "The job title provided is on the FAMS list of too general job titles and results in a collection of diverse jobs from which an accurate compensation analysis cannot be performed.";


        if (genericTitles != null) {
            if (typeof (genericTitles) == "string")
                canonicalResponse.Result.MatchingJobs.push(genericTitles);
            else
                canonicalResponse.Result.MatchingJobs = genericTitles;
        }

        state.canonicalServiceResponse = canonicalResponse;

        state.context = state.canonicalServiceResponse;
        state.rawServiceResponse = state.canonicalServiceResponse;

        return errMSG;

    }
    catch (err) {
        state._traceLog._type = "Error";
        state._traceLog._msg = err.message;
        errMSG = err.message;
    }

    var endTime = new Date();
    state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();

    state.canonicalServiceResponse = canonicalResponse;

    return errMSG;
}

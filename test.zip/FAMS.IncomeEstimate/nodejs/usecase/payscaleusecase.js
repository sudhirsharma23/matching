var request = require('request');
var serviceModels = require("../models/serviceModels.js");
//var configurationModel = require("../models/configurationModels.js");
var logger = require("../Assistants/logAssistant.js");
var jsonConverter = require("../Assistants/jsonConverterAssistant.js");
var awsAssistant = require("../Assistants/awsAssistant.js");
var mockUseCase = require("../usecase/mockusecase.js");
var responseBuilderUseCase = require("../usecase/responseBuilderUseCase.js");
const vendorStatusLookup = require("../Artifacts/Lookups/VendorStatusMap.json");

var responseObject = serviceModels.responseObject;
var canonicalResponse = serviceModels.canonicalResponse;

exports.CallPayScaleWeb = (state) => {
    var functionStartTime = new Date();
    state._traceLog._ts = new Date();

    state._tag = "Call PayScaleWeb";

    state._traceLog._className = "payscaleusecase.js";
    state._traceLog._function = "CallPayScaleWeb";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    state.context = state.canonicalServiceRequest;

    return new Promise(function (resolve, reject) {

        if (state["generticTitleStatus"].isGenericTitle) {
            state._traceLog.enabled = false;
            resolve(state);
            return;
        }

        if (state["cache_MockStatus"].isCached
            || state["cache_MockStatus"].isMock) {
            state._traceLog.enabled = false;
            resolve(state);
            return;
        }     

        //Build Payscale Request
        state._dataSource = "Vendor";
        var buildRequestMSG = BuildPayScaleSoapRequest(state);
        logger.logHelper(state);

        if (buildRequestMSG) {
            var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            state._traceLog._msg = buildRequestMSG;
            reject(state);
        }

        //verify is Test
        if (state.isTest == true)
            state.vnd_Details.isTest = true;

        var options = {
            url: state.vnd_Details.url,
            method: 'POST',
            timeout: state.vnd_Details.timeoutMS,
            body: state.vendorRequest,
            headers: {
                'Content-Type': 'text/xml'
            }
        };

        var startTime = new Date();
        let callback = (error, response, body) => {
            var endTime = new Date();
            state._traceLog._ts = new Date();
            state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();
            state._traceLog._tags.push("index.exports.CallPayScaleWeb execution time.");

            state["vendorElaspedMS"] = state._traceLog._elapsedms;
            state["vendorHttpStatusCode"] = response.statusCode;

            if (!error && response.statusCode == 200) {
                logger.logHelper(state);
                state.context = body;
                state.rawVendorResponse = body;

                var processresponse = processResponse(state);

                state._traceLog._ts = functionStartTime;
                if (processresponse != null) {
                    state._traceLog._msg = processresponse;
                    reject(state);
                }
                else
                    resolve(state);
            }
            else {
                state._traceLog._ts = functionStartTime;
                state._traceLog._type = "Error";
                state._traceLog._msg = "Error Invoking Payscale. HttpStatusCode: " + response.statusCode + " HttpStatusMessage:" + response.statusMessage;
                var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
                logger.logHelper(state);
                state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
                reject(state);
            }
        };

        request(options, callback);
    });
}

exports.CallPayScaleCache = (state) => {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push("Invoke Payscale cache");
    state._traceLog._className = "payscaleusecase.js";
    state._traceLog._function = "exports.CallPayScaleCache";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    var startTime = new Date();

    return new Promise(function (resolve, reject) {

        if (state["generticTitleStatus"].isGenericTitle) {
            state._traceLog.enabled = false;
            resolve(state);
            return;
        }

        if (!state["cache_MockStatus"].isCached) {
            state._traceLog.enabled = false;
            resolve(state);
            return;
        }       

        var s3FileKey = state["cache_MockStatus"].s3ResponseKey;

        state._dataSource = "Cache";
        var s3GetPromise = awsAssistant.getFileFromS3(s3FileKey, state["awsConfiguration"]);
        s3GetPromise.then(function (S3result) {
            var endTime = new Date();
            state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();

            state["vendorElaspedMS"] = state._traceLog._elapsedms;
            state["vendorHttpStatusCode"] = 200;

            state.context = S3result.Body.toString();
            state.rawVendorResponse = S3result.Body.toString();
            var processresponse = processResponse(state);

            if (processresponse != null) {
                state._traceLog._msg = processresponse;
                reject(state);
            }
            else
                resolve(state);

        }, function (err) {
            var message = "Order not found, TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 404);
            reject(state);
        });
    });
}

exports.CallPayScaleMock = (state) => {
    state._traceLog._ts = new Date();
    var startTime = new Date();

    state._traceLog._tags = [];
    state._traceLog._tags.push("Invoke Payscale Mock");
    state._traceLog._className = "payscaleuseacse.js";
    state._traceLog._function = "xports.CallPayScaleMock";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    return new Promise(function (resolve, reject) {

        if (state["generticTitleStatus"].isGenericTitle) {
            state._traceLog.enabled = false;
            resolve(state);
            return;
        }

        if (!state["cache_MockStatus"].isMock) {
            state._traceLog.enabled = false;
            resolve(state);
            return;
        }      

        state._dataSource = "Mock";
        var mockKey = mockUseCase.buildMockKey(state.canonicalServiceRequest);
        var s3FileKey = `${state["awsConfiguration"].mockResponseFolder}/${state.api_version}/${mockKey}`;

        var s3GetPromise = awsAssistant.getFileFromS3(s3FileKey, state["awsConfiguration"]);
        s3GetPromise.then(function (S3result) {
            var endTime = new Date();
            state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();

            state["vendorElaspedMS"] = state._traceLog._elapsedms;
            state["vendorHttpStatusCode"] = 200;

            state.context = S3result.Body.toString();
            state.rawVendorResponse = S3result.Body.toString();
            var processresponse = processResponse(state);

            if (processresponse != null) {
                state._traceLog._msg = processresponse;
                reject(state);
            }
            else
                resolve(state);

        }, function (err) {
            var message = "Order not found, TransactionID: " + state._transactionID;
            state._traceLog._error = {
                stack: err.stack,
                msg: err.message
            };
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 404);
            reject(state);

        });
    });
}


function BuildPayScaleSoapRequest(state) {
    var errMSG;
    var SOAP_Envelope;
    var startTime = new Date();

    state._tag = "BuildPayScaleSoapRequest"

    state._traceLog._className = "index.js";
    state._traceLog._function = "BuildPayScaleSoapRequest";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog._tags.push("index.BuildPayScaleSoapRequest execution time.");

    try {
        SOAP_Envelope =
            "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns=\"WS-SatoriSoftware-US-ZIP\">" +
            "<soap:Body>" +
            "<EvaluatePay xmlns=\"http://services.payscale.com/compensationSearch/060930\"> " +
            "<request> " +
            "<Credentials>" +
            "<UserName>" + state.vnd_Details.username + "</UserName>" +
            "<Password>" + state.vnd_Details.password + "</Password>" +
            "</Credentials>" +
            "<IsTest>" + state.vnd_Details.isTest + "</IsTest> " +
            "<Profile>" +
            "<Job>" +
            "<Title>" + encodeHTML(parseField(state.context, "Employer.Title")) + "</Title> " +
            createNonEmptyNode(state.context, "Employer.YearsOnJob", "YearsOnJob") +
            createNonEmptyNode(state.context, "Employer.YearsExperience", "YearsExperience") +
            "</Job>" +
            "<Location>" +
            "<Country>" + parseField(state.context, "Location.Country") + "</Country>" +
            "<State>" + parseField(state.context, "Location.State") + "</State>" +
            "<City>" + parseField(state.context, "Location.City") + "</City>" +
            "</Location>" +
            "<Personal>" + setDateofBirth(state.context, "Individual.DateOfBirth") + "</Personal>" +
            "<Employer>" +
            "<Name>" + encodeHTML(parseField(state.context, "Employer.Name")) + "</Name>" +
            createNonEmptyNode(state.context, "Employer.YearsOnJob", "YearsWithEmployer") +
            "<EmployerType>" + parseField(state.context, "Employer.EmployerType") + "</EmployerType>" +
            "</Employer>" +
            "<Income>" +
            setBaseIncome(state.context, "Income.BaseAnnualIncome") +
            createNonEmptyNode(state.context, "Income.Overtime", "Overtime") +
            createNonEmptyNode(state.context, "Income.Bonus", "Bonus") +
            createNonEmptyNode(state.context, "Income.Commissions", "Commissions") +
            "</Income>" +
            "</Profile>" +
            "<ExactMatch>" + false + "</ExactMatch>" +
            "<TargetOverstatedCompScore>500</TargetOverstatedCompScore>" +
            "</request>" +
            "</EvaluatePay>" +
            "</soap:Body>" +
            "</soap:Envelope>";

        state.vendorRequest = SOAP_Envelope;

        var endTime = new Date();
        state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();
    }
    catch (err) {
        state._traceLog._type = "Error";
        state._traceLog._msg = err.message;
        errMSG = err.message;
    }

    return errMSG;
}

function encodeHTML(htmlString) {

    var returnData = htmlString.replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');

    return returnData;


};
function setDateofBirth(obj, key) {
    var dob = parseField(obj, key);
    if (dob == '')
        return ''
    else {
        var xmlDOB = new Date(dob);
        return "<DateOfBirth>" + xmlDOB.toISOString() + "</DateOfBirth>";
    }
}

function setBaseIncome(obj, key) {
    let baseAnnualIncome = parseField(obj, key);

    if (baseAnnualIncome) {
        let baseIncome = baseAnnualIncome / 12;
        return "<Base>" + baseIncome + "</Base>";
    }
    else {
        return '';
    }
}

function createNonEmptyNode(obj, key, elementName) {

    var elementValue = parseField(obj, key);
    if (elementValue == '')
        return ''
    else {
        return "<" + elementName + ">" + elementValue + "</" + elementName + ">";
    }
}

function parseField(obj, key) {
    return key.split(".")
        .reduce(function (parent, field) {
            var value = (typeof parent === "undefined" || parent === null) ? '' : parent[field];

            if (typeof value === "undefined" || value === null)
                return '';
            else
                return value;
        }, obj);
}

function processResponse(state) {
    var message;

    //Convert to Canonical JsonResponse    
    state.context = state.rawVendorResponse;
    var jsonConverterMSG = jsonConverter.XMLtoJson(state);


    if (jsonConverterMSG != null) {
        message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
        state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
        return jsonConverterMSG;
    }

    //Map Payscale Json response to canonical response
    state.vendorResponse = state.context = state.responseContext;
    var cannoncialResponeMapper = MapPayScaleResponseToCanonical(state);


    if (cannoncialResponeMapper != null) {
        var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
        state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
        return cannoncialResponeMapper;
    }
}

function MapPayScaleResponseToCanonical(state) {
    var startTime = new Date();

    var errMSG;
    state._tag = "Call PayScaleWeb";
    state._traceLog._className = "index.js";
    state._traceLog._function = "MapPayScaleResponseToCanonical";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    canonicalResponse.Result.MatchingJobs = [];

    try {
        var serviceResponse = state.context['soap:Envelope']['soap:Body']['EvaluatePayResponse'];
        canonicalResponse.TransactionID = state._transactionID;
        canonicalResponse.RequestorID = state.canonicalServiceRequest != null ? state.canonicalServiceRequest.RequestorID : state._requestorID;

        if (serviceResponse.EvaluatePayResult.Error != undefined)
        {
           var vendorStatusMap =  vendorStatusLookup["PayScale"][serviceResponse.EvaluatePayResult.Error.toLowerCase()];

           if (vendorStatusMap == undefined)
           {
            canonicalResponse.Status.StatusCode = "Error";
            canonicalResponse.Status.StatusDescription = serviceResponse.EvaluatePayResult.Error;
            
           }
           else if (serviceResponse.EvaluatePayResult.Error.toLowerCase() == "none")
           {
                canonicalResponse.Status.StatusCode = "Ok";
                canonicalResponse.Status.StatusDescription = "Success";
                
            }
            else
            {
                canonicalResponse.Status.StatusCode = serviceResponse.EvaluatePayResult.Error;
                canonicalResponse.Status.StatusDescription = vendorStatusMap.StatusDescription;
            }

            if (vendorStatusMap != undefined && vendorStatusMap.IsBillable == 1)
                state._orderStatus = "OK";
            
            else
                state._orderStatus = "Error";
            
        }
       
       

        if (serviceResponse.EvaluatePayResult.MatchingJobs != null) {
            if (typeof (serviceResponse.EvaluatePayResult.MatchingJobs) == "string")
                canonicalResponse.Result.MatchingJobs.push(serviceResponse.EvaluatePayResult.MatchingJobs);
            else
                canonicalResponse.Result.MatchingJobs = serviceResponse.EvaluatePayResult.MatchingJobs;
        }

        if (serviceResponse.EvaluatePayResult.OverstatedCompScore != null)
            canonicalResponse.Result.OverstatedCompScore = serviceResponse.EvaluatePayResult.OverstatedCompScore;

        if (serviceResponse.EvaluatePayResult.TargetCompensation != null)
            canonicalResponse.Result.TargetCompensation = serviceResponse.EvaluatePayResult.TargetCompensation;

        if (serviceResponse.EvaluatePayResult.Percentile25 != null)
            canonicalResponse.Result.Percentile25 = serviceResponse.EvaluatePayResult.Percentile25;

        if (serviceResponse.EvaluatePayResult.Median != null)
            canonicalResponse.Result.Median = serviceResponse.EvaluatePayResult.Median;

        if (serviceResponse.EvaluatePayResult.Percentile75 != null)
            canonicalResponse.Result.Percentile75 = serviceResponse.EvaluatePayResult.Percentile75;

    }
    catch (err) {
        state._traceLog._type = "Error";
        state._traceLog._msg = err.message;
        errMSG = err.message;
    }

    var endTime = new Date();
    state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();

    state.canonicalServiceResponse = canonicalResponse;

    return errMSG;
}


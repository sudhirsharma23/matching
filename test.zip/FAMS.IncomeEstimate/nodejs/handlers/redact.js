var responseBuilderUseCase = require("../usecase/responseBuilderUseCase.js");
var redactUseCase = require("../usecase/redactUseCase.js");
var logger = require("../Assistants/logAssistant.js");

exports.ProcessRedactRequest = (state) => {
    state._traceLog._tags = [];
    state._traceLog._ts = new Date();
    state._traceLog._tags.push("ProcessRedactRequest");
    state._traceLog._className = "redact.js";
    state._traceLog._function = "ProcessRedactRequest";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    return new Promise((resolve, reject) => {

        try {
            decodeRequestBody(state)
                .then(logger.logSteps.bind(redactUseCase.legacyRedact))
                .then(function () {
                    state._traceLog._tags = [];
                    state._traceLog._ts = state._startTime;
                    state._traceLog._tags.push("IncomeEstimateService Redact Handler");
                    state._traceLog._className = "redact.js";
                    state._traceLog._function = "sucessExcecution";
                    state._traceLog._type = "Information";
                    state._traceLog.transactionid = state._transactionID;
                    state._traceLog._msg = "IncomeEstimateService RedactHandlerExecution Time. ";
                    state._traceLog.enabled = true;

                    logger.logHelper(state);
                    resolve(state._responseObject);
                }.bind(sucessfulExcecution))
                .catch(ex => {
                    
                    if (state._responseObject.httpStatus != 200)
                    {
                        var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
                        if (ex) {
                            state._traceLog._error = ex.message + ". " + ex.stack;
                            }   

                        if (!state._responseObject || !state._responseObject.errorMessage || !state._responseObject.errorMessage.error) {
                        state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
                        }

                        state._traceLog._msg = "Failed to Process Request Message. " + state._traceLog._msg;
                        logger.logHelper(state);
                    }   


                    reject(state._responseObject);
                });
        }
        catch (err) {
            var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            state._traceLog._msg = "Failed to Process Request Message: " + state._traceLog._msg + "Error: " + err.message;
            logger.logHelper(state);
            reject(state._responseObject);
        }
    });
}

function decodeRequestBody(state) {
    return new Promise((resolve, reject) => {
        state._traceLog._tags = [];
        state._traceLog._ts = new Date();
        state._traceLog._tags.push("Request Decode");
        state._traceLog._className = "postRequest.js";
        state._traceLog._function = "decodeRequestBody";
        state._traceLog._type = "Information";
        state._traceLog.transactionid = state._transactionID;
        state._traceLog.enabled = true;

        try {
            if (state.context.body) {
                state.responseContext = state.rawServiceRequest = new Buffer(state.context.body, 'base64').toString();
                state._traceLog._tags.push("postRequest.decodeRequestBody execution time.");
                resolve(state);
                return;
            }
            else {
                state._traceLog._type = "Error";
                state._traceLog._msg = "Invalid Request Type, TransactionID=" + state._transactionID;
                state._responseObject = responseBuilderUseCase.buildErrorResponse("Invalid Request Type", state._requestHeaders, 415);
                reject(state);
            }
        }
        catch (err) {
            state._traceLog._type = "Error";
            state._traceLog._msg = err.message + " TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse("Invalid Request Type", state._requestHeaders, 415);
            reject(state);
        }
    });
};

function sucessfulExcecution(state) {

    state._traceLog._ts = state._startTime;
    state._traceLog._tags = "IncomeEstimateService Completion";
    state._traceLog._className = "redact.js";
    state._traceLog._function = "sucess";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog._msg = "Sucesfully executed IncomeEstimateService Call";
    state._traceLog.enabled = true;

    logger.logSteps(state);
}
var mockUseCase = require("../usecase/mockusecase.js");
var responseBuilderUseCase = require("../usecase/responseBuilderUseCase.js");
var serviceModels = require("../models/serviceModels.js");
var awsAssistant = require("../Assistants/awsAssistant.js");
var configurationModel = require("../models/configurationModels.js");
var logger = require("../Assistants/logAssistant.js");
const uuidv4 = require('uuid/v4');

var responseObject = serviceModels.responseObject;
exports.ProcessPostMock = (state) => {

    if (!state.context["params"]["header"]["fams-id"])
        state._transactionID = uuidv4();
    else
        state._transactionID = state.context["params"]["header"]["fams-id"];

    state._traceLog._ts = state._startTime;
    state._traceLog._tags = "Post Mock ";
    state._traceLog._className = "postMockRequest.js";
    state._traceLog._function = "ProcessPostMock";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;

    return new Promise((resolve, reject) => {

        decodeRequest(state)
            .then(verifyMock(state))
            .then(buildMockKey(state))
            .then(persistS3Data(state))
            .then(function (state) {
                var message = {
                    "Message": "Successfully Persisted Mock Data.",
                    "serviceRequest": state["ServiceRequest"]["MockServiceRequest"]
                };
                responseObject = responseBuilderUseCase.buildResponse(JSON.stringify(message), "application/json", 200);
                resolve(responseObject);
            })
            .catch(rejection => {
                state._tracelog._msg = "Error Building Mockey. Message: " + rejection.message;
                state._traceLog._type = "Error";
                state._traceLog._function = "ProcessPostMock";
                logger.logHelper(state);
                reject(rejection._responseObject)
            })

    }, function (err) {

        var message = "Failed to Perist Mock Data.";
        state._responseObject = responseBuilderUseCase.buildErrorResponse(message, "application/json", 500);

        state._tracelog._msg = message + " Message: " + err.message;
        state._traceLog._type = "Error";
        state._traceLog._function = "ProcessPostMock";
        logger.logHelper(state);

        reject(state._responseObject);
    });
}

function decodeRequest(state) {
    return new Promise((resolve, reject) => {
        try {
            state["ServiceRequest"] = JSON.parse(new Buffer(state.context.body, 'base64').toString());
            resolve(state);
        }
        catch (err) {
            var message = "Failed to decode Request";
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, "application/json", 500);

            state._tracelog._msg = message + " Message: " + err.message;
            state._traceLog._type = "Error";
            state._traceLog._function = "decodeRequest";
            logger.logHelper(state);

            reject(state);
        }

    });

}
function verifyMock(state) {
    return new Promise((resolve, reject) => {
        try {
            var isMock = mockUseCase.isMockRequst(state["ServiceRequest"]["MockServiceRequest"]);

            if (!isMock) {
                var message = "Invalid Mock Request Request Title should start by zz.";
                state._responseObject = responseBuilderUseCase.buildErrorResponse(message, "application/json", 404);
                reject(state);
            }
            else
                resolve(state);
        }
        catch (err) {
            var message = "Failed to decode Request";
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, "application/json", 500);

            state._tracelog._msg = message + " Message: " + err.message;
            state._traceLog._type = "Error";
            state._traceLog._function = "verifyMock";
            logger.logHelper(state);
            reject(state);
        }

    });



}

function buildMockKey(state) {

    return new Promise((resolve, reject) => {
        try {

            state["mockKey"] = mockUseCase.buildMockKey(state["ServiceRequest"]["MockServiceRequest"]);
            resolve(state);
        }
        catch (err) {
            state._tracelog._msg = "Error Building Mockey. Message: " + err.message;
            state._traceLog._type = "Error";
            state._traceLog._function = " buildMockKey";
            logger.logHelper(state);
            reject(state);
        }
    });

}
function persistS3Data(state) {
    return new Promise((resolve, reject) => {

        if (state["ServiceRequest"]["MockVendorResponse"] == null) {
            var message = "Empty Mock Response .";
            state._responseObject = buildErrorResponse(message, "application/json", 404);
            reject(state);
            return;
        }

        s3URL_mockResponse = `${state["awsConfiguration"].mockResponseFolder}/${state.api_version}/${state["mockKey"]}`;
        state["s3MockURL"] = s3URL_mockResponse;

        var promiseServiceRequest = awsAssistant.uploadFiletoS3(
            state["ServiceRequest"]["MockVendorResponse"],
            s3URL_mockResponse,
            "application/xml",
            state["awsConfiguration"]);

        promiseServiceRequest.then(function (s3Data) {
            resolve(state);

        }, function (err) {
            var message = "Failed to save Mock data.";
            responseObject = responseBuilderUseCase.buildErrorResponse(JSON.stringify(message), "application/json", 500);

            state._tracelog._msg = message + " Message: " + err.message;
            state._traceLog._type = "Error";
            state._traceLog._function = "persistS3Data";
            logger.logHelper(state);

            reject(responseObject);
        });



    });
}



const uuidv4 = require('uuid/v4');

var awsAssistant = require("../Assistants/awsAssistant.js");
var payscaleUseCase = require("../usecase/payscaleusecase.js");
var serviceModels = require("../models/serviceModels.js");
var configurationModel = require("../models/configurationModels.js");
var configAssistant = require("../Assistants/configurationAssistant.js");
var responseBuilderUseCase = require("../usecase/responseBuilderUseCase.js");
var logger = require("../Assistants/logAssistant.js");


var awsConfiguration = configurationModel.awsConfiguration;
var responseObject = serviceModels.responseObject;
const documentTypes = configurationModel.documentTypes;


var cache_MockStatus =
    {
        isCached: false,
        cacheKey: '',
        isMock: false,
        s3ResponseKey: ''
    };

var canonicalRequest =
    {
        "RequestorID": uuidv4(),
        "Individual": {
            "DateOfBirth": "01/08/1976"
        },
        "Employer": {
            "EmployerName": "Hello World",
            "Title": "Nurse",
            "YearsOnJob": 3.14,
            "YearsExperience": 3.14
        },
        "Location": {
            "State": "CA"
        },
        "Income": {
            "BaseAnnualIncome": 30000,
            "Overtime": 30,
            "Bonus": 200,
            "Commissions": 20
        }
    }
    


exports.processHealthCheck = (state) => {
    var promises = [];
    state._traceLog._ts = state._startTime;
    state._traceLog._tags = [];
    state._traceLog._className = "healthCheck.js";
    state._traceLog._function = "ProcessHealthCheck";
    state._traceLog._type = "Information";
    state._traceLog._msg = "Sucesfully executed HealthCheck Call";
    state._traceLog.enabled = false;
    state["cache_MockStatus"] = cache_MockStatus;
    state["persona"] = state.context["params"]["persona"];

    state._responseObject = {
        ServiceName: 'incomeestimate',
        ServiceStatus: 'Green',
        Components: []
    };



    return new Promise((resolve, reject) => {

        state._transactionID = uuidv4();
        state._requestorID = canonicalRequest.RequestorID;

        configAssistant.getVendorConfigurations(state)
        .then(logger.logSteps.bind(verifyDynamoDB))
        .then(logger.logSteps.bind(verifyS3))
        .then(logger.logSteps.bind(verifyVendor))
        .then(logger.logSteps.bind(buildResponseData))
        .then(function () {
                resolve(state._responseObject);
            }
            )
            .catch(rejection => {
                reject(rejection._responseObject)
            })
        }
    )
    
               

}

function verifyDynamoDB(state) {
    state._traceLog._ts = state._startTime;
    state._traceLog._function = "verifyDynamoDB";
    state._traceLog.enabled = false;

    return new Promise((resolve, reject) => {

        var dynamoPromise = awsAssistant.checkAsyncDynamoDBTableExist(state["awsConfiguration"].dynamoTransactionTableName, state["awsConfiguration"]);
        dynamoPromise.then(function (result) {

            state._responseObject.Components.push(
                {
                    "DynamoDB": {
                        Name: state["awsConfiguration"].dynamoTransactionTableName,
                        Type: 'Infrastructure',
                        Status: result.Table.TableName === state["awsConfiguration"].dynamoTransactionTableName ? 'Green': 'Red'
                    }
                }
            );

            resolve(state);

        }, function (err) {
            var message = "Unhandled exception connecting to DynamoDB Table : " + state["awsConfiguration"].dynamoTransactionTableName;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            state._traceLog._msg = "Failed to Process the Request Message: " + err.message;
            logger.logHelper(state);
            reject(state);
        }
        );
    }
    );
}

function verifyS3(state){
    state._traceLog._ts = state._startTime;
    state._traceLog._function = "verifyS3";
    state._traceLog.enabled = false;

    return new Promise((resolve, reject) => {

        var s3Promise = awsAssistant.checkS3BucketExists(state["awsConfiguration"]);
        s3Promise.then(function (result) {

            state._responseObject.Components.push(
                {
                    "S3": {
                        Name: state["awsConfiguration"].bucketName,
                        Type: 'Infrastructure',
                        Status: 'Green'
                    }
                }
            );

            resolve(state);

        }, function (err) {

            if(err.statusCode === 404){
                state._responseObject.Components.push(
                    {
                        "S3": {
                            Name: state["awsConfiguration"].bucketName,
                            Type: 'Infrastructure',
                            Status: 'Red',
                            Information: {
                                "Error": "Bucket not found"
                            }
                        }
                    }
                );
    
                resolve(state);
            }
            else {
                var message = "Unhandled exception checking S3 Bucket : " + state["awsConfiguration"].bucketName;
                state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
                state._traceLog._msg = "Failed to Process the Request Message: " + err.message;
                logger.logHelper(state);
                reject(state);
            }

        }
        );
    }
    );
}

function verifyVendor(state) {
    state._traceLog._ts = state._startTime;
    state._traceLog._function = "verifyVendor";
    state._traceLog.enabled = false;
    return new Promise((resolve, reject) => {

        state[documentTypes.canonicalRequest] = canonicalRequest;
        //set is Test to True
        state["vnd_Details"].isTest = true;
        var promise_payscaleCall = payscaleUseCase.CallPayScaleWeb(state);

        promise_payscaleCall.then(function (state) {

            state._responseObject.Components.push(
                {
                    "Payscale": {
                        Name: 'Payscale Income Estimate',
                        Type: 'Vendor',
                        Status: 'Green',
                        Information: {
                            "URL": state.vnd_Details.url,
                            "ResponseTimeMS": state["vendorElaspedMS"],
                            "ResponseStatus": state["vendorHttpStatusCode"]
                        }
                    }
                }
            );

            resolve(state);

        }, function (err) {
            
            state._responseObject.Components.push(
                {
                    "VendorCall-Payscale": {
                        Name: 'Payscale',
                        Type: 'Vendor',
                        Status: 'Red',
                        Information: {
                            "URL": state.vnd_Details.url,
                            "ResponseTimeMS": state["vendorElaspedMS"],
                            "ResponseStatus": state["vendorHttpStatusCode"]
                        }
                    }
                }
            );

            resolve(state);

        }
        );
        });
}

function buildResponseData(state) {
    responseObject.httpStatus = 200;
    responseObject.isBase64Encoded = true;
    
    state._traceLog._tags = [];
    state._traceLog._ts = new Date();
    state._traceLog._tags.push( "Build Service Response");
    state._traceLog._className = "HealthCheck.js";
    state._traceLog._function = "buildResponseData";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;


    return new Promise((resolve, reject) => {

        state.context = state._responseObject;
        var responseMSG = responseBuilderUseCase.buildResponseData((state));

        if (responseMSG != null)
            reject(state);

        else
            resolve(state);
    }

    );

}


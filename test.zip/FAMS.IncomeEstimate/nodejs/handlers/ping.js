exports.processPing = (state) => {
    var promises = [];
    state._traceLog._ts = state._startTime;
    state._traceLog._tags = [];
    state._traceLog._className = "ping.js";
    state._traceLog._function = "ProcessPing";
    state._traceLog._type = "Information";
    state._traceLog._msg = "Sucesfully executed Ping Call";
    state._traceLog.enabled = false;
    return new Promise((resolve, reject) => {

        resolve({})
        
    })          
}
const awsAssistant = require("../Assistants/awsAssistant.js");
const jsonConverter = require("../Assistants/jsonConverterAssistant.js");
const logger = require("../Assistants/logAssistant.js");
const responseBuilderUseCase = require("../usecase/responseBuilderUseCase.js");

exports.ProcessGetRequest = (state) => {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._className = "getRequest.js";
    state._traceLog._function = "processGetRequest";
    state._traceLog._type = "Information";
    state._traceLog._msg = "Sucesfully executed IncomeEstimateService Call";
    state._traceLog.enabled = true;
    state.persona = state.context["params"]["persona"];

    return new Promise((resolve, reject) => {
        if (!state.context["params"]["queryString"]["transactionID"]) {
            let message = "Bad Request, Invalid transactionID";
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 400);
            reject(state._responseObject);
        }
        else if (!state.persona || !state.persona.globalID) {
            const message = `Internal Server Error, Cannot process your request. TransactionID: ${state.context.params.queryString.transactionID}`;
            state._traceLog._error = message;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            logger.logHelper(state);
            reject(state._responseObject);
        }
        else
            state._transactionID = state.context["params"]["queryString"]["transactionID"];

        try {
            GetResponseFromS3(state)
                .then(logger.logSteps.bind(BuildResponseData))
                .then(function () {
                    state._traceLog._ts = new Date();
                    state._traceLog._tags = [];
                    state._traceLog._tags.push["IncomeEstimateService GetHandler"];
                    state._traceLog._className = "getRequest.js";
                    state._traceLog._function = "processGetRequest";
                    state._traceLog._type = "Information";
                    state._traceLog.transactionid = state._transactionID;
                    state._traceLog._msg = "IncomeEstimateService GetHandler Execution Time";
                    state._traceLog.enabled = true;

                    logger.logHelper(state);
                    resolve(state._responseObject);
                }.bind(step_sucess))
                .catch(rejection => {
                    var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
                    state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
                    state._traceLog._msg = "Failed to Process Request Message: " + state._traceLog._msg;
                    logger.logHelper(state);
                    reject(state._responseObject);
                });
        }
        catch (err) {
            var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            state._traceLog._msg = "Failed to Process Request Message: " + err.message;
            logger.logHelper(state);
            reject(state._responseObject);
        }
    });
}

async function GetResponseFromS3(state) {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];

    state._tag = "Get S3 Data";

    state._traceLog._className = "getRequest.js";
    state._traceLog._function = "GetResponseFromS3";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;
    let responseKey = `${state.awsConfiguration.serviceResponseFolder}/${state.api_version}/${state.persona.globalID.toLowerCase()}_${state._transactionID}`;

    try {
        let S3result = await awsAssistant.getFileFromS3(responseKey, state["awsConfiguration"]);
        state.context = S3result.Body.toString();
        state.S3ContentType = S3result.ContentType;
        let responseErrMSG = buildResponse(state);

        if (responseErrMSG) {
            let message = "Failed to retreive Data,  TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 404);
            state._traceLog._msg = "Failed to retrieve Data Message: " + responseErrMSG;
            logger.logHelper(state);
            throw new Error(message);
        }
    }
    catch (err) {
        if (!err.code || err.code.toLowerCase() !== "notfound") {
            let message = "Order not found TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 404);
            state._traceLog._msg = "Failed to Process the Request Message: " + err.message;
            logger.logHelper(state);
            throw err;
        }
    }

    return state;
}

function step_sucess(state) {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push["IncomeEstimateService Completion"];
    state._traceLog._className = "postRequest.js";
    state._traceLog._function = "step12_sucess";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog._msg = "Sucesfully executed IncomeEstimateService Call";
    state._traceLog.enabled = true;

    logger.logSteps(state);
}

function BuildResponseData(state) {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push["Build Service Response"];
    state._traceLog._className = "getRequest.js";
    state._traceLog._function = "BuildResponseData";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    if (!state.context) {
        
        state._responseObject = responseBuilderUseCase.buildErrorResponse("Transaction not found", state._requestHeaders, 404);
    }
    else {
        let responseMSG = responseBuilderUseCase.buildResponseData(state);

        if (responseMSG != null) {
            state._traceLog._msg = responseMSG;
            throw new Error(responseMSG);
        }
    }
    
    return state;
}


function buildResponse(state) {
    if (state["S3ContentType"].includes("xml")) {
        let errMSG = jsonConverter.XMLtoJson(state);
        state.canonicalServiceResponse = state.responseContext.IncomeEstimateResponse;
        return errMSG;
    }
    else {
        state.canonicalServiceResponse = JSON.parse(state.context);
    }
}

const S3Client = require("aws-sdk/clients/s3");
const moment = require("moment");
const cryptoHash = require('crypto');
const uuidv4 = require('uuid/v4');

var payscaleUseCase = require("../usecase/payscaleusecase.js");

var logger = require("../Assistants/logAssistant.js");

var serviceModels = require("../models/serviceModels.js");
var persistenceModels = require("../models/persistenceModels.js");

var mockUseCase = require("../usecase/mockusecase.js");
var responseBuilderUseCase = require("../usecase/responseBuilderUseCase.js");

var configAssistant = require("../Assistants/configurationAssistant.js");
var jsonConverter = require("../Assistants/jsonConverterAssistant.js");
var requestValidator = require("../Assistants/validationAssistant.js");
var awsAssistant = require("../Assistants/awsAssistant.js");
var vendorCredAssistant = require("../Assistants/vendorCredentialAssistant.js");
var redactUseCase = require("../usecase/redactUseCase.js");

var alertUseCase = require("../usecase/alertUseCase.js");

const genericTitlesLookup = require("../Artifacts/Lookups/GenericTitles.json");


var responseObject = serviceModels.responseObject;

exports.ProcessPostRequest = (state) => {
    state._traceLog._tags = [];
    state._traceLog._ts = new Date();
    state._traceLog._tags.push("ProcessPostRequest");
    state._traceLog._className = "postRequest.js";
    state._traceLog._function = "ProcessPostRequest";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;
    //get Jodi Perosna
    state["persona"] = state.context["params"]["persona"];
    return new Promise((resolve, reject) => {

        if (!state.context["params"]["header"]["fams-id"])
            state._transactionID = uuidv4();
        else
            state._transactionID = state.context["params"]["header"]["fams-id"];

        try {
            decodeRequestBody(state)
                .then(logger.logSteps.bind(configAssistant.getVendorConfigurations))
                .then(logger.logSteps.bind(vendorCredAssistant.getVendorCredential))
                .then(logger.logSteps.bind(createCanonicalRequest))
                .then(logger.logSteps.bind(validateRequest))
                .then(logger.logSteps.bind(validateGenericTitle))
                .then(logger.logSteps.bind(verifyCacheOrMock))
                .then(logger.logSteps.bind(payscaleUseCase.CallPayScaleMock))
                .then(logger.logSteps.bind(payscaleUseCase.CallPayScaleCache))
                .then(logger.logSteps.bind(payscaleUseCase.CallPayScaleWeb))              
                .then(logger.logSteps.bind(alertUseCase.buildAlertResponseData))
                .then(logger.logSteps.bind(buildResponseData))
                .then(logger.logSteps.bind(redactUseCase.redact))
                .then(logger.logSteps.bind(persistS3Data))
                .then(logger.logSteps.bind(persistTransactionData))
                .then(function () {
                    state._traceLog._tags = [];
                    state._traceLog._ts = state._startTime;
                    state._traceLog._tags.push("IncomeEstimateService PostHandler");
                    state._traceLog._className = "postRequest.js";
                    state._traceLog._function = "sucessExcecution";
                    state._traceLog._type = "Information";
                    state._traceLog.transactionid = state._transactionID;
                    state._traceLog._msg = "IncomeEstimateService PostHandlerExecution Time. ";
                    state._traceLog.enabled = true;

                    logger.logHelper(state);
                    resolve(state._responseObject);
                }.bind(sucessfulExcecution))
                .catch(ex => {
                    
                    if (state._responseObject.httpStatus != 200)
                    {
                        var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
                        if (ex) {
                            state._traceLog._error = ex.message + ". " + ex.stack;
                            }   

                        if (!state._responseObject || !state._responseObject.errorMessage || !state._responseObject.errorMessage.error) {
                        state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
                        }

                        state._traceLog._msg = "Failed to Process Request Message. " + state._traceLog._msg;
                        logger.logHelper(state);
                    }   


                    reject(state._responseObject);
                });
        }
        catch (err) {
            var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            state._traceLog._msg = "Failed to Process Request Message: " + state._traceLog._msg + "Error: " + err.message;
            logger.logHelper(state);
            reject(state._responseObject);
        }
    });
}


function date_diff_indays(d1, d2) {
    var diff = Date.parse(d2) - Date.parse(d1);
    return Math.floor(diff / 86400000);
}

function buildCacheKey(request, persona) {
    var cacheKey = persona.globalID.toLowerCase();
    cacheKey = cacheKey + request.Employer.Title;

    if (request.Location) {
        if (request.Location.city != null)
            cacheKey = cacheKey + request.Location.city;

        if (request.Location.State != null)
            cacheKey = cacheKey + request.Location.State;
    }

    if (request.Employer.YearsOnJob != null)
        cacheKey = cacheKey + request.Employer.YearsOnJob;

    var hashValue = cryptoHash.createHash('sha512').update(cacheKey).digest("hex");

    return hashValue;
}

function decodeRequestBody(state) {
    return new Promise((resolve, reject) => {
        state._traceLog._tags = [];
        state._traceLog._ts = new Date();
        state._traceLog._tags.push("Request Decode");
        state._traceLog._className = "postRequest.js";
        state._traceLog._function = "decodeRequestBody";
        state._traceLog._type = "Information";
        state._traceLog.transactionid = state._transactionID;
        state._traceLog.enabled = true;

        try {
            if (state.context.body) {
                state.responseContext = state.rawServiceRequest = new Buffer(state.context.body, 'base64').toString();
                state._traceLog._tags.push("postRequest.decodeRequestBody execution time.");
                resolve(state);
                return;
            }
            else {
                state._traceLog._type = "Error";
                state._traceLog._msg = "Invalid Request Type, TransactionID=" + state._transactionID;
                state._responseObject = responseBuilderUseCase.buildErrorResponse("Invalid Request Type", state._requestHeaders, 415);
                reject(state);
            }
        }
        catch (err) {
            state._traceLog._type = "Error";
            state._traceLog._msg = err.message + " TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse("Invalid Request Type", state._requestHeaders, 415);
            reject(state);
        }
    });
};

function createCanonicalRequest(state) {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push("Create CanonicalRequest");
    state._traceLog._function = "createCanonicalRequest";
    state._traceLog.enabled = true;

    return new Promise((resolve, reject) => {
        try {
            if (state._requestHeaders["content-type"].includes('xml')) {
                //Convert XML to Json                
                state.context = state.rawServiceRequest;
                let jsonConverterMSG = jsonConverter.XMLtoJson(state);

                state.canonicalServiceRequest = state.responseContext.IncomeEstimateRequest;

                if (jsonConverterMSG) {
                    var message = "Invalid Request, TransactionID: " + state._transactionID;
                    responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 400);
                    reject(state);
                    return;
                }
            }
            else
                state.canonicalServiceRequest = JSON.parse(state.rawServiceRequest);

            resolve(state);
        }
        catch (err) {
            state._traceLog._type = "Error";
            state._traceLog._msg = err.message + " TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse("Invalid Request Type", state._requestHeaders, 415);
            reject(state);
        }
    });
}

function validateRequest(state) {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push("Validate Request");
    state._traceLog._function = "validateRequest";
    state._traceLog.enabled = true;

    return new Promise((resolve, reject) => {
        state._schemaFile = 'IncomeEstimateServiceRequest';
        state.context = state.canonicalServiceRequest;
        let validatoreMsg = requestValidator.validateJson(state);

        if (validatoreMsg) {
            let message = "Invalid Request, TransactionID: " + state._transactionID + " Error: " + validatoreMsg;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 400);
            reject(state);
        }
        else
            resolve(state);
    });
}

function validateGenericTitle(state) {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push("Validate Generic Title");
    state._traceLog._function = "validateGenericTitle";
    state._traceLog.enabled = true;    
       
    return new Promise((resolve, reject) => {
        
        let generticTitleStatus = {
            isGenericTitle: false
        };
        state.generticTitleStatus = generticTitleStatus;

        state._schemaFile = 'IncomeEstimateServiceRequest';
        var genericTitle = genericTitlesLookup[state.canonicalServiceRequest.Employer.Title.toLowerCase()];

        if (genericTitle != null) {
            state.generticTitleStatus.isGenericTitle = true;
            state.context = genericTitle.SuggestedTitles;
            responseBuilderUseCase.BuildGenericTitleResponse(state);       
        }
       
        resolve(state);
    });
}

async function verifyCacheOrMock(state) {
    state._traceLog._ts = new Date();
    state._traceLog._tags = "verify Cache or Mock";
    state._traceLog._className = "postRequest.js";
    state._traceLog._function = "VerifyCacheOrMock";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    let cache_MockStatus = {
        isCached: false,
        cacheKey:  buildCacheKey(state.canonicalServiceRequest, state.persona),
        isMock: false,
        s3ResponseKey: ''
    };
    
    state.cache_MockStatus = cache_MockStatus;
    const s3Client = new S3Client();

    if (mockUseCase.isMockRequst(state.canonicalServiceRequest)) {
        cache_MockStatus.isMock = true;
        return state;
    }

    let awsConfiguration = state.awsConfiguration;
    try {
        cache_MockStatus.s3ResponseKey = `${awsConfiguration.vendorResponseFolder}/${state.api_version}/${cache_MockStatus.cacheKey}`;

        let resp = await s3Client.headObject({
            Bucket: awsConfiguration.bucketName,
            Key: cache_MockStatus.s3ResponseKey
        }).promise();

        let expirationDate = moment.utc(resp.Expires);
        let today = moment.utc();
        
        if(today.isBefore(expirationDate)){
            cache_MockStatus.isCached = true;
        }
    }
    catch (err) {
        if (err.statusCode !== 404) {
            state._error = {
                msg: `failed to call to check cache`,
                raw: err
            };

            throw new Error(`S3 Head call failed for cache check`);
        }
    }

    return state;    
}

function buildResponseData(state) {
    responseObject.httpStatus = 200;
    responseObject.isBase64Encoded = true;

    state._traceLog._ts = new Date();
    state._traceLog._tags = "Build Service Response";
    state._traceLog._className = "postRequest.js";
    state._traceLog._function = "buildResponseData";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    return new Promise((resolve, reject) => {

        state.context = state.canonicalServiceResponse;
        var responseMSG = responseBuilderUseCase.buildResponseData(state);

        if (responseMSG != null ||
            state.generticTitleStatus.isGenericTitle)
            reject(state);

        else
            resolve(state);
    });
}

function persistS3Data(state) {
    var promises = [];

    //Save ServiceRequest
    var s3URL_serviceRequest = "";
    var s3URL_serviceResponse = "";
    var s3URL_vndPayScaleRequest = "";
    var s3URL_vndPayScaleResponse = "";
    var s3URL_redactedServiceRequest = "";

    state._traceLog._ts = new Date();
    state._traceLog._tags = "Persist S3 Data";
    state._traceLog._className = "postRequest.js";
    state._traceLog._function = "persistS3Data";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    var awsConfiguration = state["awsConfiguration"];

    var serviceLifeSpanTagValue = "180d";
    var serviceNoNPIDataLifespanTagValue = "7y";
    var vendorLifespanTagValue = "90d";
    var serviceDataLifeTags = [{Key:"LifeSpan", Value: serviceLifeSpanTagValue}];
    var redactedServiceDataLifeTags = [{Key:"LifeSpan", Value: serviceNoNPIDataLifespanTagValue}];
    var vendorDataLifeTags = [{Key:"LifeSpan", Value: vendorLifespanTagValue}];

    return new Promise((resolve, reject) => {

        if (state.rawServiceRequest) {
            s3URL_serviceRequest = `${awsConfiguration.serviceRequestFolder}/${state.api_version}/${state._transactionID}`;
            var promiseServiceRequest = awsAssistant.uploadFiletoS3WithTagging(
                state.rawServiceRequest,
                s3URL_serviceRequest,
                state._requestHeaders["content-type"],
                awsConfiguration,
                serviceDataLifeTags);

            promises.push(promiseServiceRequest);
        }

        if(state.redactedRawServiceRequest){
            s3URL_redactedServiceRequest = `${awsConfiguration.redactedServiceRequestFolder}/${state.api_version}/${state._transactionID}`;

            var promiseRedactedServiceRequest = awsAssistant.uploadFiletoS3WithTagging(
                state.redactedRawServiceRequest,
                s3URL_redactedServiceRequest,
                state._requestHeaders["content-type"],
                awsConfiguration,
                redactedServiceDataLifeTags);

            promises.push(promiseRedactedServiceRequest);
        }

        if (state.rawServiceResponse) {
            s3URL_serviceResponse = `${awsConfiguration.serviceResponseFolder}/${state.api_version}/${state.persona.globalID.toLowerCase()}_${state._transactionID}`;

            var promiseServiceResponse = awsAssistant.uploadFiletoS3WithTagging(
                state.rawServiceResponse,
                s3URL_serviceResponse,
                state._requestHeaders["accept"],
                awsConfiguration,
                redactedServiceDataLifeTags);

            promises.push(promiseServiceResponse);
        }

        //Save vendor Request   
        if (state.vendorRequest) {
            s3URL_vndPayScaleRequest = `${awsConfiguration.vendorRequestFolder}/${state.api_version}/${state._transactionID}`;
            var promisePayScaleRequest = awsAssistant.uploadFiletoS3WithTagging(
                state.vendorRequest,
                s3URL_vndPayScaleRequest,
                "application/xml",
                awsConfiguration,
                vendorDataLifeTags);

            promises.push(promisePayScaleRequest);
        }

        //Save vendor Response 
        if (state.rawVendorResponse) {
            s3URL_vndPayScaleResponse = `${awsConfiguration.vendorResponseFolder}/${state.api_version}/${state["cache_MockStatus"].cacheKey}`;
            var promisePayScaleResponse = awsAssistant.uploadFiletoS3WithTagging(
                state.rawVendorResponse,
                s3URL_vndPayScaleResponse,
                "application/xml",
                awsConfiguration,
                vendorDataLifeTags,
                state["vnd_Details"].cachePeriodDays);

            promises.push(promisePayScaleResponse);
        }

        Promise.all(promises).then(function (values) {
            state["s3URL_serviceRequest"] = s3URL_serviceRequest;
            state["s3URL_serviceResponse"] = s3URL_serviceResponse;
            state["s3URL_vndPayScaleRequest"] = s3URL_vndPayScaleRequest;
            state["s3URL_vndPayScaleResponse"] = s3URL_vndPayScaleResponse;
            state["s3URL_redactedServiceRequest"] = s3URL_redactedServiceRequest;

            resolve(state);

        }), function (err) {
            state._traceLog._type = "Error";
            state._traceLog._msg = "Error Persisting Data to S3 Message: " + err.message;
            var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            logger.logHelper(state);

            reject(state);
        }
    });

}

function persistTransactionData(state) {

    state._traceLog._ts = new Date();
    state._traceLog._tags = "Persist TransactionData DynamoDB";
    state._traceLog._className = "postRequest.js";
    state._traceLog._function = "persistTransactionData";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    var transactionDB = persistenceModels.transactionDB;
    var vendorResponse = persistenceModels.vendorResponse;



    transactionDB.VendorCalls = [];
    return new Promise((resolve, reject) => {

        transactionDB.AppPlan = state._requestHeaders["application-plan"];
        transactionDB.CacheKey = state["cache_MockStatus"].cacheKey;
        transactionDB.ClientID = state["persona"]["clientID"];
        transactionDB.CompanyName = state["persona"]["companyName"];
        transactionDB.DataSource = state._dataSource;
        transactionDB.DateTimeUTC = new Date(new Date().toUTCString()).toISOString();
        transactionDB.Elapsedms = state["vendorElaspedMS"];
        transactionDB.GlobalID = state["persona"]["globalID"].toLowerCase();
        transactionDB.HttpStatus = state._responseObject.httpStatus;   //Service Http status returned
        transactionDB.PortalCode = state["persona"].portalCode;
        transactionDB.Product = "EvaluatePay"; //Requested API product
        transactionDB.RequestorID = state._requestorID;
        transactionDB.RequestS3Key = state["s3URL_serviceRequest"]; //Service request S3 Key
        transactionDB.ResponseS3Key = state["s3URL_serviceResponse"]; // Service response S3 key
        transactionDB.RedactedRequestS3Key = state["s3URL_redactedServiceRequest"];
        transactionDB.TransactionID = state._transactionID;

        if ( state._vendorStatus != undefined)
            transactionDB.OrderStatus =  state._orderStatus;
        else
            transactionDB.OrderStatus =  "";

        vendorResponse.DateTimeUTC = new Date().toISOString();
        vendorResponse.Elapsedms = state["vendorElaspedMS"];
        vendorResponse.HttpStatus = state["vendorHttpStatusCode"];
        vendorResponse.Name = "PayScale"; //Vendor name
        vendorResponse.Product = "EvaluatePay";     //Vendor Product
        vendorResponse.Sequence = 1; //Priority order in which vendor was called
        vendorResponse.RequestS3Key = state["s3URL_vndPayScaleRequest"];
        vendorResponse.ResponseS3Key = state["s3URL_vndPayScaleResponse"];


        transactionDB.VendorCalls.push(vendorResponse);

        //upload Request into S3 bucket
        var transactinDataPromise = awsAssistant.saveAsyncDataIntoDynamoDB(transactionDB,
            state["awsConfiguration"].dynamoTransactionTableName, state["awsConfiguration"]);
        transactinDataPromise.then(function (data) {
            resolve(state);
        }, function (err) {
            state._traceLog._type = "Error";
            state._traceLog._msg = "Error Persisting Data to DynamoDB Message: " + err.message;
            var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
            logger.logHelper(state);
            state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
            reject(state);

        }

        )
            .catch(err => {
                state._traceLog._type = "Error";
                state._traceLog._msg = "Error Persisting Data to DynamoDB Message: " + err.message;
                var message = "Internal Server Error, Cannot process your request. TransactionID: " + state._transactionID;
                logger.logHelper(state);
                state._responseObject = responseBuilderUseCase.buildErrorResponse(message, state._requestHeaders, 500);
                reject(state);

            });
    });
}

function sucessfulExcecution(state) {

    state._traceLog._ts = state._startTime;
    state._traceLog._tags = "IncomeEstimateService Completion";
    state._traceLog._className = "postRequest.js";
    state._traceLog._function = "sucess";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog._msg = "Sucesfully executed IncomeEstimateService Call";
    state._traceLog.enabled = true;

    logger.logSteps(state);
}




const responseBuilderUseCase = require("../usecase/responseBuilderUseCase.js");
const uuidv4 = require('uuid/v4');
const awsAssistant = require("../Assistants/awsAssistant.js");
const logger = require("../Assistants/logAssistant");
const responseModel = require("../models/serviceModels").canonicalResponse;
exports.migrate = migrate;

async function migrate(state) {
    try {
        decodeRequestBody(state);
        const requestBody = JSON.parse(state.rawServiceRequest);
        const transactionID = requestBody.transactionID || requestBody.serviceResponse.TransactionID || state.context["params"]["header"]["fams-id"] || uuidv4();

        requestBody.serviceResponse.TransactionID = transactionID;

        const config = state.awsConfiguration;
        //validate request
        let validationErrors = [];

        if (!requestBody.serviceResponse) {
            validationErrors.push("serviceResponse is required");
        }

        if (!requestBody.serviceResponse.RequestorID) {
            validationErrors.push("RequestorID is required");
        }

        if (!requestBody.companyID) {
            validationErrors.push("companyID is required");
        }

        let result = requestBody.serviceResponse.Result;

        if (!result) {
            validationErrors.push("Result is required");
        }

        for (let key of Object.keys(responseModel.Result)) {
            if (result[key] === undefined || result[key] === null) {
                validationErrors.push(`Result.${key} is required`);
            }
        }

        if (result.MatchingJobs) {
            if (!result.MatchingJobs.length) {
                validationErrors.push("Result.MatchingJobs must have at least one element");
            }

            if (result.MatchingJobs.length) {
                for(let job of result.MatchingJobs){
                    if(!job){
                        validationErrors.push("Result.MatchingJobs cannot contain empty or null elements");
                    }
                }
            }
        }

        if (validationErrors.length) {
            return responseBuilderUseCase.buildErrorResponse(validationErrors.join("; "), state._requestHeaders, 400);
        }

        await awsAssistant.uploadFiletoS3(
            JSON.stringify(requestBody.serviceResponse),
            `ServiceResponses/v1/${requestBody.companyID.toLowerCase()}_${transactionID}`,
            'application/json',
            config);

        let resp = {
            "URL": `https://${process.env.RETURN_BASE_URL}/v1/${process.env.SERVICE_ZONE_NAME}/report?transactionID=${transactionID}`
        }

        return responseBuilderUseCase.buildResponse(JSON.stringify(resp), "application/json", 200);
    }
    catch (err) {
        state._traceLog._error = {
            stack: err.stack,
            msg: err.message
        };
        logger.logHelper(state);
        return responseBuilderUseCase.buildErrorResponse("Failed to migrate", state._requestHeaders, 500);
    }
}

function decodeRequestBody(state) {
    state._traceLog._tags = [];
    state._traceLog._ts = new Date();
    state._traceLog._tags.push("Request Decode");
    state._traceLog._className = "migration.js";
    state._traceLog._function = "decodeRequestBody";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;

    try {
        if (state.context.body) {
            state.responseContext = state.rawServiceRequest = new Buffer(state.context.body, 'base64').toString();
            state._traceLog._tags.push("migration.decodeRequestBody execution time.");
            return;
        }
        else {
            state._traceLog._type = "Error";
            state._traceLog._msg = "Invalid Request Type, TransactionID=" + state._transactionID;
            state._responseObject = responseBuilderUseCase.buildErrorResponse("Invalid Request Type", state._requestHeaders, 415);
        }
    }
    catch (err) {
        state._traceLog._type = "Error";
        state._traceLog._msg = err.message + " TransactionID: " + state._transactionID;
        state._responseObject = responseBuilderUseCase.buildErrorResponse("Invalid Request Type", state._requestHeaders, 500);
    }
};
var serviceModels = require("./models/serviceModels.js");
var responseBuilderUseCase = require("./usecase/responseBuilderUseCase.js");
var awsconfigAssistant = require("./Assistants/awsconfigurationAssistant.js");
var logger = require('./Assistants/logAssistant');

var responseObject = serviceModels.responseObject;

//AWS 
exports.routeHandler = function (event, context, callback) {

    var tracingLog = {
        _lambdaname: "IncomeEstimateService",
        _className: "index.js",
        _elapsedms: 0,
        _function: "routeHandler",
        _linenumber: 0,
        _msg: "",
        _ts: new Date(),
        _type: "Error",
        _tags: [
            "API",
            "AWS",
            "Lambda",
            "FAMS.IncomeEstimateService"
        ],
        portalcode: "",
        sourcefunction: "",
        transactionid: 0,
        enabled: true
    };

    //Define State Object
    var state = {
        _transactionID: "",
        _requestorID: "",
        _requestHeaders: {},
        _startTime: new Date(),
        _dataSource: "",
        _tag: "",
        _traceLog: tracingLog,
        context: "",
        _documentType: "",
        _schemaFile: "",
        _responseObject: serviceModels.responseObject
    };

    //Set AWS Configuration
    state["awsConfiguration"] = awsconfigAssistant.getAWSConfiguration();

    //Set Handlers
    var postHandler = require("./handlers/postRequest.js");
    var mockHandler = require("./handlers/postMockRequest.js");
    var gettHandler = require("./handlers/getRequest.js");
    var healthtHandler = require("./handlers/healthCheck.js");
    var pingHandler = require("./handlers/ping.js");
    const migrationHandler = require("./handlers/migration");
    var redactHandler = require("./handlers/redact.js");
    state.context = event;
    state.api_version = "v1";

    //logger.logTrace(state);

    if (state.context.bodyType == null)
        state._requestHeaders["content-type"] = "application/json";
    else
        state._requestHeaders["content-type"] = state.context.bodyType;

    if (!state.context.params.header["accept"])
        state._requestHeaders["accept"] = state._requestHeaders["content-type"];
    else
        state._requestHeaders["accept"] = event.params.header["accept"];

    if (state.context.params.header["isTest"] === true)
        state.isTest = true;

    var requestHandlerPromise;

    if (state.context.context["orig-path"].toLowerCase().match("order")
        && state.context.context["http-method"].toLowerCase().match("post"))
        requestHandlerPromise = postHandler.ProcessPostRequest(state);

    else if (state.context.context["orig-path"].toLowerCase().match("mock")
        && state.context.context["http-method"].toLowerCase().match("post"))
        requestHandlerPromise = mockHandler.ProcessPostMock(state);

    else if (state.context.context["orig-path"].toLowerCase().match("report")
        && state.context.context["http-method"].toLowerCase().match("get"))
        requestHandlerPromise = gettHandler.ProcessGetRequest(state);

    else if (state.context.context["orig-path"].toLowerCase().match("health")
        && state.context.context["http-method"].toLowerCase().match("get"))
        requestHandlerPromise = healthtHandler.processHealthCheck(state);
    else if (state.context.context["orig-path"].toLowerCase().match("ping")
        && state.context.context["http-method"].toLowerCase().match("get"))
        requestHandlerPromise = pingHandler.processPing(state);
    else if (state.context.context["orig-path"].toLowerCase().match("migratedata")
        && state.context.context["http-method"].toLowerCase().match("post"))
        requestHandlerPromise = migrationHandler.migrate(state);
    else if(state.context.context["orig-path"].toLowerCase().match("redact")
    && state.context.context["http-method"].toLowerCase().match("post"))
        requestHandlerPromise = redactHandler.ProcessRedactRequest(state);
    else {
        responseObject = responseBuilderUseCase.buildErrorResponse('Method Not Allowed', 405, state._requestHeaders["accept"]);
        return responseObject;
    }

    //Promise Execution
    requestHandlerPromise
        .then(function (jodiResponse) {
            callback(null, jodiResponse);
        }, function (jodiResponse) {
            callback(null, jodiResponse);
        });
}
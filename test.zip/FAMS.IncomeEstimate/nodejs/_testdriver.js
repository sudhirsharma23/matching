var app = require("./index.js");
var fs = require('fs');
const uuidv4 = require('uuid/v4');
var xml2js = require('xml2js');

var builder2 = new xml2js.Builder({headless: true});
var parser = new xml2js.Parser({ explicitArray: false, headless: true, mergeAttrs: true, valueProcessors: [xml2js.processors.parseNumbers] });

var dataXML = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><IncomeEstimateRequest>	<RequestorID>abc corp234123Z1</RequestorID>	<Individual>		<DateOfBirth>01/13/1976</DateOfBirth>	</Individual>	<Employer>		<EmployerName>Hello World</EmployerName>		<Title>Nurse</Title>		<YearsOnJob>3.14</YearsOnJob>		<YearsExperience>3.14</YearsExperience>	</Employer>	<Location>		<State>CA</State>	</Location>	<Income>		<BaseAnnualIncome>-30000</BaseAnnualIncome>		<Overtime>30</Overtime>		<Bonus>200</Bonus>		<Commissions>20</Commissions>	</Income></IncomeEstimateRequest>";


process.env.aws_region = "us-west-2";
process.env.S3_BUCKET = "sbx-income-estimate-api-w2-exact-hermit";
process.env.DYNAMODB_TRANSACTION_TABLE = "sbx-income-estimate-api-w2-transactions";
process.env.DYNAMODB_CACHE_TABLE = "IncomeEstimateCache";
process.env.ENVIRONMENT = "sbx";
process.env.SERVICE_ZONE_NAME  = "incomeestimate";
process.env.AWS_PROFILE = "sbx";

//kmsKeyID: process.env.KMS_KEY_ID

let builder = new xml2js.Builder({headless: true});


var request = JSON.parse(fs.readFileSync('./nodejs/Artifacts/unitTest/newOrderRequest.json', 'utf8').trim());
var jodiRequest = JSON.parse(fs.readFileSync('./nodejs/Artifacts/unitTest/jodiOrderRequest.json', 'utf8').trim());
var jodiRequest2 = JSON.parse(fs.readFileSync('./nodejs/Artifacts/unitTest/jodiOrderRequest.json', 'utf8').trim());

var _transactionID = uuidv4();
request.RequestorID = _transactionID;

var _strRequest = JSON.stringify(request);


jodiRequest.body = Buffer.from(dataXML).toString('base64');
jodiRequest.bodyType = "application/xml";


jodiRequest2.body = Buffer.from(_strRequest).toString('base64');
jodiRequest2.bodyType = "application/json";


var event = jodiRequest;
jodiRequest2.body = Buffer.from(_strRequest).toString('base64');
var event2 = jodiRequest2;

var context = {};
context.succeed = function (data) {
    console.log(JSON.stringify(data));
}
context.fail = function (msg) {
    console.log(msg);
}

var context2 = {};
context2.succeed = function (data) {

    var serviceResponse = JSON.parse(new Buffer(data.responseBody, 'base64').toString());
    var transactionID = serviceResponse["IncomeEstimateResponse"].TransactionID;
    testGet(transactionID);
    console.log("context2 : " + JSON.stringify(data));
}


context2.fail = function (msg) {
    console.log(msg);
}

//new order
app.routeHandler(event2, context, function (error, response) {
    console.log(JSON.stringify(response));
});


function testGet(transactionID) {
    var jodiRequest = JSON.parse(fs.readFileSync('./nodejs/Artifacts/unitTest/jodiOrderRequest.json', 'utf8').trim());
    jodiRequest["params"]["queryString"] = { "transactionID": transactionID };
    jodiRequest["context"]["http-method"] = "get";
    var getcontext = {};
    getcontext.succeed = function (data) {
        console.log(JSON.stringify(data));
    }
    getcontext.fail = function (msg) {
        console.log(msg);
    }

    var getEvent = jodiRequest;
    app.routeHandler(getEvent, getcontext);

}
//console.log(JSON.stringify(res));

//Cache Order
//var res = app.routeHandler(event,null);
//console.log(JSON.stringify(res));

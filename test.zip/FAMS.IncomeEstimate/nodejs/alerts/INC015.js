let serviceModels = require("../models/serviceModels.js");

let alertModel = JSON.parse(JSON.stringify(serviceModels.alertModel));
let alertStatus = serviceModels.alertStatus;

alertModel.Code = "INC015";
alertModel.Description = "The Borrower income may be overstated. The Annual Income for Borrower falls into the TOP ( X Percentage) of salaries for workers with a similar job profile.";
alertModel.Status = alertStatus.NotEvaluated;

exports.ExecuteLogic = function (state) {

    let _alertFactName = alertModel.Code;
    state[_alertFactName] = {
        alertFact: {
            transactionId: "",
            logicStep: "",
            logicExp: "",
            error: "",
            reason: "",
            position: "",
            percentVariance: "",
            status: alertStatus.NotFired,
            code: alertModel.Code,
            description: alertModel.Description
        }
    };    

    if (state.canonicalServiceRequest === null
        || typeof state.canonicalServiceRequest === "undefined"
        || state.canonicalServiceResponse === null
        || typeof state.canonicalServiceResponse === "undefined"
    ) {
        state[_alertFactName].alertFact.transactionId = state._transactionID;
        state[_alertFactName].alertFact.logicStep = "0.1";
        state[_alertFactName].alertFact.logicExp = "Data Verification";
        state[_alertFactName].alertFact.reason = "Request/Respones is NULL";
        state[_alertFactName].alertFact.status = alertStatus.NotFired;
		return;
	}

    var responseObj = typeof state.canonicalServiceResponse === "string" ? JSON.parse(state.canonicalServiceResponse) : state.canonicalServiceResponse;
    var requestObj = typeof state.canonicalServiceRequest === "string" ? JSON.parse(state.canonicalServiceRequest) : state.canonicalServiceRequest;	

	var overStateCompScore = responseObj.Result.OverstatedCompScore;
	if (overStateCompScore === null
		|| typeof overStateCompScore === "undefined") {
        state[_alertFactName].alertFact.logicStep = "0.2";
        state[_alertFactName].alertFact.logicExp = "Required Data Verification";
        state[_alertFactName].alertFact.reason = "Missing required data --- OverstateCompScore";
        state[_alertFactName].alertFact.status = alertStatus.NotFired;
		return;
	}

	if(isNaN(overStateCompScore)){
        state[_alertFactName].alertFact.logicStep = "0.3";
        state[_alertFactName].alertFact.logicExp = "Required Data Verification";
        state[_alertFactName].alertFact.reason = "OverstateCompScore is not a number";
        state[_alertFactName].alertFact.status = alertStatus.NotFired;
		return;
	}
	
    state[_alertFactName].alertFact.logicStep = "1";
    state[_alertFactName].alertFact.logicExp = "Check OverstateCompScore",
	overStateCompScore = typeof (overStateCompScore) === "number" ? overStateCompScore : parseInt(overStateCompScore);
	if(overStateCompScore >= 300){
        state[_alertFactName].alertFact.status = alertStatus.Fired;
        state[_alertFactName].alertFact.position = requestObj.Employer.Title;
        state[_alertFactName].alertFact.percentVariance = "5";
		if (overStateCompScore >= 500) {
            state[_alertFactName].alertFact.percentVariance = "1";
		}
	}	

    if (typeof responseObj.Alerts === "undefined"
        || responseObj.Alerts === null) {
        responseObj.Alerts = [];
    }

    alertModel.Status = state[_alertFactName].alertFact.status;
    alertModel.Evidence = {
        position: state[_alertFactName].alertFact.position,
        percentVariance: state[_alertFactName].alertFact.percentVariance
    };
    responseObj.Alerts.push(alertModel);
	
    state.canonicalServiceResponse = responseObj;
	state.context = responseObj;
	state.responseContext = JSON.stringify(responseObj);


}
let serviceModels = require("../models/serviceModels.js");

let alertModel = JSON.parse(JSON.stringify(serviceModels.alertModel));
let alertStatus = serviceModels.alertStatus;

alertModel.Code = "INC003";
alertModel.Description = "Income could not be estimated for one or more Borrowers due to limited salary information on the Borrower's position.";
alertModel.Status = alertStatus.NotEvaluated;

exports.ExecuteLogic = function (state) {  

    let _alertFactName = alertModel.Code;
    state[_alertFactName] = {
        alertFact: {
            transactionId: "",
            logicStep: "",
            logicExp: "",
            error: "",
            reason: "",
            position: "",
            status: alertStatus.NotFired,
            code: alertModel.Code,
            description: alertModel.Description
        }
    };    

    let errorCode = ["JobNotFound", "NotEnoughData"];
  
    if (state.canonicalServiceRequest === null
        || typeof state.canonicalServiceRequest === "undefined"
        || state.canonicalServiceResponse === null
        || typeof state.canonicalServiceResponse === "undefined"
    ) {
        state[_alertFactName].alertFact.transactionId = state._transactionID;
        state[_alertFactName].alertFact.logicStep = "0.1";
        state[_alertFactName].alertFact.logicExp = "Data Verification";
        state[_alertFactName].alertFact.reason = "Request/Respones is NULL";
        state[_alertFactName].alertFact.status = alertStatus.NotFired;
        return;
    }

    let requestObj = typeof state.canonicalServiceRequest === "string" ?
                             JSON.parse(state.canonicalServiceRequest) :
                             state.canonicalServiceRequest;

    let responseObj = typeof state.canonicalServiceResponse === "string" ?
                             JSON.parse(state.canonicalServiceResponse) :
                             state.canonicalServiceResponse;   

    let statusCode = responseObj.Status.StatusCode;

    if (statusCode !== null
        && typeof statusCode === "string"        
        && errorCode.includes(statusCode)) {    
        
        state[_alertFactName].alertFact.logicStep = "1";
        state[_alertFactName].alertFact.logicExp = "1.0";
        state[_alertFactName].alertFact.reason = "Check Income Estimate Responses";
        state[_alertFactName].alertFact.error = "None";
        state[_alertFactName].alertFact.position = requestObj.Employer.Title;
        state[_alertFactName].alertFact.status = alertStatus.Fired;
    }

    if (typeof responseObj.Alerts === "undefined"
        || responseObj.Alerts === null) {
        responseObj.Alerts = [];
    }

    alertModel.Status = state[_alertFactName].alertFact.status;
    alertModel.Evidence = {
        position: state[_alertFactName].alertFact.position
    };
    responseObj.Alerts.push(alertModel);

    state.canonicalServiceResponse = responseObj;
    state.context = responseObj;
    state.responseContext = JSON.stringify(responseObj);
}
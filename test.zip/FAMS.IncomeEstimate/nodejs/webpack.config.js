const path = require('path');
module.exports = {
    stats: {
        warnings: false
    },
    entry: './index.js',
    externals: [
        {
            "request": "require('request')",
            "forever-agent": "require('forever-agent')",
            "tough-cookie": "require('tough-cookie')",
            "tunnel-agent": "require('tunnel-agent')"
        }
    ],
  output: {
    filename: 'final.js',
    path: path.resolve(__dirname, 'dist')
  },
  optimization: {
		// We no not want to minimize our code.
		minimize: false
	}
};
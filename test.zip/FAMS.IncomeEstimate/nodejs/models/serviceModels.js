var canonicalResponse = {
    TransactionID: "",
    RequestorID: "",
    Status : {
        StatusCode : "OK",
        StatusDescription : "Success"
    },
    Result: {
        MatchingJobs: [],
        OverstatedCompScore: 0,
        TargetCompensation: 0.0,
        Percentile25: 0.0,
        Median: 0.0,
        Percentile75: 0.0
    },
    Alerts: []
};

var alertModel = {
    Code: "",
    Description: "",
    Evidence: [],
    Status: ""
};

var alertStatus = {
    Fired: "Fired",
    NotFired: "NotFired",
    NotEvaluated: "NotEvaluated"
};

var serviceRequest = {
    RequestorID: '',
    Individual: {
        DateOfBirth: ''
    },
    Employer: {
        EmployerName: '',
        Title: '',
        YearsOnJob: 3.14,
        YearsExperience: 3.14
    },
    Location: {
        State: '',
        City: ''
    },
    Income: {
        BaseAnnualIncome: 30000,
        Overtime: 30,
        Bonus: 200,
        Commissions: 20
    }
};

var responseObject = {
    "errorMessage": {
        "httpStatus": '',
        "error": ""
    },
    "httpStatus": 200,
    "content-type": "application/json",
    "responseBody": "Base64Encoded response",
    "isBase64Encoded": true
}



var jodiRequest = {
    "lambda": "sample",
    "bodyType": "application/json",
    "body": "ew0KICAicm9vdCIgOiAidGVzdCBkYXRhIg0KfQ==",
    "params": {
        "header": {
            "connection": "upgrade",
            "host": "d1fc808697b3c47ed9761a840486b5c8-1536932855.us-west-2.elb.amazonaws.com",
            "x-source-ip": "10.243.64.132",
            "x-orig-path": "/sample-payload",
            "x-request-id": "7ea67269-83c6-48d4-add1-999e614fc7d2",
            "x-cert-verified": "NONE",
            "content-length": "28",
            "content-type": "application/json",
            "user-agent": "vscode-restclient",
            "accept-encoding": "gzip, deflate"
        },
        "queryString": {},
        "persona": {
            "PortalID": "DnA-FraudGuard",
            "ClientID": "DISSCOQA"
        }
    },
    "context": {
        "http-method": "POST",
        "source-ip": "10.243.64.132",
        "orig-path": "/sample-payload",
        "request-id": "7ea67269-83c6-48d4-add1-999e614fc7d2",
        "stage": "sbx"
    },
    "stage-variables": {}
}

var mockRequest = {
    "VendorCode": "Payscale",
    "MockServiceRequest": serviceRequest,
    "MockVendorResponse": "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><EvaluatePayResponse xmlns=\"http://services.payscale.com/compensationSearch/060930\"><EvaluatePayResult><Error>None</Error><ResponseID>96981399-e7cf-4c20-9d81-632cb550ecf5</ResponseID><MatchingJobs>Registered Nurse (RN)</MatchingJobs><MatchingJobs>Certified Nurse Assistant (CNA)</MatchingJobs><MatchingJobs>Licensed Practical Nurse (LPN)</MatchingJobs><MatchingJobs>Staff Nurse</MatchingJobs><MatchingJobs>Registered Nurse (RN), Emergency Room</MatchingJobs><OverstatedCompScore>411</OverstatedCompScore><TargetCompensation>29114.652201701349</TargetCompensation><Percentile25>68068.1096859636</Percentile25><Median>78142.353684417089</Median><Percentile75>84757.842773431359</Percentile75></EvaluatePayResult></EvaluatePayResponse></soap:Body></soap:Envelope>"
};


module.exports = {
    canonicalResponse: canonicalResponse,
    serviceRequest: serviceRequest,
    responseObject: responseObject,
    alertModel: alertModel,
    alertStatus: alertStatus
}
var vnd_Details = {
    vendorName : "Payscale",
    product: "EvaluatePay",
    url : 'http://services.payscale.com/compensationsearchv2.asmx',
    timeoutMS :   8000,
    username : '',
    password : '',
    isTest : true,
    cachePeriodDays : 60 ,
   
};




const documentTypes = {

serviceRequest : "serviceRequest",
canonicalRequest : "canonicalJsonRequest",
payscaleRequest : "payscaleRequest",
payscaleResponse : "payscaleResponse",
payscaleJsonResponse : "payscaleJsonResponse",
serviceJsonResponse : "canonicalJsonResponse",
canonicalServiceResponse : "canonicalServiceResponse"

};

module.exports = {
    vnd_Details : vnd_Details,
    documentTypes : documentTypes
   
}
var transactionDB =
  {
  AppPlan: "TestIdentity",
  CacheKey: "",
  ClientID: "DEVTEST",
  CompanyName: "FAMSTESTCO", //Added this because we do pass this through to some vendors so we way want to record it
  DataSource: "Vendor",
  DateTimeUTC: "2018-04-04T23:21:03.743Z",
  Elapsedms: 5833,
  GlobalID: "FAMSTESTCO",
  HttpStatus: 200,   //Service Http status returned
  OrderStatus: "OK",
  PortalCode: "API",
  Product: "EvaluatePay", //Requested API product
  RequestorID: "",
  RequestS3Key: "", //Service request S3 Key
  ResponseS3Key: "", // Service response S3 key
  TransactionID: "",
  ServiceName: process.env.SERVICE_ZONE_NAME,
  VendorCalls: [],
  RedactedRequestS3Key: ""
};

var cacheDB =
{
  CacheKey  : "",
  S3ResponseKey :  "",
  DateTimeUTC :  ""
};


var vendorResponse = 
  {
    DateTimeUTC: new Date().toISOString(),
    Elapsedms: 0,
    HttpStatus: 200,
    Name: "PayScale", //Vendor name
    Product: "EvaluatePay",     //Vendor Product
    Sequence: 1, //Priority order in which vendor was called
    RequestS3Key: "",
    ResponseS3Key: ""
  };



module.exports = {
    transactionDB : transactionDB,
    vendorResponse : vendorResponse,
    cacheDB : cacheDB
}
let greenColor = "\x1b[32m";
let blackColor = "\x1b[0m";
let redColor = "\033[31m";


try {
    console.log("Entering test...");

    //Fire
    test("Test for ErrorCode JobNotPreciseEnough",
        "../../Artifacts/unitTest/alerts/INC004/Fire/Request.json",
        "../../Artifacts/unitTest/alerts/INC004/Fire/Fire_Response_JobNotPreciseEnough.json",
        "Fired");

    test("Test for ErrorCode JobFoundOnGenericList",
        "../../Artifacts/unitTest/alerts/INC004/Fire/Request.json",
        "../../Artifacts/unitTest/alerts/INC004/Fire/Fire_Response_JobFoundOnGenericList.json",
        "Fired");

    //NoFire
    test("Test for ErrorCode None",
        "../../Artifacts/unitTest/alerts/INC004/Fire/Request.json",
        "../../Artifacts/unitTest/alerts/INC004/NoFire/NoFire_Response_OK.json",
        "NotFired");

    test("Test for Null ErrorCode",
        "../../Artifacts/unitTest/alerts/INC004/Fire/Request.json",
        "../../Artifacts/unitTest/alerts/INC004/NoFire/NoFire_Response_Null_Error.json",
        "NotFired");

    test("Test for Empty ErrorCode",
        "../../Artifacts/unitTest/alerts/INC004/Fire/Request.json",
        "../../Artifacts/unitTest/alerts/INC004/NoFire/NoFire_Response_Empty_Error.json",
        "NotFired");
   
    console.log("Exiting test succesfully...");
}
catch (error) {
    console.log("Entering catch block to handle exception...");
    console.log(error);
}
finally {
    //wait for input to close
    console.log("Press any key to exit...");
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', process.exit.bind(process, 0));
}


function test(testName, pathToTestRequest, pathToTestResponse, shouldAlertFire) {

    var inc_004 = require("../../alerts/INC004.js");
    var sampleRequest = require(pathToTestRequest);
    var sampleResponse = require(pathToTestResponse);
    //Define State Object
    var state = {
        _transactionID: "",
        _requestorID: "",
        _requestHeaders: [],
        _startTime: new Date(),
        _dataSource: "",
        _tag: "",
        _traceLog: "",
        context: "",
        _documentType: "",
        _schemaFile: "",
        _responseObject: "",
        rawServiceRequest: sampleRequest,
        rawServiceResponse: sampleResponse,
        canonicalServiceRequest: sampleRequest,
        canonicalServiceResponse: sampleResponse
    };

    inc_004.ExecuteLogic(state);

    var responseObj = state.canonicalServiceResponse;
    var inc004alert = responseObj.Alerts[0];    
    if (inc004alert.Status === shouldAlertFire) {
        console.log(blackColor + testName + " --- " + greenColor + "Passed" + blackColor);
  
    }
    else {
        console.log(blackColor + testName + " --- " + redColor + "Failed" + blackColor);
        console.log(state["INC004"]);
    }
}
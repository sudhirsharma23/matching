let greenColor = "\x1b[32m";
let blackColor = "\x1b[0m";
let redColor = "\033[31m";

try {
    console.log("Entering test...");

    testAlertUseCase(true, true)
    .then(function () {
        testAlertUseCase(false, false);
    }).then(function () {
        testAlertUseCase("true", true);
    }).then(function () {
        testAlertUseCase("false", false);
    }).then( function () {
        testAlertUseCase(1, false);
    });
    
    //testAlertUseCase("true", true);
    //testAlertUseCase("false", false);
    //testAlertUseCase(1, false);


    console.log("Exit test succesfully...")
}
catch (error) {

    console.log("Entering catch block to handle exception...");
    console.log(error);
}
finally {

    //wait for input to close
    console.log("Press any key to exit...");
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', process.exit.bind(process, 0));
}

function testAlertUseCase(includeAnalyticValue, shouldResponseHasAlerts) {

    let sampleRequest = require("../../Artifacts/unitTest/alerts/INC004/Fire/Request.json");
    let sampleResponse = require("../../Artifacts/unitTest/alerts/INC004/Fire/Fire_Response_JobNotPreciseEnough.json");

    sampleRequest.IncludeAnalytics = includeAnalyticValue;

    return new Promise(function (resolve, reject) {
        let state = {
            _transactionID: "",
            _requestorID: "",
            _requestHeaders: [],
            _startTime: new Date(),
            _dataSource: "",
            _tag: "",
            _traceLog: "",
            context: "",
            _documentType: "",
            _schemaFile: "",
            _responseObject: "",
            rawServiceRequest: sampleRequest,
            rawServiceResponse: sampleResponse,
            canonicalServiceRequest: sampleRequest,
            canonicalServiceResponse: sampleResponse
        };

        let alertUseCase = require("../../usecase/alertUseCase.js");

        let buildAlertPromise = alertUseCase.buildAlertResponseData(state);

        buildAlertPromise.then(function (state) {

            let response = state.canonicalServiceResponse;

            if (typeof response === "string") {
                response = JSON.parse(response);
            }

            let testName = "IncludeAnalytic --- Value: " + includeAnalyticValue + "--- Type: " + typeof includeAnalyticValue;
            let alerts = response.Alerts;
            let didTestPass = false;
            if (shouldResponseHasAlerts) {

                let alertsString = JSON.stringify(alerts);
                didTestPass = alertsString.includes("INC003")
                    && alertsString.includes("INC004")
                    && alertsString.includes("INC015");
            }
            else {
                didTestPass = typeof alerts === "undefined";
            }

            if (didTestPass) {
                console.log(blackColor + testName + " --- " + greenColor + "Passed" + blackColor);
            }
            else {
                console.log(blackColor + testName + " --- " + redColor + "Failed" + blackColor);
            }           
        });  

        resolve();
    });  
   
}
let greenColor = "\x1b[32m";
let blackColor = "\x1b[0m";
let redColor = "\033[31m";


try {
    console.log("Entering test...");

    ////Fire
    //test("Test for OverstateCompScore 300",
    //    "../../Artifacts/unitTest/alerts/INC015/Fire/Request.json",
    //    "../../Artifacts/unitTest/alerts/INC015/Fire/Fire_Response_OverstateCompScore_300.json",
    //    "Fired");

    //test("Test for OverstateCompScore 500",
    //    "../../Artifacts/unitTest/alerts/INC015/Fire/Request.json",
    //    "../../Artifacts/unitTest/alerts/INC015/Fire/Fire_Response_OverstateCompScore_500.json",
    //    "Fired");

    ////NoFire
    //test("Test for OverstateCompScore 299",
    //    "../../Artifacts/unitTest/alerts/INC015/Fire/Request.json",
    //    "../../Artifacts/unitTest/alerts/INC015/NoFire/NoFire_Response_OverstateCompScore_299.json",
    //    "NotFired");

    test("Test for OverstateCompScore Zero",
        "../../Artifacts/unitTest/alerts/INC015/Fire/Request.json",
        "../../Artifacts/unitTest/alerts/INC015/NoFire/NoFire_Response_OverstateCompScore_Zero.json",
        "NotFired");

    test("Test for OverstateCompScore Negative",
        "../../Artifacts/unitTest/alerts/INC015/Fire/Request.json",
        "../../Artifacts/unitTest/alerts/INC015/NoFire/NoFire_Response_OverstateCompScore_Negative.json",
        "NotFired");

    console.log("Exiting test succesfully...");
}
catch (error) {
    console.log("Entering catch block to handle exception...");
    console.log(error);
}
finally {
    //wait for input to close
    console.log("Press any key to exit...");
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', process.exit.bind(process, 0));
}


function test(testName, pathToTestRequest, pathToTestResponse, shouldAlertFire) {

    var inc_015 = require("../../alerts/INC015.js");
    var sampleRequest = require(pathToTestRequest);
    var sampleResponse = require(pathToTestResponse);
    //Define State Object
    var state = {
        _transactionID: "",
        _requestorID: "",
        _requestHeaders: [],
        _startTime: new Date(),
        _dataSource: "",
        _tag: "",
        _traceLog: "",
        context: "",
        _documentType: "",
        _schemaFile: "",
        _responseObject: "",
        rawServiceRequest: sampleRequest,
        rawServiceResponse: sampleResponse,
        canonicalServiceRequest: sampleRequest,
        canonicalServiceResponse: sampleResponse
    };

    inc_015.ExecuteLogic(state);

    var responseObj = state.canonicalServiceResponse;
    var inc_015 = responseObj.Alerts[0];
    if (inc_015.Status === shouldAlertFire) {
        console.log(blackColor + testName + " --- " + greenColor + "Passed" + blackColor);
      
    }
    else {
        console.log(blackColor + testName + " --- " + redColor + "Failed" + blackColor);
        console.log(state["INC015"]);
    }
}
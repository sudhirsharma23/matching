//You need to set up a "default" profile and log into corp azure-aws-cred application with that default profile. Info on FALive.
// To test locally: Open cmd, go to the location of this file, type in: node secretsManagerAssistantTest.js
var fs = require('fs');
var secretAssistant = require('../../Assistants/secretsManagerAssistant');
var serviceModels = require("../../models/serviceModels.js");
var awsConfigAssistant = require("../../Assistants/awsconfigurationAssistant.js");


//Set local environment variables
process.env.AWS_REGION = "us-west-2";

var jodiRequest = JSON.parse(fs.readFileSync('../../Artifacts/unitTest/jodiOrderRequest.json', 'utf-8'));

var tracingLog = {
    _lambdaname: "IncomeEstimateService",
    _className: "secretsManagerAssistantTest.js",
    _elapsedms: 0,
    _function: "routeHandler",
    _linenumber: 0,
    _msg: "",
    _ts: new Date(),
    _type: "Error",
    _tags: [
        "API",
        "AWS",
        "Lambda",
        "FAMS.IncomeEstimateService"
    ],
    portalcode: "",
    sourcefunction: "",
    transactionid: 0,
    enabled: true
};

//Define State Object
var state = {
    _transactionID: "",
    _requestorID: "",
    _requestHeaders: {},
    _startTime: new Date(),
    _dataSource: "",
    _tag: "",
    _traceLog: tracingLog,
    context: "",
    _documentType: "",
    _schemaFile: "",
    _responseObject: serviceModels.responseObject
};


state["awsConfiguration"] = awsConfigAssistant.getAWSConfiguration();
state.context = jodiRequest;
state["persona"] = state.context.params.persona;

var getSecretPromise = secretAssistant.getVendorCredentialFromSecretsManager(state);
getSecretPromise.then(data => console.log(data)).catch(err => console.log(err));



// To test locally: Open cmd, go to the location of this file, type in: node vendorCredentialAssistantTest.js
var fs = require('fs');
var vendorCredAssistant = require('../../Assistants/vendorCredentialAssistant.js');
var serviceModels = require("../../models/serviceModels.js");
var awsConfigAssistant = require("../../Assistants/awsconfigurationAssistant.js");
var configAssistant = require("../../Assistants/configurationAssistant.js");

//Set local environment variables
process.env.AWS_REGION = "us-west-2";
process.env.ENVIRONMENT = "sbx";

var jodiRequest = JSON.parse(fs.readFileSync('../../Artifacts/unitTest/jodiOrderRequest.json', 'utf-8'));

var tracingLog = {
    _lambdaname: "IncomeEstimateService",
    _className: "vendorCredentialAssistantTest.js",
    _elapsedms: 0,
    _function: "routeHandler",
    _linenumber: 0,
    _msg: "",
    _ts: new Date(),
    _type: "Error",
    _tags: [
        "API",
        "AWS",
        "Lambda",
        "FAMS.IncomeEstimateService"
    ],
    portalcode: "",
    sourcefunction: "",
    transactionid: 0,
    enabled: true
};

//Define State Object
var state = {
    _transactionID: "",
    _requestorID: "",
    _requestHeaders: {},
    _startTime: new Date(),
    _dataSource: "",
    _tag: "",
    _traceLog: tracingLog,
    context: "",
    _documentType: "",
    _schemaFile: "",
    _responseObject: serviceModels.responseObject
};


state["awsConfiguration"] = awsConfigAssistant.getAWSConfiguration();
state.context = jodiRequest;
state["persona"] = state.context.params.persona;

configAssistant.getVendorConfigurations(state)
.then(vendorCredAssistant.getVendorCredential)
.then(data => console.log(`Login: ${state.vnd_Details.username}. Password: ${state.vnd_Details.password}`))
.catch(err => console.log(err));
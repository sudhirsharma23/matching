// To test locally: Open cmd, go to the location of this file, type in: node redactUseCaseTest.js
var redactUseCase = require('../../usecase/redactUseCase.js');
var serviceModels = require("../../models/serviceModels.js");
var parser = require('xml2js');
var awsConfigAssistant = require("../../Assistants/awsconfigurationAssistant.js");

process.env.aws_region = "us-west-2";
process.env.S3_BUCKET = "sbx-identity-api-w2-definite-ray";
process.env.DYNAMODB_TRANSACTION_TABLE = "sbx-identity-api-w2-definite-ray-transactions";
process.env.DYNAMODB_CACHE_TABLE = "IncomeEstimateCache";
process.env.ENVIRONMENT = "sbx";
process.env.SERVICE_ZONE_NAME  = "incomeestimate";
process.env.AWS_PROFILE = "sbx";

var tracingLog = {
    _lambdaname: "IncomeEstimateService",
    _className: "vendorCredentialAssistantTest.js",
    _elapsedms: 0,
    _function: "routeHandler",
    _linenumber: 0,
    _msg: "",
    _ts: new Date(),
    _type: "Error",
    _tags: [
        "API",
        "AWS",
        "Lambda",
        "FAMS.IncomeEstimateService"
    ],
    portalcode: "",
    sourcefunction: "",
    transactionid: 0,
    enabled: true
};

//Define State Object
var state = {
    _transactionID: "",
    _requestorID: "",
    _requestHeaders: {},
    _startTime: new Date(),
    _dataSource: "",
    _tag: "",
    _traceLog: tracingLog,
    context: "",
    _documentType: "",
    _schemaFile: "",
    _responseObject: serviceModels.responseObject,
    rawServiceRequest:""
};

state["awsConfiguration"] = awsConfigAssistant.getAWSConfiguration();
/*


// Test redact service request json
state._requestHeaders["content-type"] = "application/json"
state.rawServiceRequest = "{\"RequestorID\":\"abc-rmd-7\",\"Individual\":{\"DateOfBirth\":\"13\/31\/1976\"},\"Employer\":{\"Name\":\"First American\",\"Title\":\"Software Engineer\",\"YearsOnJob\":3.5,\"YearsExperience\":5},\"Location\":{\"State\":\"CA\"},\"Income\":{\"BaseAnnualIncome\":-30000,\"Overtime\":30,\"Bonus\":200,\"Commissions\":20}}";
redactUseCase.redact(state);
console.log(`Json Redact Test: \n ${state.redactedRawServiceRequest}`);


// Test redact service request xml
state._requestHeaders["content-type"] = "application/xml"
state.rawServiceRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?> <IncomeEstimateRequest> <RequestorID>abc corp234<\/RequestorID> <Individual> <DateOfBirth>01\/08\/1976<\/DateOfBirth> <\/Individual> <Employer> <EmployerName>Hello World<\/EmployerName> <Title>Manager<\/Title> <YearsOnJob>6<\/YearsOnJob> <YearsExperience>6<\/YearsExperience> <\/Employer> <Location> <State>CA<\/State><City>Los Angeles<\/City> <\/Location> <Income> <BaseAnnualIncome>30000<\/BaseAnnualIncome> <Overtime>30<\/Overtime> <Bonus>200<\/Bonus> <Commissions>20<\/Commissions> <\/Income> <\/IncomeEstimateRequest>";
redactUseCase.redact(state);
console.log(`XML Redact Test: \n ${state.redactedRawServiceRequest}`);

*/

//Test Legacy Redact
state.rawServiceRequest = "{ \"S3Key\":\"identity\/ServiceRequests\/v2\/0017cb98-5754-4a51-86da-99d9e3f4c6fc\", \"IsLatest\": true, \"VersionID\": \"3QNDIlcddb1IN24nFr7N6GTWYU9Qs31R\" }  ";
redactUseCase.LegacyRedact(state).then(data => console.log("success")).catch(e => console.log(e.message));


var http = require('http');


var logger = require("../Assistants/logAssistant.js");
var serviceModels = require("../models/serviceModels.js");
var configurationModels = require("../models/configurationModels.js");
var configAssistant = require("../Assistants/configurationAssistant.js");
var awsconfigAssistant = require("../Assistants/awsconfigurationAssistant.js");


const hostname = '127.0.0.1';
const port = 20090;

const server = http.createServer((request, response) => {

    var tracingLog =
        {

            _lambdaname: "IncomeEstimateService",
            _className: "index.js",
            _elapsedms: 0,
            _function: "exports Handler",
            _linenumber: 0,
            _msg: "",
            _ts: new Date(),
            _type: "Error",
            _tags: [
                "API",
                "AWS",
                "Lambda",
                "FAMS.IncomeEstimateService"
            ],
            portalcode: "",
            sourcefunction: "",
            transactionid: 0,
            enable: true


        }

    //Define State Object
    var state = {
        _transactionID: "",
        _requestorID: "",
        _requestHeaders: [],
        _startTime: new Date(),
        _dataSource: "",
        _tag: "",
        _traceLog: tracingLog,
        context: "",
        _documentType: "",
        _schemaFile: "",
        _responseObject: serviceModels.responseObject
    };



    const { headers, method, url } = request;

    //Get/Set Environment Variables
    process.env.aws_region = "us-east-1";
    process.env.s3_bucketname = "payscaleservice";
    process.env.aws_dynamo_transaction_table_name = "IncomeEstimateService";
    process.env.aws_dynamo_cache_table_name = "IncomeEstimateCache";
    process.env.environment = "sbx";

     

    state["awsConfiguration"] = awsconfigAssistant.getAWSConfiguration();

    state._startTime = new Date();
    
    if (method == 'POST') {
        const chunks = [];
        request.on('error', (err) => {
            console.error(err);
        });

        request.on('data', chunk => chunks.push(chunk));

        request.on('end', () => {
            var data = Buffer.concat(chunks).toString();
            state.context = JSON.parse(data);

            //Determine Headers

            state._requestHeaders = state.context.params["header"];


            if (state.context.bodyType == null)
                state._requestHeaders["content-type"] = "application/json";
            else
                state._requestHeaders["content-type"] = state.context.bodyType;


            if (state._requestHeaders["accept"] == null)
                state._requestHeaders["accept"] = state._requestHeaders["content-type"];

            var postHandler = require("../handlers/postRequest.js");
            var mockHandler = require("../handlers/postMockRequest.js");
            var gettHandler = require("../handlers/getRequest.js");
            var healthtHandler = require("../handlers/healthCheck.js");
            

            var initializePromise;

            if (state.context.context["orig-path"].toLowerCase().match("/order") 
                && state.context.context["http-method"].toLowerCase().match("post")) 
                initializePromise = postHandler.ProcessPostRequest(state);
            
            else if (state.context.context["orig-path"].toLowerCase().match("/mock")
                    && state.context.context["http-method"].toLowerCase().match("post") )
                initializePromise = mockHandler.ProcessPostMock(state);
            else if (state.context.context["orig-path"].toLowerCase().match("/order")
                    && state.context.context["http-method"].toLowerCase().match("get") )
                    initializePromise = gettHandler.ProcessGetRequest(state);
            else if (state.context.context["orig-path"].toLowerCase().match("/health")
                    && state.context.context["http-method"].toLowerCase().match("get") )
                    initializePromise = healthtHandler.processHealthCheck(state);

            else {
                response.statusCode = "405";
                response.setHeader('content-type', err.headers["content-type"]);
                response.write("Methdod Not allowed");
                response.end();
            }

            initializePromise.then(function (result) {

            response.statusCode = result.httpStatus;
            response.setHeader('content-type', result["content-type"]);
            response.write(result.responseBody);
           
                response.end();

            }, function (err) {
                response.statusCode = err.errorMessage.httpStatus;
                response.setHeader('content-type', err["content-type"]);
                response.write(err.error);
                response.end();
            }
            );


        });
    }
   



}
);


server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});






var Validator = require('jsonschema').Validator;

exports.validateJson = (state) => {

    try {
        var startTime = new Date();
        var jsonSchemaFilePath = '../Artifacts/Schemas/' + state._schemaFile + '.json';        
        var jsonSchema = require(jsonSchemaFilePath);        
        state._traceLog.jsonSchemaPath = jsonSchemaFilePath;

        var validator = new Validator();
        var result = validator.validate(state.context, jsonSchema);

        let errMSG = null;
        var endTime = new Date();

        state._tag = "ValidateIncomeEstimateServiceRequest"
        state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();
        state._traceLog._className = "validationAssistant.js";
        state._traceLog._function = "exports.validateJson";
        state._traceLog._type = "Information";
        state._traceLog.transactionid = state._transactionID;

        state._traceLog._tags.push("validationAssistant.exports.validateJson execution time.");

        if (!result.valid) {
            errMSG = getValidationMessage(result.errors);
            state._traceLog._msg = errMSG;
        }

        return errMSG;
    }
    catch (err) {
        state._traceLog.err = err;
        return err;
    }
}


function getValidationMessage(err) {
    var errorMessage;
    var error;
    if (err != null) {
        if (err.filter(y => y["name"] == "required")) {
            error = err.filter(y => y["name"] == "required");
            errorMessage = error.map(y => y["schema"]["properties"][y["argument"]]["messages"]["required"]);
        }
        if (err.filter(y => y["name"] != "required")) {
            error = err.filter(y => y["name"] != "required");
            errorMessage = errorMessage.concat(error.map(y => y["schema"]["messages"][y["name"]]));
        }
    }

    return errorMessage;
}


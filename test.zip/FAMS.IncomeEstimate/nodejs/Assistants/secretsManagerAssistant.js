var aws = require('aws-sdk');

exports.getVendorCredentialFromSecretsManager = (state) => {

    return new Promise((resolve, reject) => {
        let configOverride = state.persona.configoverride;
        let credsID = state.persona.credsid;
        let portalCode = state.persona.portalCode.toLowerCase();
        let secretName = `payscale/${portalCode}/default`;
        let aws_region = state.awsConfiguration.region;

        if(configOverride != null && configOverride.toLowerCase() == "true"){
            let globalID = state.persona.globalID.toLowerCase();
            secretName = `payscale/${globalID}/${credsID}`;
        }

        var client = new aws.SecretsManager({region: aws_region});
        client.getSecretValue({SecretId: secretName}, function(err, data){
            if(err){
                let errorMsg = `Failed to Get Secret. SecretName: ${secretName}. Message: ${err.message}`;
                reject(errorMsg);
            }
            else{
                resolve(data.SecretString);
            }
        })
    });
}
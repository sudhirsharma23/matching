const NodeCache = require("node-cache");
const Config = require("../config.json");

var configurationModel = require("../models/configurationModels.js");
var awsAssistant = require("../Assistants/awsAssistant.js");

var vnd_Details;


const myCache = new NodeCache();
const vndconfigkeyName = "vnd_Configuration";

exports.getVendorConfigurations = (state) => {
    state._traceLog._ts = new Date();
    var startTime = new Date();

    state._traceLog._tags = [];
    state._traceLog._tags.push("Get Vendor Configuration.");
    state._traceLog._className = "configurationAssistant.js";
    state._traceLog._function = "exports.getVendorConfigurations";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;
    return new Promise((resolve, reject) => {

        var awsConfiguration = state["awsConfiguration"];
        state["environment"] = awsConfiguration.environment;

        vnd_Details = myCache.get(vndconfigkeyName);
        let portalCode = state["persona"].portalCode.toLowerCase();

        if (vnd_Details == null) {
            vnd_Details = configurationModel.vnd_Details;

            const defaultConfig = Config.default;

            //Apply portal overrides
            if (defaultConfig[portalCode]) {
                //TODO: add portal code override
                throw new Error("Portal code override not implemented");
            }

            vnd_Details.cachePeriodDays = defaultConfig.CachePeriodDays;
            vnd_Details.timeoutMS = defaultConfig.Vendors.PayScale.TimeoutMS;

            var vndData = defaultConfig.Environment[state["environment"]]["Vendors"]["PayScale"];
            vnd_Details.vendorName = defaultConfig.Vendors.PayScale.VendorName,
                vnd_Details.product = defaultConfig.Vendors.PayScale.VendorProduct,
                vnd_Details.url = vndData.URL;
            vnd_Details.username = vndData.Login;
            vnd_Details.password = vndData.Password;
            vnd_Details.isTest = vndData.IsTest;


            success = myCache.set(vndconfigkeyName, vnd_Details, 0);
            state["vnd_Details"] = vnd_Details;
            resolve(state);

        }
        else {
            state["vnd_Details"] = vnd_Details;
            resolve(state);
        }

    },
        function (err) {
            state._traceLog._type = "Error";
            state._traceLog._msg = "Failed to Fetch configuration! Message: " + err.message;
            reject(state);

        }
    )
}


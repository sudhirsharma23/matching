const aws = require('aws-sdk');
const moment = require("moment");

exports.uploadFiletoS3 = function (contents, fileName, contentType, awsConfigurations, cacheDays) {
    aws.config.setPromisesDependency(null);
    aws.config.update({
        region: awsConfigurations.region
    });

    var s3Client = new aws.S3({
        "signatureVersion": "v4"
    });

    var params = {
        Bucket: awsConfigurations.bucketName,
        Key: fileName,
        Body: contents,
        ContentType: contentType,
    };

    if(cacheDays){
        params.Expires = moment.utc().add(cacheDays, 'day').toISOString()
    }

    if(awsConfigurations.kmsKeyID){
        params["SSEKMSKeyId"] = awsConfigurations.kmsKeyID;
        params["ServerSideEncryption"] = "aws:kms"
    }

    return s3Client.putObject(params).promise();
}

exports.getFileFromS3 = function (s3Url, awsConfigurations) {
    aws.config.setPromisesDependency(null);
    aws.config.update({
        region: awsConfigurations.region
    });

    var s3Client = new aws.S3({
        "signatureVersion": "v4"
    });

    var params = {
        Bucket: awsConfigurations.bucketName,
        Key: s3Url
    };

    return s3Client.getObject(params).promise();
}

exports.checkS3BucketExists = function (awsConfigurations) {
    aws.config.setPromisesDependency(null);
    aws.config.update({
        region: awsConfigurations.region
    });

    var s3Client = new aws.S3({
        "signatureVersion": "v4"
    });


    var params = {
        Bucket: awsConfigurations.bucketName,
    };

    return s3Client.headBucket(params).promise();
}




exports.saveDataIntoDynamoDB = function (items, tableName, awsConfigurations) {

    aws.config.update({
        region: awsConfigurations.region
    });

    var dynamoDBClient = new aws.DynamoDB.DocumentClient();
    var transactOrder = removeEmptyStringElements(items);


    var dynamoDBClientParams = {
        TableName: tableName,
        Item: transactOrder
    };


    dynamoDBClient.put(dynamoDBClientParams, function (err, data) {
        if (err) {
            console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
        } else {
            console.log("Added item:", JSON.stringify(items, null, 2));
        }
    });

    return items;

}

exports.saveAsyncDataIntoDynamoDB = function (items, tableName, awsConfigurations) {
    aws.config.setPromisesDependency(null);
    aws.config.update({
        region: awsConfigurations.region
    });

    var dynamoDBClient = new aws.DynamoDB.DocumentClient();
    var transactOrder = removeEmptyStringElements(items);

    var dynamoDBClientParams = {
        TableName: tableName,
        Item: transactOrder
    };


    return dynamoDBClient.put(dynamoDBClientParams).promise();

}

exports.getTransactionFromDynamoDB = function (transactionID,awsConfigurations) {

    aws.config.update({
        region: awsConfigurations.region
    });

    var dynamoDBClient = new aws.DynamoDB.DocumentClient();

    var dynamoDBClientParams = {
        TableName: awsConfigurations.dynamoTransactionTableName,
        KeyConditionExpression: "#TransactionID = :TransactionIDValue",
        ExpressionAttributeNames: {
            "#TransactionID": "TransactionID"
        },
        ExpressionAttributeValues: {
            ":TransactionIDValue": transactionID
        }
    };

    return dynamoDBClient.query(dynamoDBClientParams).promise();
}

exports.getCacheFromDynamoDB = function (cacheKey, awsConfigurations) {
    var items;
    aws.config.update({
        region: awsConfigurations.region
    });

    var dynamoDBClient = new aws.DynamoDB.DocumentClient();

    var dynamoDBClientParams = {
        TableName: awsConfigurations.dynamoCacheTableName,
        KeyConditionExpression: "#CacheKey = :CacheKeyValue",
        ExpressionAttributeNames: {
            "#CacheKey": "CacheKey"
        },
        ExpressionAttributeValues: {
            ":CacheKeyValue": cacheKey
        }
    };


    return dynamoDBClient.query(dynamoDBClientParams).promise();

}

exports.checkAsyncDynamoDBTableExist = function (tableName, awsConfigurations) {

    var dynamodb = new aws.DynamoDB();

    aws.config.update({
        region: awsConfigurations.region
    });

    var params = {
        TableName: tableName /* required */
    };

    return dynamodb.describeTable(params).promise();

}

exports.checkDynamoDBTableExist = function (tableName) {

    var status = false;
    var dynamodb = new aws.DynamoDB();

    aws.config.update({
        region: awsConfigurations.region
    });

    var params = {
        TableName: tableName /* required */
    };

    dynamodb.describeTable(params, function (err, data) {
        if (err) {
            status = "false";
            console.log(err, err.stack); // an error occurred
        }
        else {
            status = ("true");
            console.log(data); // successful response
        }

    });

    return status;

}

function removeEmptyStringElements(obj) {
    for (var prop in obj) {
        if (typeof obj[prop] === 'object') {// dive deeper in
            removeEmptyStringElements(obj[prop]);
        } else if (obj[prop] === '') {// delete elements that are empty strings
            delete obj[prop];
        }
    }
    return obj;
}


exports.putS3ObjectTagging = function (s3Url, awsConfigurations, tagKey, tagValue){
    aws.config.setPromisesDependency(null);
    aws.config.update({
        region: awsConfigurations.region
    });

    var s3Client = new aws.S3({
        "signatureVersion": "v4"
    });

    var params = {
        Bucket: awsConfigurations.bucketName,
        Key: s3Url,
        Tagging: {
            TagSet: [
               {
              Key: tagKey, 
              Value: tagValue
             }
            ]
           }
    };

    return s3Client.putObjectTagging(params).promise();
}

exports.uploadFiletoS3WithTagging = function (contents, fileName, contentType, awsConfigurations, tagging, cacheDays) {
    aws.config.setPromisesDependency(null);
    aws.config.update({
        region: awsConfigurations.region
    });

    var s3Client = new aws.S3({
        "signatureVersion": "v4"
    });

    var tags = "";
    tagging.forEach(tag => {
        tags += `${tag.Key}=${tag.Value}&`;
    });


    var params = {
        Bucket: awsConfigurations.bucketName,
        Key: fileName,
        Body: contents,
        ContentType: contentType,
        Tagging: tags.trimEnd('&')
    };

    if(cacheDays){
        params.Expires = moment.utc().add(cacheDays, 'day').toISOString()
    }

    if(awsConfigurations.kmsKeyID){
        params["SSEKMSKeyId"] = awsConfigurations.kmsKeyID;
        params["ServerSideEncryption"] = "aws:kms"
    }

    return s3Client.putObject(params).promise();
}

exports.updateDataInDynamoDBWithRedaction = function (transactionID, awsConfigurations, fieldName, redactedKey) {

    aws.config.update({
        region: awsConfigurations.region
    });

    var dynamoDBClient = new aws.DynamoDB();

    var dynamoDBClientParams = {
        TableName: awsConfigurations.dynamoTransactionTableName,
        Key: {
            "TransactionID":{
                S: transactionID
            }
        },
        ExpressionAttributeNames: {
            "#R": fieldName
        },
        ExpressionAttributeValues:{
            ":rsk": {
                S: redactedKey
            }
        },
        UpdateExpression: "SET #R = :rsk"
    };

    dynamoDBClient.updateItem(dynamoDBClientParams, function (err, data) {
        if (err) {
            console.log("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
        }
    });

}

exports.deleteObjectFromS3 = function (s3Key, versionID, awsConfigurations){
    aws.config.setPromisesDependency(null);
    aws.config.update({
        region: awsConfigurations.region
    });

    var s3Client = new aws.S3({
        "signatureVersion": "v4"
    });

    var params = {
        Bucket: awsConfigurations.bucketName,
        Key: s3Key,
        VersionId: versionID
    };

    return s3Client.deleteObject(params).promise();
}
exports.fieldValue = (obj, key) =>
{
    return key.split(".").reduce(function(o, x) {
        return (typeof o == "undefined" || o === null) ? o : o[x];
    }, obj);
}

exports.fieldValue = (obj, key, returnDefaultValue) =>
{
    return key.split(".").reduce(function(o, x) {
        return (typeof o == "undefined" || o === null) ? returnDefaultValue : o[x];
    }, obj);
}

exports.fieldHasValue = (obj, key) =>
{
    return key.split(".").every(function(x) {
        if(typeof obj != "object" || obj === null || ! x in obj)
            return false;
        obj = obj[x];
        return true;
    });
}

var xml2js = require('xml2js');
var options = {
    valueProcessors: [xml2js.processors.parseNumbers]
}
var parser = new xml2js.Parser({ explicitArray: false, mergeAttrs: true, valueProcessors: [xml2js.processors.parseNumbers] });

exports.XMLtoJson = (state) => {
    var startTime = new Date();
    var errMessage;
    state._tag = "XmltoJsonConversion"

    state._traceLog._className = "jsonConverterAssistant.js";
    state._traceLog._function = "exports.XMLtoJson";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;

    parser.parseString(state.context, function (err, result) {
        if (err != null) {
            state._traceLog._type = "Error";
            errMessage = err.message;
            state._traceLog._msg = errMessage;
        }
        else {
            state.responseContext = result;
        }
    });

    var endTime = new Date();
    state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();
    state._traceLog._tags.push("jsonConverterAssistant.exports.XMLtoJson DocumentType: " + state._documentType + "execution time.");

    return errMessage;
}

exports.JsontoXML = (state, root) => {
    var startTime = new Date();
    var errMessage;
    state._tag = "JsontoXML"

    state._traceLog._className = "jsonConverterAssistant.js";
    state._traceLog._function = "exports.JsontoXML";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;

    try {
        var opts = {};

        if (root) {
            opts.rootName = root;
        }

        var builder = new xml2js.Builder(opts);
        var result = builder.buildObject(state.context);
        state.responseContext = result;
        var endTime = new Date();
        state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();
        state._traceLog._tags.push("jsonConverterAssistant.exports.JsontoXML DocumentType: " + state._documentType + "execution time.");
    }
    catch (err) {
        state._traceLog._type = "Error";
        state._traceLog._msg = err.message;
        errMSG = err.message;
    }

    var endTime = new Date();
    state._traceLog._elapsedms = endTime.getTime() - startTime.getTime();

    return errMessage;
}
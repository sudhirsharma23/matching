exports.logHelper = logTrace;
exports.logSteps = logSteps;

function logTrace(state) {
    var endTime = new Date();

    if (!state._traceLog._ts)
        state._traceLog._ts = new Date();

    state._traceLog._elapsedms = endTime.getTime() - new Date(state._traceLog._ts).getTime();
    state._traceLog._ts = new Date(state._traceLog._ts).toUTCString();

    if (state.awsConfiguration.logLevel === 'verbose')
        console.log(JSON.stringify(state));
    else
        console.log(JSON.stringify(state._traceLog));
}

function logSteps(state) {
    if (state._traceLog.enabled === true || state.awsConfiguration.logLevel === 'verbose')
        logTrace(state);

    return this(state);
}
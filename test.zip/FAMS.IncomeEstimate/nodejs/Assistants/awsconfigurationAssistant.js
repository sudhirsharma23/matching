exports.getAWSConfiguration = () => {

    var awsConfiguration = {
        region: process.env.AWS_REGION,
        logLevel: process.env.LOG_LEVEL,
        bucketName: process.env.S3_BUCKET,
        dynamoTransactionTableName: process.env.DYNAMODB_TRANSACTION_TABLE,
        dynamoCacheTableName: process.env.DYNAMODB_CACHE_TABLE,
        environment: process.env.ENVIRONMENT,
        kmsKeyID: process.env.KMS_KEY_ID,
        prefixKey: "S3Prefix",
        prefixttlSecs: 2592000,
        configrationFolder: "VendorConfigurations",
        serviceRequestFolder: "ServiceRequests",
        serviceResponseFolder: "ServiceResponses",
        vendorRequestFolder: "VendorRequests",
        vendorResponseFolder: "VendorResponses",
        mockResponseFolder: "MockResponses",
        redactedServiceRequestFolder: "RedactedServiceRequests"
    }
    return awsConfiguration;
}
const NodeCache = require( "node-cache" );
const myCache = new NodeCache();

exports.getRandomPrefix = (keyName,expiration,characterLength) =>
{
    
    var randomString = myCache.get(keyName );
    if ( randomString == null ){
         randomString =  generateRandomString(characterLength);
         success = myCache.set( keyName, randomString, expiration );
        }

     return randomString;
   
}

function generateRandomString(characterLength)
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  
    for (var i = 0; i < characterLength; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));
  
    return text;
}
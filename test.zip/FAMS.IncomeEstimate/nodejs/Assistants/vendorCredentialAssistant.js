var secretsAssistant = require('./secretsManagerAssistant.js');

exports.getVendorCredential = (state) => {
    state._traceLog._ts = new Date();
    state._traceLog._tags = [];
    state._traceLog._tags.push("Get Vendor Get Vendor Credential From Persona And Secret Manager");
    state._traceLog._className = "vendorCredentialAssistant.js";
    state._traceLog._function = "exports.getVendorCredential";
    state._traceLog._type = "Information";
    state._traceLog.transactionid = state._transactionID;
    state._traceLog.enabled = true;


    return new Promise((resolve, reject) => {
        let configOverride = state.persona.configoverride;
        let credsID = state.persona.credsid;
        let headers = state.context.params.header;

        if(configOverride != null && configOverride.toLowerCase() == "true"){

            if(!(headers.login === "") && !(headers.password === "")){
                state.vnd_Details.username = headers.login;
                state.vnd_Details.password = headers.password;
                resolve(state);
            }
            else if(credsID === ""){
                let error = "Failed to get Vendor Credential. Login and Password or CredsID must exist when configoverride is set to true";
                state._traceLog._type = "Error";
                state._traceLog._msg = error;
                reject(error)
            }
        }

        if(state.vnd_Details.username == "" || state.vnd_Details.password == ""){
            secretsAssistant.getVendorCredentialFromSecretsManager(state)
            .then(secretValue => {
                json = JSON.parse(secretValue);
                state.vnd_Details.username = json.Login;
                state.vnd_Details.password = json.Password;
                resolve(state);
            })
            .catch(err => {
                let error = `Fail to get Vendor Credential. ${err}`;
                state._traceLog._type = "Error";
                state._traceLog._msg = error;
                reject(error);
            });
        }
    });
};
﻿using Amazon.Lambda.TestUtilities;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using FAMS.CryptoService.core;
using FAMS.CryptoService.v1;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using Xunit;

namespace FAMS.CryptoService.Tests
{
    public class APITest
    {
        AWSCredentials credentials;
        IAmazonS3 s3Client;
        private string POST_VERB = "order";
        private string GET_VERB = "report";
        //private string MOCK_VERB = "mock";
        private string VERSION = "v1";
        private string lambda_generated_name = "sbx-crypto-api-w2-humane-sponge-crypto-lambda";
// private string dynamo_generated_name = "sbx-mers-api-w2-unified-stingray-mers-transactions";
        private string s3_generated_name = "sbx-crypto-api-w2-humane-sponge";

        public APITest()
        {
            credentials = GetAWSCredentialsFromProfile("sbx");
            s3Client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USWest2);
           // dbClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.USWest2);

            //Environment.SetEnvironmentVariable("DYNAMODB_TABLE", aws_generated_name + "-transactions");
            //Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:666678657097:key/bdc09bb0-aa26-4fde-a7f3-38f2b9b6c982");

            Environment.SetEnvironmentVariable("S3_BUCKET", s3_generated_name);
           // Environment.SetEnvironmentVariable("DYNAMODB_TABLE", dynamo_generated_name);
            Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:666678657097:key/9b084b46-36ac-419f-9f0d-235246f82f03");
            Environment.SetEnvironmentVariable("LOG_JODI", "true");
            Environment.SetEnvironmentVariable("SERVICE_ZONE_NAME", "crypto");
            Environment.SetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE", "false");
            Environment.SetEnvironmentVariable("ENVIRONMENT", "prod");
        }

        #region "Crypto"
        [Fact]
        [Trait("Vendor", "")]
        public async void POST_CryptoData_Encrypt()
        { 
       
            string fileName = "Crypto_Encrypt.txt";

            var requestStream = BuildJodiRequest("FAMS.CryptoService.Tests.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/encrypt", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME")), null, "LEGACY-RAPID");

            // Invoke the lambda function
            var api = new API(s3Client);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);

            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The POST search call was not successful.");
        }

        [Fact]
        [Trait("Vendor", "")]
        public async void POST_CryptoData_Decrypt()
        {
            string fileName = "Crypto_Decrypt.txt";

            var requestStream = BuildJodiRequest("FAMS.CryptoService.Tests.SampleRequests", fileName, "POST", string.Format("/{0}/{1}/decrypt", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME")), null, "LAG","Decrypt");

            // Invoke the lambda function
            var api = new API(s3Client);
            var context = new TestLambdaContext();
            context.FunctionName = lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The POST search call was not successful.");
        }

        [Fact]
        [Trait("Vendor", "")]
        public async void GET_CryptoData_generatekey()
        {
            
            var requestStream = BuildJodiRequest("", "", "GET", string.Format("/{0}/{1}/{2}/generatesymmetrickey", VERSION, Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"), GET_VERB), null,null,null, "AESManaged");

            // Invoke the lambda function
            var api = new API(s3Client);
            var context = new TestLambdaContext();
            context.FunctionName = "GET " + lambda_generated_name;
            var routingResponse = await api.RouteHandler(requestStream, context);

            var desResponse = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);
            Assert.True(desResponse != null && desResponse.HttpStatus == 200, "The POST search call was not successful.");
        }

        #endregion

        #region Helpers

        private AWSCredentials GetAWSCredentialsFromProfile(string profile)
        {
            var credentialProfileStoreChain = new CredentialProfileStoreChain();

            if (credentialProfileStoreChain.TryGetAWSCredentials(profile, out AWSCredentials credentials))
                return credentials;
            else
                throw new AmazonClientException("Unable to find a " + profile + " profile in CredentialProfileStoreChain.");
        }

        private string ReadFileToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();

            resource.CopyTo(ms);

            return Encoding.ASCII.GetString(ms.ToArray());
        }

        private string ConvertServiceRequestToBase64(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);

            return Convert.ToBase64String(ms.ToArray());
        }

        private string ConvertServiceRequestToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);
            string resp = string.Empty;
            //StreamReader sr = null;

            using (Stream resource = assembly.GetManifestResourceStream(file))
            {
                using (var reader = new StreamReader(resource))
                {
                    resp = reader.ReadToEnd();
                }
            }

            return resp;
        }

        private string GetContentTypeFromFile(string extension)
        {
            if (extension.Equals(".json"))
                return "application/json";
            else if (extension.Equals(".xml"))
                return "text/xml";
            else
                return string.Empty;
        }

        public Stream BuildJodiRequest(string filePath, string fileName, string method, string servicePath, string transactionID,string configcode=null, string methodType=null, string algorithmType=null)
        {
            transactionID = (string.IsNullOrEmpty(transactionID)) ? Guid.NewGuid().ToString() : transactionID;
            string base64body = string.Empty;
            if (!string.IsNullOrEmpty(filePath) && !string.IsNullOrEmpty(fileName))
            {
                string json = ConvertServiceRequestToString(filePath, fileName);
                var plainTextBytes = Encoding.UTF8.GetBytes(json);
                base64body = Convert.ToBase64String(plainTextBytes);
                if (methodType == "Decrypt")
                {
                    base64body = json;
                }
            }
            JODIRequest jr = new JODIRequest
            {
                Lambda = lambda_generated_name,
                Body = (string.IsNullOrEmpty(filePath) || string.IsNullOrEmpty(fileName)) ? string.Empty : base64body,
                BodyType = (string.IsNullOrEmpty(fileName)) ? string.Empty : GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", method},
                    { "orig-path", servicePath},
                    { "request-id", transactionID }
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        { "accept", "application/octet-stream" },
                        { "content-type", "application/octet-stream" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        { "clientID", "DEVTEST" },
                        { "portalCode", "API" },
                        { "globalID", "FAMSTESTCO" }
                    }
                }
            };
            jr.Params.QueryString = new SerializableDictionary<string, string>();
            if (!string.IsNullOrEmpty(transactionID))
            {
                jr.Params.QueryString.Add("transactionID", transactionID);
                
            }
            if (!string.IsNullOrEmpty(configcode))
            {
                jr.Params.QueryString.Add("configcode", configcode);
            }
            if (!string.IsNullOrEmpty(algorithmType))
            {
                jr.Params.QueryString.Add("algorithmtype", algorithmType);
            }

            MemoryStream requestStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, requestStream);

            return requestStream;
        }

        #endregion
    }
    
}

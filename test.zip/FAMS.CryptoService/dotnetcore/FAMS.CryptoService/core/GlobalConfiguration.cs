﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.CryptoService.core
{
    public static class GlobalConfiguration
    {
        public static readonly string KMS_KEY_ID = Environment.GetEnvironmentVariable("KMS_KEY_ID");
        public static readonly string environment = Environment.GetEnvironmentVariable("ENVIRONMENT");
        public static readonly string SERVICE_ZONE_NAME = Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME");
        public static readonly string KEEP_WARM_CLOUDWATCH_EVENT_RULE = Environment.GetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE");
        public static readonly string S3_BUCKET = Environment.GetEnvironmentVariable("S3_BUCKET");
        public const string CRYPTO_FOLDER = "Crypto";

        public static readonly string ENCRYPTION_CONFIG_FOLDER = string.Format("{0}/EncryptionConfigurations", SERVICE_ZONE_NAME);

        public static bool LOG_JODI;
        static GlobalConfiguration()
        {
            bool.TryParse(System.Environment.GetEnvironmentVariable("LOG_JODI"), out bool logJodi);
            LOG_JODI = logJodi;
        }
    }
}

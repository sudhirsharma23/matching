﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace FAMS.CryptoService.core
{
    public static class StreamAssistant
    {
        public const int DEFAULT_BUFFER_SIZE = 32768;

        /// <summary>
        /// Copies a stream to another stream.
        /// </summary>
        /// <param name="copyFrom">Stream to copy from.</param>
        /// <param name="copyTo">Stream to copy to.</param>
        public static void Copy(Stream copyFrom, Stream copyTo)
        {
            Copy(copyFrom, copyTo, StreamCopyOptions.None);
        }

        /// <summary>
        /// Copies a stream to a new stream.
        /// </summary>
        /// <param name="copyFrom">Stream to copy from.</param>
        /// <returns>A new stream containing the contents of <paramref name="copyFrom"/>.</returns>
        public static Stream Copy(Stream copyFrom)
        {
            MemoryStream returnValue = new MemoryStream();
            StreamAssistant.Copy(copyFrom, returnValue);
            returnValue.Seek(0, SeekOrigin.Begin);
            return returnValue;
        }

        /// <summary>
        /// Options for stream copying operations.
        /// </summary>
        [Flags]
        public enum StreamCopyOptions
        {
            /// <summary>
            /// Do not close either stream.
            /// </summary>
            None = 0,

            /// <summary>
            /// Close the input stream when finished.
            /// </summary>
            CloseReadStream = 1,

            /// <summary>
            /// Close the output stream when finished.
            /// </summary>
            CloseWriteStream = 2
        };

        /// <summary>
        /// Copies a stream to another stream.
        /// </summary>
        /// <param name="copyFrom">Stream to copy from.</param>
        /// <param name="copyTo">Stream to copy to.</param>
        /// <param name="copyOptions">
        /// Any combination of <see cref="StreamCopyOptions"/> values, indicating whether the streams
        /// should be closed when finished.
        /// </param>
        public static void Copy(Stream copyFrom, Stream copyTo, StreamCopyOptions copyOptions)
        {
            Copy(copyFrom, copyTo, copyOptions, null);
        }

        /// <summary>
        /// Copies a stream to another stream, allowing for the data to be examined during the copy.
        /// </summary>
        /// <remarks>
        /// Bytes are copied from <paramref name="copyFrom"/> to <paramref name="copyTo"/> in
        /// multiple blocks of bytes.  After copying a block of bytes, the bytes are passed to
        /// the <paramref name="callback"/> action, allowing the client to examine the contents.
        /// </remarks>
        /// <param name="copyFrom">Stream to copy from.</param>
        /// <param name="copyTo">Stream to copy to.</param>
        /// <param name="copyOptions">
        /// Any combination of <see cref="StreamCopyOptions"/> values, indicating whether the streams
        /// should be closed when finished.
        /// </param>
        /// <param name="callback">Callback action.</param>
        public static void Copy(Stream copyFrom, Stream copyTo, StreamCopyOptions copyOptions, Action<byte[]> callback)
        {
            if (copyFrom == null)
                throw new ArgumentNullException("copyFrom");

            if (copyTo == null)
                throw new ArgumentNullException("copyTo");

            try
            {
                if (copyFrom.CanSeek)
                    copyFrom.Seek(0, SeekOrigin.Begin);

                if (copyTo.CanSeek)
                    copyTo.Seek(0, SeekOrigin.Begin);

                int bytesLength = DEFAULT_BUFFER_SIZE;
                byte[] buffer = new byte[bytesLength];

                int bytesRead = copyFrom.Read(buffer, 0, bytesLength);

                while (bytesRead > 0)
                {
                    copyTo.Write(buffer, 0, bytesRead);

                    if (callback != null)
                    {
                        byte[] data = new byte[bytesRead];
                        Array.Copy(buffer, data, bytesRead);
                        callback(data);
                    }

                    bytesRead = copyFrom.Read(buffer, 0, bytesLength);
                }
            }
            finally
            {
                if (StreamCopyOptions.CloseReadStream == (copyOptions & StreamCopyOptions.CloseReadStream))
                    copyFrom.Close();

                if (StreamCopyOptions.CloseWriteStream == (copyOptions & StreamCopyOptions.CloseWriteStream))
                    copyTo.Close();
            }
        }

        /// <summary>
        /// Determines if the content of one stream is equal to content of another stream.
        /// </summary>
        /// <param name="stream1">Stream.</param>
        /// <param name="stream2">Other stream.</param>
        /// <returns>True if content of <paramref name="stream1"/> is equal to content of 
        /// <paramref name="stream2"/>; otherwise, false.</returns>
        public static bool AreEqual(Stream stream1, Stream stream2)
        {
            int bufferSize = DEFAULT_BUFFER_SIZE;
            byte[] buffer1 = new byte[bufferSize];
            byte[] buffer2 = new byte[bufferSize];
            stream1.Seek(0, SeekOrigin.Begin);
            stream2.Seek(0, SeekOrigin.Begin);
            int bytes1 = stream1.Read(buffer1, 0, bufferSize);
            int bytes2 = stream2.Read(buffer2, 0, bufferSize);
            while (bytes1 > 0 && bytes2 > 0)
            {
                if (!buffer1.Take<byte>(bytes1).SequenceEqual<byte>(buffer2.Take<byte>(bytes2)))
                {
                    return false;
                }
                bytes1 = stream1.Read(buffer1, 0, bufferSize);
                bytes2 = stream2.Read(buffer2, 0, bufferSize);
            }
            return true;
        }

        /// <summary>
        /// Converts passed <paramref name="copyFrom"/> to a string.
        /// </summary>
        /// <remarks>
        /// <paramref name="copyFrom"/> must be either a <see cref="MemoryStream"/> or a
        /// <see cref="FileStream"/>. Any other streams will throw an exception.
        /// </remarks>
        /// <param name="copyFrom">Stream to convert.</param>
        /// <returns>The stream content in a string.</returns>
        public static string StreamToString(Stream readStream)
        {
            return StreamToString(readStream, new ASCIIEncoding());
        }

        /// <summary>
        /// Converts passed <paramref name="readStream"/> to a string.
        /// </summary>
        /// <param name="readStream">Stream to convert.</param>
        /// <param name="textEncoding">Encoding to apply.</param>
        /// <returns>The stream content in a string.</returns>
        public static string StreamToString(Stream readStream, Encoding textEncoding)
        {
            if (readStream == Stream.Null)
            {
                return String.Empty;
            }

            if (readStream.CanSeek)
            {
                readStream.Seek(0, SeekOrigin.Begin);
            }

            StreamReader streamReader = new StreamReader(readStream, textEncoding);
            return streamReader.ReadToEnd();
        }

        /// <summary>
        /// Converts string <paramref name="content"/> to a <see cref="Stream"/>.
        /// </summary>
        /// <param name="content">String to convert.</param>
        /// <returns>A stream containing the string content.</returns>
        public static Stream StreamFromString(string content)
        {
            return StreamFromString(content, new ASCIIEncoding());
        }

        /// <summary>
        /// Converts string <paramref name="content"/> to a <see cref="Stream"/>.
        /// </summary>
        /// <param name="content">String to convert.</param>
        /// <param name="encoding">Encoding to apply.</param>
        /// <returns>A stream containing the string content.</returns>
        public static Stream StreamFromString(string content, Encoding encoding)
        {
            MemoryStream memoryStream = new MemoryStream();

            if (String.IsNullOrEmpty(content))
            {
                return memoryStream;
            }

            StreamWriter streamWriter = new StreamWriter(memoryStream, encoding);
            streamWriter.Write(content);
            streamWriter.Flush();
            memoryStream.Seek(0, SeekOrigin.Begin);
            return memoryStream;
        }

        /// <summary>
        /// Converts a <c>byte[]</c> to a <see cref="Stream"/>.
        /// </summary>
        /// <param name="content">Content to convert to a stream.</param>
        /// <returns>A stream containing the bytes in <paramref name="content"/>.</returns>
        public static Stream StreamFromByteArray(byte[] content)
        {
            MemoryStream ms = new MemoryStream(content);
            ms.Seek(0, SeekOrigin.Begin);

            return ms;
        }


        public static Stream DictionaryToStream(Dictionary<string, string> dictionary)
        {
            MemoryStream stream = new MemoryStream();
            BinaryWriter writer = new BinaryWriter(stream);
            writer.Write(dictionary.Count);
            foreach (var kvp in dictionary)
            {
                writer.Write(kvp.Key);
                writer.Write(kvp.Value);
            }
            writer.Flush();
            stream.Seek(0, SeekOrigin.Begin);
            return stream;
        }

        public static Dictionary<string, string> StreamToDictionary(Stream stream)
        {
            BinaryReader reader = new BinaryReader(stream);
            int count = reader.ReadInt32();
            var dictionary = new Dictionary<string, string>(count);
            for (int n = 0; n < count; n++)
            {
                var key = reader.ReadString();
                var value = reader.ReadString();
                dictionary.Add(key, value);
            }
            return dictionary;
        }

        public static byte[] StreamToByte(Stream input)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                input.CopyTo(ms);
                return ms.ToArray();
            }
        }
    }
}

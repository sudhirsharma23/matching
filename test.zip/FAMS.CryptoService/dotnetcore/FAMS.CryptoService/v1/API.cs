﻿using Amazon.Lambda.Core;
using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.CryptoService.core;
using FAMS.CryptoService.v1.Models.Service;
using FAMS.CryptoService.v1.UseCases;
using FAMS.CryptoService.v1.UseCases.Service;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace FAMS.CryptoService.v1
{
    public class API
    {

        #region "Constructors"


        static List<Method> MethodLookup;
        static object MethodLock = new object();


        const string API_VERSION = "v1";
        CryptoUseCase UseCase;
        IAmazonS3 S3Client;
        public API()
        {
            UseCase = new CryptoUseCase();
            InitializeMethodLookup();
        }

        // Used for testing purposes.
        public API(IAmazonS3 s3Client)
        {
            UseCase = new CryptoUseCase(s3Client);
            S3Client = s3Client;
            InitializeMethodLookup();
        }
        #endregion

        #region Properties"


        private static object _dictLocker = new object();

        static Dictionary<int, string> _dictEncryptionConfigCodes = null;
        private Dictionary<int, string> dictEncryptionConfigCodes
        {
            get
            {
                if (_dictEncryptionConfigCodes == null)
                {
                    lock (_dictLocker)
                    {
                        if (_dictEncryptionConfigCodes == null)
                        {
                            _dictEncryptionConfigCodes = new Dictionary<int, string>();
                            _dictEncryptionConfigCodes.Add(1, "LEGACY");
                            _dictEncryptionConfigCodes.Add(2, "LEGACY-DOTNET");
                            _dictEncryptionConfigCodes.Add(3, "LEGACY-RAPID");
                            _dictEncryptionConfigCodes.Add(4, "LEGACY-SECONDARY");
                            _dictEncryptionConfigCodes.Add(5, "LEGACY-DISSCO");
                        }
                    }
                }
                return _dictEncryptionConfigCodes;
            }

        }


        #endregion

        #region Function Handlers
        /// <summary>
        /// Routing handler for the lambda functions.  This is the one method that the lambda will call directly, then based on HTTP Method and URI, this method will invoke the correct function to call.
        /// </summary>
        /// <param name="jodiRequest">Stream of JODIRequest. Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>Stream of JODI response.  The service response is b64 encoded in the body </returns>
        public async Task<Stream> RouteHandler(Stream jodiRequestStream, ILambdaContext context)
        {
            UseCase.LambdaName = context.FunctionName;
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string httpMethod = string.Empty;
            string uri = string.Empty;
            string requestID = string.Empty;

            JODIRequest request = null;
            JODIResponse response = null;
            MemoryStream responseStream = new MemoryStream();


            try
            {
                request = SerializationAssistant.DeserializeJson<JODIRequest>(jodiRequestStream);

                if (request == null)
                    throw new Exception("Unable to deserialize to JODIRequest object.");

                UseCase.Persona = request.Params.Persona;
                request.Context?.TryGetValue("http-method", out httpMethod);
                request.Context?.TryGetValue("orig-path", out uri);
                request?.Context?.TryGetValue("request-id", out requestID);

                Method method = JODIAssistant.FindMethod(MethodLookup, request);

                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},Supported Methods=GET,POST",
                                              uri,
                                              string.Join(",", MethodLookup.Select(a => a.Path)),
                                              httpMethod);
                    throw new Exception(errorMsg);
                }

                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                responseStream.Position = 0;

                return responseStream;
            }
            catch (Exception ex)
            {
                UseCase.Logger.LogServiceError(ex, string.Format("Failure in the RouteHandler. JODIRequest={0}", JODIAssistant.StreamToJson(jodiRequestStream)),
                                                              FunctionTimer.ElapsedMilliseconds);
                response = CreateErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError);
                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                return responseStream;
            }
            finally
            {
                FunctionTimer.Stop();

                //dont want to log to CW for keep warm request

                if (GlobalConfiguration.LOG_JODI)
                {
                    UseCase.Logger.LogJsonObject(request);
                    UseCase.Logger.LogJsonObject(response);
                    UseCase.Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                }
            }
        }


        private async Task<JODIResponse> PostEncryptHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            JODIResponse jodiResponse = null;
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();


            string configcode = string.Empty;
            string transactionID = string.Empty;
            TransactionRecord<VendorCall> cryptoTrans = new TransactionRecord<VendorCall>();

            jodiRequest?.Params?.QueryString?.TryGetValue("configcode", out configcode);

            if (string.IsNullOrEmpty(configcode))
            {
                throw new Exception(string.Format("Configcode is Empty"));
            }
            try
            {
                if (jodiRequest?.Params?.QueryString != null && jodiRequest?.Params?.QueryString.Count > 0)
                    foreach (var queryString in jodiRequest?.Params?.QueryString)
                    {
                        if (queryString.Key.Equals("transactionid", StringComparison.OrdinalIgnoreCase))
                            transactionID = queryString.Value;
                    }
                else
                {
                    jodiRequest?.Context?.TryGetValue("request-id", out transactionID);
                }

                cryptoTrans.TransactionID = transactionID;

                Stream inputStream = StreamAssistant.StreamFromByteArray(Convert.FromBase64String(jodiRequest.Body));

                Dictionary<string, EncryptionConfig> cryptoconfig = UseCase.GetVendorConfiguration();
                EncryptionConfig configEntity = UseCase.GetEncryptionConfigInfo(configcode, cryptoconfig.Values.ToList<EncryptionConfig>());
                if (configEntity == null)
                {
                    throw new Exception(string.Format("Entity Does not Exist for Config Code"));
                }
                string providername = configEntity.AlgorithmProvider;

                if (string.IsNullOrEmpty(providername))
                {
                    throw new Exception(string.Format("Provider Does not Exist for Config Code"));
                }

                Stream outputStream = Stream.Null;
                AlgorithmProvider AlgorithmProvider = new AlgorithmProvider();
                AlgorithmProvider.algorithmType = configEntity.AlgorithmType;
                AlgorithmProvider.encryptionKey = configEntity.EncryptionKey;
                AlgorithmProvider.encryptionSalt = configEntity.EncryptionSalt;
                AlgorithmProvider.encryptionAlgorithmIndicator = Convert.ToInt32(configEntity.EncryptionIndicatorCode);
                AlgorithmProvider.isLegacy = UseCase.isLegacy(configEntity, configcode);

                AlgorithmUseCase algorithmUseCase = AlgorithmUseCaseFactory.CreateAlgorithmUseCase(providername, AlgorithmProvider);

                if (inputStream.CanSeek)
                {
                    inputStream.Seek(0, SeekOrigin.Begin);
                }

                using (MemoryStream plainStream = (MemoryStream)StreamAssistant.Copy(inputStream))
                {
                    outputStream = algorithmUseCase.Encrypt(plainStream);
                    plainStream.Seek(0, SeekOrigin.Begin);
                    outputStream.Seek(0, SeekOrigin.Begin);
                }

                jodiResponse = new JODIResponse()
                {
                    ContentType = "application/octet-stream",
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = Convert.ToBase64String(StreamAssistant.StreamToByte(outputStream))
            };

            }
            catch (Exception ex)
            {
                UseCase.Logger.LogServiceError(ex, "Failure in the PostEncryptHandler", FunctionTimer.ElapsedMilliseconds);
                jodiResponse = CreateErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError);

            }
            finally
            {
                FunctionTimer.Stop();

            }

            return jodiResponse;
        }

        private async Task<JODIResponse> PostDecryptHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            JODIResponse jodiResponse = null;
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();


            string configcode = string.Empty;
            string transactionID = string.Empty;
            TransactionRecord<VendorCall> cryptoTrans = new TransactionRecord<VendorCall>();

            jodiRequest?.Params?.QueryString?.TryGetValue("configcode", out configcode);
            if (string.IsNullOrEmpty(configcode))
            {
                throw new Exception(string.Format("Configcode is Empty"));
            }

            try
            {
                if (jodiRequest?.Params?.QueryString != null && jodiRequest?.Params?.QueryString.Count > 0)
                    foreach (var queryString in jodiRequest?.Params?.QueryString)
                    {
                        if (queryString.Key.Equals("transactionid", StringComparison.OrdinalIgnoreCase))
                            transactionID = queryString.Value;
                    }
                else
                {
                    jodiRequest?.Context?.TryGetValue("request-id", out transactionID);
                }

                //Get Persona Info

                cryptoTrans.TransactionID = transactionID;

               Stream inputStream = StreamAssistant.StreamFromByteArray(Convert.FromBase64String(jodiRequest.Body));
             
                Dictionary<string, EncryptionConfig> cryptoconfig = UseCase.GetVendorConfiguration();
                List<EncryptionConfig> configs = cryptoconfig.Values.ToList<EncryptionConfig>();
                long indicator = 0;
                EncryptionConfig configEntity = null;
                Stream outputStream = Stream.Null;

                using (MemoryStream cipherStream = new MemoryStream())
                {
                    StreamAssistant.Copy(inputStream, cipherStream);
                    indicator = UseCase.GetEncryptionIndicatorCode(cipherStream);
                    if (UseCase.IsValidIndicator(indicator, configs))
                    {
                        configEntity = UseCase.GetEncryptionConfigInfo(indicator, configs);

                        cipherStream.Seek(0, SeekOrigin.Begin);
                        // unwrap byte array before it can be decrypted

                        using (MemoryStream unwrappedcipherStream = (MemoryStream)CryptographyUtility.UnwrapCipherText(cipherStream))
                        {
                            if (unwrappedcipherStream.Length < 1)
                            {
                                outputStream = new MemoryStream();
                            }
                            else
                            {
                                outputStream = DecryptStream(unwrappedcipherStream, configEntity, configcode);
                            }
                        }
                    }
                    else
                    {
                        bool isError = true;
                        if (cipherStream.Length < 1)
                        {
                            outputStream = new MemoryStream();
                        }
                        else
                        {
                            if (isError)
                            {
                                foreach (var d in dictEncryptionConfigCodes)
                                {
                                    if (isError)
                                    {
                                        string pname = string.Empty;
                                        try
                                        {
                                            pname = d.Key == 3 ? d.Value : string.Format("{0}-{1}", configcode, d.Value);
                                            configEntity = UseCase.GetEncryptionConfigInfo(pname, configs);
                                            outputStream = DecryptStream(cipherStream, configEntity, configcode);
                                            isError = false;
                                        }
                                        catch (Exception ex)
                                        {
                                            if (GlobalConfiguration.LOG_JODI)
                                            {
                                                UseCase.Logger.LogServiceError(ex, String.Format("Failure in the decryption with configcode{0}", pname), FunctionTimer.ElapsedMilliseconds);
                                            }

                                        }
                                        finally { }
                                    }

                                }
                            }

                        }

                    }

                }
                if (outputStream.CanSeek)
                {
                    outputStream.Seek(0, SeekOrigin.Begin);
                }

                jodiResponse = new JODIResponse()
                {
                    ContentType = "application/octet-stream",
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = Convert.ToBase64String(StreamAssistant.StreamToByte(outputStream))
                };
            }
            catch (Exception ex)
            {
                UseCase.Logger.LogServiceError(ex, "Failure in the PostDecryptHandler", FunctionTimer.ElapsedMilliseconds);
                jodiResponse = CreateErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError);

            }
            finally
            {
                FunctionTimer.Stop();
            }

            return jodiResponse;
        }


        private async Task<JODIResponse> GetSymmetricKeyHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            JODIResponse jodiResponse = null;
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();


            string algorithmType = string.Empty;
            string transactionID = string.Empty;
            TransactionRecord<VendorCall> cryptoTrans = new TransactionRecord<VendorCall>();

            jodiRequest?.Params?.QueryString?.TryGetValue("algorithmtype", out algorithmType);

            if (String.IsNullOrEmpty(algorithmType))
            {
                throw new Exception("Algorithm Type is empty");
            }
            byte[] generatedKey = null;
            try
            {
                if (jodiRequest?.Params?.QueryString != null && jodiRequest?.Params?.QueryString.Count > 0)
                    foreach (var queryString in jodiRequest?.Params?.QueryString)
                    {
                        if (queryString.Key.Equals("transactionid", StringComparison.OrdinalIgnoreCase))
                            transactionID = queryString.Value;
                    }
                else
                {
                    jodiRequest?.Context?.TryGetValue("request-id", out transactionID);
                }

                //Get Persona Info

                cryptoTrans.TransactionID = transactionID;

                using (SymmetricAlgorithm algorithm = CryptographyUtility.CreateAlgorithm(algorithmType))
                {
                    if (algorithm == null)
                        throw new ArgumentException("algorithm is null.");

                    algorithm.KeySize = 256;
                    algorithm.GenerateKey();
                    generatedKey = algorithm.Key;
                }

                jodiResponse = new JODIResponse()
                {
                    ContentType = "application/octet-stream",
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = Convert.ToBase64String(generatedKey)
                };
            }
            catch (Exception ex)
            {
                UseCase.Logger.LogServiceError(ex, "Failure in the GetSymmetricKeyHandler", FunctionTimer.ElapsedMilliseconds);
                jodiResponse = CreateErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError);

            }
            finally
            {
                FunctionTimer.Stop();
                
            }

            return jodiResponse;
        }
        #endregion



        #region Private Methods
        private Stream DecryptStream(MemoryStream cipherStream, EncryptionConfig configEntity, string configcode = null)
        {
            Stream decryptStream = null;
            string providername = configEntity.AlgorithmProvider;
            AlgorithmProvider AlgorithmProvider = new AlgorithmProvider();
            AlgorithmProvider.algorithmType = configEntity.AlgorithmType;
            AlgorithmProvider.encryptionKey = configEntity.EncryptionKey;
            AlgorithmProvider.encryptionSalt = configEntity.EncryptionSalt;
            AlgorithmProvider.encryptionAlgorithmIndicator = Convert.ToInt32(configEntity.EncryptionIndicatorCode);
            AlgorithmProvider.isLegacy = UseCase.isLegacy(configEntity, configcode);

            AlgorithmUseCase algorithmUseCase = AlgorithmUseCaseFactory.CreateAlgorithmUseCase(providername, AlgorithmProvider);

            decryptStream = algorithmUseCase.Decrypt(cipherStream);
            return decryptStream;
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        MethodLookup = new List<Method>()
                        {

                        new Method()
                        {
                            InvokeFunction = PostEncryptHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/encrypt$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        },
                        new Method()
                        {
                            InvokeFunction = PostDecryptHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/decrypt$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        }
                        ,new Method()
                        {
                            InvokeFunction = GetSymmetricKeyHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/generatekey$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        }
                        };

                    }
                }
            }

        }

        private JODIResponse CreateErrorResponse(string errorMsg, int statusCode)
        {
            return new JODIResponse()
            {
                ErrorMessage = new JODIErrorResponse()
                {
                    Error = errorMsg,
                    HttpStatus = statusCode
                }
            };
        }
        #endregion

    }
}

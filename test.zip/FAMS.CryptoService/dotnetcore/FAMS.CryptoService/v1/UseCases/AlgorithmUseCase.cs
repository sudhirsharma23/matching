﻿
using FAMS.CryptoService.v1.Models.Service;
using System.IO;


namespace FAMS.CryptoService.v1.UseCases
{
    public abstract class AlgorithmUseCase
    {
        public abstract Stream Encrypt(Stream plaintext);
        public abstract Stream Decrypt(Stream ciphertext);
    }

    public static class AlgorithmUseCaseFactory
    {
        public static AlgorithmUseCase CreateAlgorithmUseCase(string AlgorithmProviderName, AlgorithmProvider AlgorithmProvider)
        {
            if(AlgorithmProviderName == "FrameworkSymmetricAlgorithmProvider")
            {
                return new FrameworkSymmetricAlgorithmProvider(AlgorithmProvider);
            }
            else if(AlgorithmProviderName == "RijndaelSymmetricAlgorithmProvider")
            {
                return new RijndaelSymmetricAlgorithmProvider(AlgorithmProvider);
            }
            
            return null;
        }
    }
}

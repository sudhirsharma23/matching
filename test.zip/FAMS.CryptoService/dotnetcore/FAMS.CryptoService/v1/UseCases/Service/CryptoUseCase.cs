﻿using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using FAMS.CryptoService.core;
using FAMS.CryptoService.v1.Models.Service;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace FAMS.CryptoService.v1.UseCases.Service
{
    public class CryptoUseCase
    {
        #region properties
        private IAmazonS3 _s3Client;

        private string _lambdaName;
        public string LambdaName
        {
            get
            {
                return this._lambdaName;
            }
            set
            {
                this._lambdaName = value;
            }
        }

        private string _projectName;
        public string ProjectName
        {
            get
            {
                return this._projectName;
            }
            set
            {
                this._projectName = value;
            }
        }
        private SerializableDictionary<string, string> _persona;
        public SerializableDictionary<string, string> Persona
        {
            get
            {
                return this._persona;
            }
            set
            {
                this._persona = value;
            }
        }

        private string _transactionID;
        public string TransactionID
        {
            get
            {
                return this._transactionID;
            }
            set
            {
                this._transactionID = value;
            }
        }

        public LoggingAssistant Logger { get; set; }
        #endregion

        public CryptoUseCase()
        {
            _s3Client = new AmazonS3Client();
            _projectName = typeof(CryptoUseCase).GetTypeInfo().Assembly.GetName().Name;
            Logger = new LoggingAssistant(LambdaName, ProjectName, TransactionID, Persona);
        }

        public CryptoUseCase(IAmazonS3 s3Client)
        {
            _s3Client = s3Client;
            _projectName = typeof(CryptoUseCase).GetTypeInfo().Assembly.GetName().Name;
            Logger = new LoggingAssistant(LambdaName, ProjectName, TransactionID, Persona);
        }

        #region " sync Methods"
        public string GetServiceRequestFromJODI(JODIRequest jodiRequest, Stopwatch functionTimer)
        {
            string decodedRequest = string.Empty;
            try
            {
                byte[] byteArray = Convert.FromBase64String(jodiRequest.Body);
                decodedRequest = Encoding.UTF8.GetString(byteArray);
            }
            catch (Exception ex)
            {
                string requestID = string.Empty;
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                Logger.LogServiceError(ex, string.Format("Failure to deserialize b64 body. Body={0}", jodiRequest.Body), functionTimer.ElapsedMilliseconds);

            }
            return decodedRequest;
        }

        public string GetDecryptServiceRequestFromJODI(JODIRequest jodiRequest, Stopwatch functionTimer)
        {
            string decodedRequest = string.Empty;
            try
            {
                byte[] byteArray = Convert.FromBase64String(jodiRequest.Body);
                decodedRequest = Convert.ToString(byteArray);
            }
            catch (Exception ex)
            {
                string requestID = string.Empty;
                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                Logger.LogServiceError(ex, string.Format("Failure to deserialize b64 body. Body={0}", jodiRequest.Body), functionTimer.ElapsedMilliseconds);

            }
            return decodedRequest;
        }


        public EncryptionConfig GetEncryptionConfigInfo(string encryptionConfigCode, List<EncryptionConfig> ConfigList, bool defaultconfig)
        {
            EncryptionConfig returnValue = null;
            if (defaultconfig)
            {
                returnValue= GetEncryptionConfigInfo( encryptionConfigCode, ConfigList);
            }
            else
            {
                var config = from ce in ConfigList
                             select ce;
                returnValue = config?.Where(c => c?.EncryptionConfigCode == encryptionConfigCode)?.FirstOrDefault();
            }
            return returnValue;

        }
        public EncryptionConfig GetEncryptionConfigInfo(string encryptionConfigCode, List<EncryptionConfig> ConfigList)
        {
            EncryptionConfig returnValue = null;

            var config = from ce in ConfigList
                         select ce;

            if (string.IsNullOrEmpty(encryptionConfigCode))
                config = config.Where(c => c.EncryptionDefaultAlgorithm == true);
            else
                config = config.Where(c => c.EncryptionConfigCode == encryptionConfigCode);

            foreach (var cfg in config)
            {
                if (cfg.EncryptionDefaultAlgorithm)
                {
                    returnValue = cfg as EncryptionConfig;
                    break;
                }
                returnValue = cfg as EncryptionConfig;
            }
            return returnValue;
        }

        public EncryptionConfig GetEncryptionConfigInfo(long indicatorCode, List<EncryptionConfig> ConfigList)
        {
            EncryptionConfig returnValue = null;

            var config = from ce in ConfigList
                         where ce.EncryptionIndicatorCode == indicatorCode
                         select ce;
            foreach (var cfg in config)
            {
                returnValue = cfg as EncryptionConfig;
                break;
            }
            return returnValue;
        }

        public long GetEncryptionIndicatorCode(Stream cipherStream)
        {
            long indicator = 0;
            byte[] cipherBytes = ((MemoryStream)cipherStream).ToArray();
            if (cipherBytes.Length >= 8)
            {
                using (MemoryStream ms = new MemoryStream(cipherBytes, 0, 8))
                {
                    indicator = BitConverter.ToInt64(ms.ToArray(), 0);
                }
            }
            return indicator;
        }

        public bool IsValidIndicator(long indicator, List<EncryptionConfig> ConfigList)
        {
            return EncryptionIndicatorCodeList(ConfigList).Contains(indicator);
        }


        private List<long> EncryptionIndicatorCodeList(List<EncryptionConfig> ConfigList)
        {

            List<long> _indicatorList = new List<long>();
            var distinctIndicatorList = ConfigList.Where(i => i.EncryptionIndicatorCode != 0).GroupBy(i => i.EncryptionIndicatorCode).Select(g => g.First());

            foreach (var indicator in distinctIndicatorList)
            {
                if (indicator.EncryptionIndicatorCode != null)
                    _indicatorList.Add(Convert.ToInt32(indicator.EncryptionIndicatorCode));
            }
            return _indicatorList;

        }

        public bool isLegacy(EncryptionConfig configEntity, string configCode)
        {
            bool isLegacy = true;
            if (string.IsNullOrEmpty(configCode) || configEntity.EncryptionIndicatorCode > 0)
            { isLegacy = false; }
            return isLegacy;
        }



        #endregion

        #region "Async Methods"
        public async Task<T> SearchS3ByKey<T>(string bucket, string key, string transactionID, bool log404Error = false, int? cacheLimit = null)
        {
            T document = default(T);

            try
            {
                document = await AWSAssistant.SearchS3ByKey<T>(_s3Client, bucket, key, log404Error, cacheLimit);
            }
            catch (AmazonS3Exception ex)
            {
                //Some cases 404 is OK like when we are just searching for a key
                if (log404Error || ex.StatusCode != HttpStatusCode.NotFound)
                {
                    Logger.LogS3Error(ex,
                                   "Failure searching S3",
                                   bucket,
                                   key);
                }
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex,
                            "Failure searching S3",
                            bucket,
                            key);
            }

            return document;
        }

        public Dictionary<string, EncryptionConfig> GetVendorConfiguration()
        {
                var environment = GlobalConfiguration.environment;

                var assembly = typeof(CryptoUseCase).GetTypeInfo().Assembly;

                string file = string.Format("FAMS.CryptoService.v1.Configs.Config.json");
                string resp = string.Empty;

                using (Stream resource = assembly.GetManifestResourceStream(file))
                {
                    using (var reader = new StreamReader(resource))
                    {
                        resp = reader.ReadToEnd();
                    }
                }

                var portalConfig = JObject.Parse(resp);

                var defaultConfig = portalConfig["default"].ToObject<List<EncryptionConfig>>();
                var envconfig = portalConfig[GlobalConfiguration.environment].ToObject<List<EncryptionConfig>>();

                var dict = defaultConfig.ToDictionary(p => p.EncryptionConfigCode);
                if (envconfig.Count > 0)
                {
                    foreach (var configcode in envconfig)
                    {
                        dict[configcode.EncryptionConfigCode] = configcode;
                    }
                }

                return dict;
            
        }


        public async Task<List<EncryptionConfig>> GetEncryptionConfigurations(ConcurrentDictionary<string, List<EncryptionConfig>> encryptConfigs, string folder, string bucket, string portalCode, string transactionID)
        {

            if (!encryptConfigs.TryGetValue(portalCode, out List<EncryptionConfig> config))
            {
                string s3Key = string.Format("{0}/{1}.json", folder, portalCode);
                var envConfig = await SearchS3ByKey<Dictionary<string, List<EncryptionConfig>>>(bucket, s3Key, transactionID, true);

                if (!envConfig.TryGetValue(GlobalConfiguration.environment, out config) || config == null || config.Count == 0)
                {
                    throw new Exception(string.Format("Unable to find vendor configuration. Environment: {0}, Bucket:{1}, Key:{2}", GlobalConfiguration.environment, bucket, s3Key));
                }
                // config = config.OrderBy(conf => conf.Priority).ToList();

                encryptConfigs.TryAdd(portalCode, config);
            }

            return config;
        }


        #endregion
    }
}

﻿using FAMS.CryptoService.core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace FAMS.CryptoService.v1.UseCases.Algorithms
{
    public sealed class FrameworkSymmetricCryptographer : IDisposable
    {
        private SymmetricAlgorithm _algorithm;
        private byte[] _key;
        private long _AlgorithmTypeCode;
        private bool _isLegacy;

        #region constructor
        public FrameworkSymmetricCryptographer(string algorithmType,
          string encryptionKey,
          long algorithmTypeCode,
          bool isLegacy)
        {
            try
            {
                this._key = Convert.FromBase64String(encryptionKey);
            }
            catch // Legacy DotNet gets a hash out of ascci based encryption key to decrypt
            {
                MD5CryptoServiceProvider hashProvider = new MD5CryptoServiceProvider();
                this._key = hashProvider.ComputeHash(
                              Encoding.ASCII.GetBytes(encryptionKey)
                            );
            }
            this._algorithm = CreateSymmetricAlgorithm(algorithmType);
            this._AlgorithmTypeCode = algorithmTypeCode;
            this._isLegacy = isLegacy;
        }
        #endregion

        #region static create algorithm
        private static SymmetricAlgorithm CreateSymmetricAlgorithm(string algorithmType)
        {
            return CryptographyUtility.CreateAlgorithm(algorithmType);
        }
        #endregion

        #region encrypt decrypt
        public Stream Encrypt(Stream plainData)
        {
            byte[] plaintextBytes = ((MemoryStream)plainData).ToArray();
            byte[] output = null;
            byte[] cipherText = null;

            this._algorithm.Key = this._key;

            if (this._algorithm.GetType().FullName.Equals("System.Security.Cryptography.TripleDESCryptoServiceProvider"))
                this._algorithm.Mode = CipherMode.ECB;


            using (ICryptoTransform transform = this._algorithm.CreateEncryptor())
            {
                cipherText = CryptographyUtility.Transform(transform, plaintextBytes);
            }

            if (this._isLegacy)
            {
                output = cipherText;
            }
            else
            {
                output = new byte[IVLength + cipherText.Length];
                Buffer.BlockCopy(this._algorithm.IV, 0, output, 0, IVLength);
                Buffer.BlockCopy(cipherText, 0, output, IVLength, cipherText.Length);
            }

            // Add our indicator to this encrypted text 
            // so that decrypt process will know which algorithm to use to decrypt
            byte[] finalOutput = CryptographyUtility.WrapCipherText(output, this._AlgorithmTypeCode);

            return StreamAssistant.StreamFromByteArray(finalOutput);
        }

        public Stream Decrypt(Stream cipherData)
        {

            byte[] encryptedTextBytes = ((MemoryStream)cipherData).ToArray();
            byte[] output = null;
            byte[] data = ExtractIV(encryptedTextBytes);

            this._algorithm.Key = this._key;

            if (this._algorithm.GetType().FullName.Equals("System.Security.Cryptography.TripleDESCryptoServiceProvider"))
                this._algorithm.Mode = CipherMode.ECB;

            using (ICryptoTransform transform = this._algorithm.CreateDecryptor())
            {
                if (this._isLegacy)
                {
                    output = CryptographyUtility.Transform(transform, encryptedTextBytes);
                }
                else
                {
                    output = CryptographyUtility.Transform(transform, data);
                }
            }

            return StreamAssistant.StreamFromByteArray(output);
        }
        #endregion

        #region private methods
        private int IVLength
        {
            get
            {
                if (this._algorithm.IV == null)
                {
                    this._algorithm.GenerateIV();
                }
                return this._algorithm.IV.Length;
            }
        }

        private byte[] ExtractIV(byte[] cipherData)
        {
            byte[] initVector = new byte[IVLength];

            if (cipherData.Length < IVLength + 1)
            {  
                return cipherData;
            }

            byte[] data = new byte[cipherData.Length - IVLength];

            Buffer.BlockCopy(cipherData, 0, initVector, 0, IVLength);
            Buffer.BlockCopy(cipherData, IVLength, data, 0, data.Length);

            this._algorithm.IV = initVector;

            return data;
        }
        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
            System.GC.SuppressFinalize(this);
        }

        #endregion

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                // release manages resources
            }

            if (this._algorithm != null)
            {
                this._algorithm.Clear();
                this._algorithm = null;
            }
        }

        ~FrameworkSymmetricCryptographer()
        {
            Dispose(false);
        }
    }
}

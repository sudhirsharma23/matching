﻿using FAMS.CryptoService.core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace FAMS.CryptoService.v1.UseCases.Algorithms
{
    public sealed class RijndaelSymmetricCryptographer : IDisposable
    {
        private SymmetricAlgorithm _algorithm;
        private string _encryptionSalt;
        private bool _isLegacy;
        private string _encryptionKey;
        private static PasswordDeriveBytes _pdb;
        private static byte[] _IV;
        private static byte[] _Key;
        private static int intSize;

        #region constructor

        public RijndaelSymmetricCryptographer(string algorithmType,
          string encryptionKey,
          string encryptionSalt,
          bool isLegacy)
        {

            _encryptionSalt = encryptionSalt;
            this._algorithm = CreateSymmetricAlgorithm(algorithmType);
            this._encryptionSalt = encryptionSalt;
            this._encryptionKey = encryptionKey;
            this._isLegacy = isLegacy;

            RijndaelManaged rm = new RijndaelManaged();

            lock (typeof(RijndaelSymmetricCryptographer))
            {
                _pdb = new PasswordDeriveBytes(
              Encoding.ASCII.GetBytes(_encryptionKey),
                  Encoding.ASCII.GetBytes(_encryptionSalt));

                _IV = _pdb.GetBytes(rm.IV.Length);
                _Key = _pdb.GetBytes(rm.KeySize / 8);

            }
            intSize = Marshal.SizeOf(typeof(int));

        }

        #endregion

        #region static create algorithm
        private static SymmetricAlgorithm CreateSymmetricAlgorithm(string algorithmType)
        {
            return CryptographyUtility.CreateAlgorithm(algorithmType);
        }
        #endregion

        #region encrypt decrypt
        public Stream Encrypt(Stream plainData)
        {
            RijndaelManaged rm = new RijndaelManaged();
            string ClearText = StreamAssistant.StreamToString(plainData);

            rm.IV = _IV;
            rm.Key = _Key;

            Stream returnStream = null;
            MemoryStream ms = new MemoryStream();
            using (CryptoStream cs = new CryptoStream(ms, rm.CreateEncryptor(), CryptoStreamMode.Write))
            {

                cs.Write(BitConverter.GetBytes(ClearText.Length), 0, intSize);
                cs.Write(Encoding.ASCII.GetBytes(ClearText), 0, Encoding.ASCII.GetByteCount(ClearText));
                cs.FlushFinalBlock();

                ms.Seek(0, SeekOrigin.Begin);
                returnStream = StreamAssistant.Copy(ms);
            }

            returnStream.Seek(0, SeekOrigin.Begin);
            return returnStream;

        }

        public Stream Decrypt(Stream cipherData)
        {

            RijndaelManaged rm = new RijndaelManaged();
            rm.IV = _IV;
            rm.Key = _Key;

            cipherData.Seek(0, SeekOrigin.Begin);
            Stream returnStream = null;
            MemoryStream ms = new MemoryStream();
            using (CryptoStream cs = new CryptoStream(cipherData, rm.CreateDecryptor(), CryptoStreamMode.Read))
            {
                byte[] clearBuf = new byte[cipherData.Length];
                byte[] stringSize = null;
                stringSize = new byte[intSize];

                cs.Read(stringSize, 0, intSize);
                cs.Read(clearBuf, 0, (int)cipherData.Length);
                ms = (MemoryStream)StreamAssistant.StreamFromString(Encoding.ASCII.GetString(clearBuf, 0, BitConverter.ToInt32(stringSize, 0)));

                ms.Seek(0, SeekOrigin.Begin);
                returnStream = StreamAssistant.Copy(ms);
            }

            returnStream.Seek(0, SeekOrigin.Begin);
            return returnStream;

        }
        #endregion



        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
            System.GC.SuppressFinalize(this);
        }

        #endregion

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                // release manages resources
            }

            if (this._algorithm != null)
            {
                this._algorithm.Clear();
                this._algorithm = null;
            }
        }

        ~RijndaelSymmetricCryptographer()
        {
            Dispose(false);
        }
    }
}

﻿using FAMS.CryptoService.v1.Models.Service;
using FAMS.CryptoService.v1.UseCases.Algorithms;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FAMS.CryptoService.v1.UseCases
{
    public class RijndaelSymmetricAlgorithmProvider : AlgorithmUseCase
    {
        private string _algorithmType = string.Empty;
        private string _encryptionKey = string.Empty;
        private string _encryptionSalt = string.Empty;
        private bool _isLegacy = false;

        #region constructor
        private RijndaelSymmetricAlgorithmProvider(string algorithmType,
          string encryptionKey,
          string encryptionSalt,
          bool isLegacy)
        {
            this._algorithmType = algorithmType;
            this._encryptionSalt = encryptionSalt;
            this._encryptionKey = encryptionKey;
            this._isLegacy = isLegacy;
        }

        public RijndaelSymmetricAlgorithmProvider(AlgorithmProvider AlgorithmProvider)
        {
            this._algorithmType = AlgorithmProvider.algorithmType;
            this._encryptionSalt = AlgorithmProvider.encryptionSalt;
            this._encryptionKey = AlgorithmProvider.encryptionKey;
            this._isLegacy = AlgorithmProvider.isLegacy;
        }
        #endregion

        public static RijndaelSymmetricAlgorithmProvider Create(params object[] args)
        {
            if (args.Length < 4)
                throw new ArgumentException("List of parameters not sufficient");

            return new RijndaelSymmetricAlgorithmProvider(
              (string)args[0],
              (string)args[1],
              (string)args[2],
              (bool)args[3]);
        }

        #region abstarct Members

        public override Stream Encrypt(Stream plainData)
        {
            if (plainData == null) throw new ArgumentNullException("plainText is null.");

            Stream output = null;

            using (RijndaelSymmetricCryptographer crypto = new RijndaelSymmetricCryptographer(
              this._algorithmType, this._encryptionKey,
              this._encryptionSalt, this._isLegacy))
            {
                output = crypto.Encrypt(plainData);
            }

            return output;
        }

        public override Stream Decrypt(Stream cipherData)
        {
            if (cipherData == null) throw new ArgumentNullException("cipherText");

            Stream output = null;

            using (RijndaelSymmetricCryptographer crypto = new RijndaelSymmetricCryptographer(
              this._algorithmType, this._encryptionKey,
              this._encryptionSalt, this._isLegacy))
            {
                output = crypto.Decrypt(cipherData);
            }

            return output;
        }


        #endregion
    }
}

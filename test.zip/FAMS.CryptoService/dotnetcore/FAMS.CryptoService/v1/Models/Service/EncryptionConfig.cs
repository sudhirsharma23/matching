﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.CryptoService.v1.Models.Service
{
   public class EncryptionConfig
    {
        public string EncryptionConfigCode { get; set; }
        public Nullable<long> EncryptionIndicatorCode { get; set; }
        public string AlgorithmProvider { get; set; }
        public string AlgorithmType { get; set; }
        public string EncryptionKey { get; set; }
        public string EncryptionSalt { get; set; }
        public Nullable<bool> AllowCaching { get; set; }
        public bool EncryptionDefaultAlgorithm { get; set; }
    }
}

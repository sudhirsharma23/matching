﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.CryptoService.v1.Models.Service
{
    public class AlgorithmProvider
    {
        public string algorithmType { get; set; }
        public string encryptionKey { get; set; }
        public string encryptionSalt { get; set; }
        public bool isLegacy { get; set; }

        public long encryptionAlgorithmIndicator;


    }
}

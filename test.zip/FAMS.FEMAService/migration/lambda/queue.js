const fs = require("fs");
const DynamoDBClient = require("aws-sdk/clients/dynamodb").DocumentClient;
const DynamoDB = require("aws-sdk/clients/dynamodb");
const IniFileCreds = require("aws-sdk").SharedIniFileCredentials;
const command = require("commander");
const _LOG = require("./logHelper").log;
const AWS = require("aws-sdk");
const sqs = new AWS.SQS({'region': 'us-west-2'}); 

command
.option("-s, --source-profile <profile>", "AWS Profile for source")
    .option("-t, --target-profile <profile>", "AWS Profile for target")
    .option("-f, --config-file <file>", "Config file")
    .option("-l, --log-output <logFolder>", "Log output directory")
    .action((cmd) => {
        let state = {};
        readConfigAsync(state, cmd.configFile)
            .then(function (state) {
                return getCountAsync(state, state.config.source.table, cmd.sourceProfile, state.config.queue);
            })
            .then(state => {
                console.log(`Records Found: ${state.fileCount}`);
                
            })
            .catch(err => {
                console.error(err);
                console.error(err.stack);
            });
    });

if (process.argv.length < 3) {
     command.help();
 }

command.parse(process.argv);

function readConfigAsync(state, filePath) {
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, (err, data) => {
            if (err) {
                reject(err);
            }
            else {
                let config = JSON.parse(data.toString());
                state.config = config;
                resolve(state);
            }
        });
    });
}




async function getCountAsync(state, tableName, profile, queueurl) {
    if (process.env.FILE_COUNT) {
        console.log(`Using filecount from Environment variables`);
        state.fileCount = parseInt(process.env.FILE_COUNT);
        return state;
    }
    const params = {
        TableName: tableName,
        Limit : 100
        // ,FilterExpression : 'DateTimeUTC > :this_date',
        //  ExpressionAttributeValues : {':this_date' : '2019-06-25'}
    };

    const SourceDBClient = new DynamoDBClient({
        service: new DynamoDB({
            credentials:  new IniFileCreds({ profile: profile }),
            region: 'us-west-2'
        })
    });

    let items;
    let count = 0;
    do{
        try{
            items =  await SourceDBClient.scan(params).promise();
            count +=items.Count;
            insertIntoQueue(items.Items,queueurl);
        }
        catch (err) {
            _LOG(`Failed on ListObjects from dynamo, error: ${err.message}, stack: ${err.stack}`);
        }
        params.ExclusiveStartKey  = items.LastEvaluatedKey;
    }while(typeof items.LastEvaluatedKey != "undefined") ;

    state.fileCount = count;

    return state;
}

 function insertIntoQueue(item, queueurl){
    var params = {
        DelaySeconds: 10,
      
        MessageBody: JSON.stringify(item),
        QueueUrl: queueurl
      };
      
      sqs.sendMessage(params, function(err, data) {
        if (err) {
          console.log("Error", err);
        } else {
          console.log("Success", data.MessageId);
        }
      });
}

const fs = require('fs');
require('events').EventEmitter.defaultMaxListeners = 50;

const path = require("path");
const DynamoDBClient = require("aws-sdk/clients/dynamodb").DocumentClient;
const DynamoDB = require("aws-sdk/clients/dynamodb");
const S3Client = require("aws-sdk/clients/s3");
const stream = require('stream');
//const promisePipe = require("promisepipe");
const moment = require('moment');

const AWS = require("aws-sdk");
const IniFileCreds = require("aws-sdk").SharedIniFileCredentials;

const core = require("./core");
const fileHelper = require("./fileHelper");
const _LOG = require("./logHelper").log;
const KeyBuilder = require("./keyBuilder").Builder;


exports.handler =  async function handler(event, context, callback) {

    let start = moment.utc();
    let recordPromises = [];
    let count = 0;
    let params = {"region": process.env.REGION, "source_bucket" : process.env.SOURCE_BUCKET
                , "dest_bucket": process.env.DEST_BUCKET,"table_name": process.env.TABLE_NAME, "kmskeyid": process.env.KMS_KEY_ID
};
try{
console.log(params);
    //const sourceCreds = new IniFileCreds({ profile: "RC-Support" });
    //const targetCreds = new IniFileCreds({ profile: "sbx" });
    const targetDBClient = new DynamoDBClient({
        service: new DynamoDB({
            //credentials: targetCreds,
            region: params.region
        })
    });
    const sourceS3Client = new S3Client({
      //  credentials: sourceCreds,
      region: params.region
    });

    const sourceS3Client2 = new S3Client({
        //  credentials: sourceCreds,
        region: params.region
      });

    const targetS3Client = new S3Client({
      //  credentials: targetCreds,
      region: params.region
                });

                const targetS3Client2 = new S3Client({
                    //  credentials: targetCreds,
                    region: params.region
                              });

    for(let i in event.Records){
        let promises = [];
        let record = event.Records[i];
        
        if( !record.body && !record.Body ){
            continue;
        }

        let batch = JSON.parse(new Buffer(record.body || record.Body).toString("utf-8"));

        for( let x in batch){

            count++;
            let msg = batch[x];
        try{
           
                console.log(msg.RequestS3Key);
                console.log(msg.ResponseS3Key);

                        let getTasks = [       core.getFromS3(sourceS3Client, {
                            sourceBucket: params.source_bucket,
                            sourceKey: msg.RequestS3Key
                        }),
                        
                        core.getFromS3(sourceS3Client2, {
                                        sourceBucket: params.source_bucket,
                                        sourceKey: msg.ResponseS3Key
                                    })
                    ];

                        let [s3Req, s3Resp] = await Promise.all(getTasks);
               // console.log(s3Req);
               // console.log(s3Resp);
               let saverequest = null;
               let saveresponse = null;
               let savetransaction = null;
               
               if(s3Req !== null){
                saverequest =  savetoS3(targetS3Client, {
                    bucketName: params.dest_bucket, 
                    key : msg.RequestS3Key,
                    body: s3Req,
                    metadata :{ "globalid": msg.GlobalID.toLowerCase()},
                    contenttype: "application/json",
                    tagging: "LifeSpan=7y" ,
                    kmskeyid:params.kmskeyid
                                    });
               }
               if(s3Resp !== null){
                saveresponse = savetoS3(targetS3Client2, {
                    bucketName:  params.dest_bucket, 
                    key : msg.ResponseS3Key,
                    body: s3Resp,
                    metadata :{ "globalid": msg.GlobalID.toLowerCase()},
                    contenttype: "application/json",
                    tagging: "LifeSpan=7y",
                    kmskeyid: params.kmskeyid
                                    });
               }

               savetransaction =  SaveDynamoTransaction(targetDBClient,msg,{
                tableName: params.table_name
                                });
              

                        let putTasks = [saverequest,saveresponse,savetransaction];
                         await  Promise.all(putTasks);

                        
                    }
                    catch(ex){
                        console.log(ex);
                    }
                            
        }
    }
}
catch(ex){
    console.log(ex);
}
//resolve();
    
}


 async function SaveDynamoTransaction(targetDBClient, record,opts){

    try{
    let transaction = {
            TransactionID: record.TransactionID.toLowerCase(),
            BucketName: opts.bucketName,
            ClientID: record.ClientID.toLowerCase(),
            DataSource: record.DataSource,
            DateTimeUTC: record.DateTimeUTC,
            Elapsedms: record.Elapsedms,
            GlobalID: record.GlobalID.toLowerCase(),
            HttpStatus: record.HttpStatus,
            PortalCode: record.PortalCode.toLowerCase(),
            Product: record.Product,
            RequestS3Key: record.RequestS3Key,
            RequestorID: record.RequestorID,
            ResponseS3Key: record.ResponseS3Key,
            CacheKey: record.CacheKey,
            VendorCalls: record.VendorCalls,
        };

        const tableName = opts.tableName;
      

       await core.checkIfTransactionCopied(targetDBClient,tableName, transaction.TransactionID).then(r=>{
        if (!r.allCopied) {
            targetDBClient.put({ TableName: tableName, Item: transaction },function(err,data){
               console.log(err,data);
            }) ;
        }
      });
     
    }
    catch (ex)
    {
        console.log(ex);
    }

}

 async function savetoS3(targetS3Client, opts ){
try{
    let request ={
            Bucket: opts.bucketName,
            Key: opts.key,
            Body: opts.body,
            Metadata :opts.metadata,
            Tagging: opts.tagging,
            ContentType: opts.contenttype,
            SSEKMSKeyId: opts.kmskeyid,
            ServerSideEncryption: "aws:kms",

    }

await core.checkIfS3Copied(targetS3Client, opts.bucketName, opts.key).then( r=>{

    if (!r.allCopied) {
        
          targetS3Client.upload(request, function(err,data){
              console.log(err,data)

          });
       
}

});
     
    }
    catch(ex){
        console.log(ex);
    }
}
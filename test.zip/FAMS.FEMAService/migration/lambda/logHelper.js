exports.log = log;

/**
* 
* @param {WriteStream} msg 
* @param {*} stream 
*/
function log(msg, stream) {
   if (!process.env.LOG_TO_STDOUT) {
       stream.write(msg + "\n");
   }
   else {
       console.log(msg);
   }
}

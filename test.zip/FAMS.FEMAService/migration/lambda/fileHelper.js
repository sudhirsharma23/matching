const fs = require("fs");
exports.createFileAsync = createFileAsync;

/**
 * 
 * @param {string} filepath 
 */
function createFileAsync(filepath) {
    return new Promise((resolve, reject) => {
        let stream = fs.createWriteStream(filepath, {
            autoClose: true
        });

        stream.on('open', fd => {
            resolve(stream);
        });

        stream.on('error', err => {
            reject(err);
        })
    });
}
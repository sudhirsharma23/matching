const AWS = require("aws-sdk");

const sqs = new AWS.SQS();

const lambda = require("./index.js");

async function _main() {
   await sqs.receiveMessage( {
        QueueUrl : process.env.SQS_URL,
        MaxNumberOfMessages : 1,
        VisibilityTimeout : 120,
        WaitTimeSeconds : 10
    }).promise().then( r => {

        process.env.REGION = "us-west-2";
        process.env.SOURCE_BUCKET = "sbx-reverse-phone-api-w2-kind-ladybird";
        process.env.DEST_BUCKET = "sbx-reverse-phone-api-w2-kind-ladybird";
        process.env.TABLE_NAME = "sbx-reverse-phone-api-w2-transactions";

        //return  new Promise( (resolve, reject) => {

             lambda.handler( {
                Records : r.Messages
            }, 
            {},
            function(err,resp) {
                if (err){
                    console.error( err );
                    reject(err);
                }

                console.log(resp);
                resolve();
            });

        //});

    });


}
_main();

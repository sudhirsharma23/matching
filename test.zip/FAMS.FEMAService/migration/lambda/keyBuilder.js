/**
 * 
 * @param {String} transactionID 
 * @param {String} globalID 
 */
function getIdentifier(transactionID, globalID) {
    return `${globalID}_${transactionID}`.toLowerCase();
}

class KeyBuilder {
    constructor(apiVersion, globalID, transactionID) {
        this.apiVersion = apiVersion;
        this.globalID = globalID.toLowerCase();
        this.transactionID = transactionID.toLowerCase();
    }

    getServiceResponseKey() {
        let key = `fema/ServiceResponses/${this.apiVersion}/${this.transactionID}`;
        return key;
    }

    getServiceRequestKey() {
        let key = `fema/ServiceRequests/${this.apiVersion}/${this.transactionID}`;
        return key;
    }

    getVendorResponseKey() {
        let key = `fema/VendorResponses/${this.apiVersion}/${this.transactionID}`;
        return key;
    }

    getVendorRequestKey() {
        let key = `fema/VendorRequests/${this.apiVersion}/${this.transactionID}`;
        return key;
    }
}

let keyBuild = {
    Builder: KeyBuilder
};

module.exports = keyBuild;
const fs = require("fs");
const DynamoDBClient = require("aws-sdk/clients/dynamodb").DocumentClient;
const DynamoDB = require("aws-sdk/clients/dynamodb");
const S3Client = require("aws-sdk/clients/s3");
const IniFileCreds = require("aws-sdk").SharedIniFileCredentials;
const command = require("commander");
const _LOG = require("./logHelper").log;
const AWS = require("aws-sdk");
const sqs = new AWS.SQS({'region': 'us-west-2'}); 
const path = require("path");
const moment = require("moment");
const fileHelper = require("./fileHelper");
const Lock = require("await-lock");
const core = require("./core");

command
.option("-s, --source-profile <profile>", "AWS Profile for source")
    .option("-t, --target-profile <profile>", "AWS Profile for target")
    .option("-f, --config-file <file>", "Config file")
    .option("-l, --log-output <logFolder>", "Log output directory")
    .action((cmd) => {
        let state = {};
        readConfigAsync(state, cmd.configFile)
            .then(function (state) {
                return getCountAsync(state, state.config.source.table, cmd.sourceProfile,state.config.source.bucket,
                    state.config.destination.table, cmd.targetProfile,state.config.destination.bucket,cmd.logOutput);
            })
            .then(state => {
                console.log(`Records Found: ${state.fileCount}`);
                
            })
            .catch(err => {
                console.error(err);
                console.error(err.stack);
            });
    });

if (process.argv.length < 3) {
     command.help();
 }

command.parse(process.argv);

function readConfigAsync(state, filePath) {
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, (err, data) => {
            if (err) {
                reject(err);
            }
            else {
                let config = JSON.parse(data.toString());
                state.config = config;
                resolve(state);
            }
        });
    });
}




async function getCountAsync(state, tableName, profile, bucket, desttableName, targetprofile, destbucket,logOutput) {
    if (process.env.FILE_COUNT) {
        console.log(`Using filecount from Environment variables`);
        state.fileCount = parseInt(process.env.FILE_COUNT);
        return state;
    }

    let logPath = __dirname;

    if (logOutput) {
        logPath = path.join(logPath, logOutput);
        if (!fs.existsSync(logPath)) {
            fs.mkdirSync(logPath);
        }
    }

    let date = moment().format("MM-DD_HH.mm.ss.SSS");

    let csvLogFile = path.join(logPath, `${date}_migration.csv`);
    let txtLogFile = path.join(logPath, `${date}_migration.log`);


    let csvLogStream = await fileHelper.createFileAsync(csvLogFile);
    let logStream = await fileHelper.createFileAsync(txtLogFile);

    csvLogStream.on('error', err => {
        console.log('CSV Log write failed: ' + err.message);
    })

    logStream.on('error', err => {
        console.log("TXT Log write failed: " + err.message);
    })

    csvLogStream.write('transactionID,transactionstatus,requests3Key,requeststatus,responses3Key,responsestatus,error \n');


    const sourceparams = {
        TableName: tableName
        ,Limit : 400
      //   ,FilterExpression : 'DateTimeUTC > :this_date',
      //   ExpressionAttributeValues : {':this_date' : '2019-05-16'}
    };

    const targetparams = {
        TableName: desttableName
    };

    const SourceDBClient = new DynamoDBClient({
        service: new DynamoDB({
            credentials:  new IniFileCreds({ profile: profile }),
            region: 'us-west-2'
        })
    });

    const lock = new Lock();
    

    let items;
    let count = 0;
    do{
        try{
            items =  await SourceDBClient.scan(sourceparams).promise();
            count +=items.Count;
            let batch = [];
            batch.push(Verify({
                 recs:   items.Items,
                 profile: profile,
                 targetprofile: targetprofile,
                 bucket: destbucket,
                 tableName : desttableName,
                 logStream: logStream,
                 csvLogStream: csvLogStream,
                 count : count,
                 lock:lock
                }));
                await Promise.all(batch);
                let elapsed = (Date.now() - start) / 1000;
                _LOG(`${new Date().toLocaleString()} BatchSize: ${batchSize}, Duration: ${elapsed}`, logStream);

        }
        catch (err) {
            _LOG(`Failed on ListObjects from dynamo, error: ${err.message}, stack: ${err.stack}`, logStream);
        }
        sourceparams.ExclusiveStartKey  = items.LastEvaluatedKey;
    }while(typeof items.LastEvaluatedKey != "undefined") ;

    state.fileCount = count;

    return state;
}

 async function Verify(opts){
     let batch = opts.recs;
     let logStream = opts.logStream;
    let csvLogStream = opts.csvLogStream;
    let lock = opts.lock;
    let record = {
        transactionID: null,
        requests3Key: null,
        responses3Key: null,
        requeststatus: null,
        responsestatus: null,
        transactionstatus:null,
        error: ''
        
    };

    const targetDBClient = new DynamoDBClient({
        service: new DynamoDB({
            credentials: new IniFileCreds({ profile: opts.targetprofile }), 
            region: 'us-west-2'
        })
    });
    const targetS3Client = new S3Client({
        credentials: new IniFileCreds({ profile: opts.targetprofile }), 
        region: 'us-west-2' 
    });

    const targetS3Client2 = new S3Client({
        credentials: new IniFileCreds({ profile: opts.targetprofile }), 
        region: 'us-west-2' 
      });

    

    for( let x in batch){

        //count++;
        try{
        let msg = batch[x];
        let getTasks = [ core.objectExists(targetS3Client, opts.bucket, msg.RequestS3Key),
                         core.objectExists(targetS3Client2, opts.bucket, msg.ResponseS3Key),
                         core.checkIfTransactionCopied(targetDBClient, opts.tableName, msg.TransactionID.toLowerCase())
    ];
    record.transactionID=msg.TransactionID.toLowerCase();
    record.requests3Key = msg.RequestS3Key;
    record.responses3Key = msg.ResponseS3Key;


    let [s3Req, s3Resp , transaction]=  await Promise.all(getTasks);
    record.requeststatus = s3Req;
    record.responsestatus = s3Resp;
    record.transactionstatus = transaction.allCopied;
    
}
    catch(ex){
        console.log(ex);
    }

    await lock.acquireAsync();
    try {
        csvLogStream.write(`"${record.transactionID}","${record.transactionstatus}","${record.requests3Key}","${record.requeststatus}","${record.responses3Key}","${record.responsestatus}","${record.error}"\n`);
        _LOG(`${new Date().toLocaleString()} TransactionID: ${record.transactionID}, TransactionStatus: ${record.transactionstatus},
        ,RequestS3Key : ${record.requests3Key},RequestS3Status : ${record.requeststatus},ResponseS3Key : ${record.responses3Key},ResponseS3Status : ${record.responsestatus},
        `, logStream);
    }
    finally {
        lock.release();
    }


}

    
     
}

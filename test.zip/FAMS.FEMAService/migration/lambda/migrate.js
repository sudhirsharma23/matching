const fs = require("fs");
const path = require("path");
const DynamoDBClient = require("aws-sdk/clients/dynamodb").DocumentClient;
const DynamoDB = require("aws-sdk/clients/dynamodb");
const S3Client = require("aws-sdk/clients/s3");
const IniFileCreds = require("aws-sdk").SharedIniFileCredentials;

const request = require("request-promise-native");
const command = require("commander");
const Lock = require("await-lock");
const moment = require("moment");


const core = require("./core");
const fileHelper = require("./fileHelper");
const _LOG = require("./logHelper").log;
const parseString = require('xml2js').parseString;
const xmlParser = require('xml-js');

command
.option("-s, --source-profile <profile>", "AWS Profile for source")
    .option("-t, --target-profile <profile>", "AWS Profile for target")
    .option("-f, --config-file <file>", "Config file")
    .option("-b, --batch-size <batchSize>", "Number of orders to run in asynchronously")
    .option("-l, --log-output <logFolder>", "Log output directory")
    .action((cmd) => {
        let state = {};
        readConfigAsync(state, cmd.configFile)
            .then(function (state) {
                return core.getCountAsync(state, state.config.source.table, cmd.sourceProfile);
            })
            .then(state => {
                console.log(`Files Found: ${state.fileCount}`);
                return migrateAsync(state, state.config, cmd.sourceProfile, cmd.targetProfile, cmd.logOutput, cmd.batchSize);
            })
            .catch(err => {
                console.error(err);
                console.error(err.stack);
            });
    });

if (process.argv.length < 3) {
     command.help();
 }

command.parse(process.argv);

function readConfigAsync(state, filePath) {
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, (err, data) => {
            if (err) {
                reject(err);
            }
            else {
                let config = JSON.parse(data.toString());
                state.config = config;
                resolve(state);
            }
        });
    });
}

async function migrateAsync(state, config, sourceProfile, targetProfile, logOutput, batchSize) {
    let logPath = __dirname;

    if (logOutput) {
        logPath = path.join(logPath, logOutput);
        if (!fs.existsSync(logPath)) {
            fs.mkdirSync(logPath);
        }
    }

    let date = moment().format("MM-DD_HH.mm.ss.SSS");

    let csvLogFile = path.join(logPath, `${date}_migration.csv`);
    let txtLogFile = path.join(logPath, `${date}_migration.log`);


    let csvLogStream = await fileHelper.createFileAsync(csvLogFile);
    let logStream = await fileHelper.createFileAsync(txtLogFile);

    csvLogStream.on('error', err => {
        console.log('CSV Log write failed: ' + err.message);
    })

    logStream.on('error', err => {
        console.log("TXT Log write failed: " + err.message);
    })

    csvLogStream.write('transactionID,s3Key,status,error \n');

    const sourceCreds = new IniFileCreds({ profile: sourceProfile });
    const targetCreds = new IniFileCreds({ profile: targetProfile });

    const sourceS3Client = new S3Client({
        credentials: sourceCreds
    });

    let resp = {
        //IsTruncated: true
    };

    const lock = new Lock();

    let count = 0;

    try {
        do {
            try {
                resp = await sourceS3Client.listObjectsV2({
                    Bucket: config.source.bucket,
                    Prefix: "identity/ServiceResponses/v1/",
                    ContinuationToken: resp.NextContinuationToken,
                    MaxKeys: parseInt(batchSize)
                }).promise();

                let batch = [];
                let start = Date.now();
                for (let data of resp.Contents) {
                    count++;
                    batch.push(migrateResponseAsync({
                        sourceCreds: sourceCreds,
                        targetCreds: targetCreds,
                        key: data.Key,
                        logStream: logStream,
                        csvLogStream: csvLogStream,
                        lock: lock,
                        count: count,
                        fileCount: state.fileCount,
                        config: config
                    }));
                }

                await Promise.all(batch);
                let elapsed = (Date.now() - start) / 1000;
                _LOG(`${new Date().toLocaleString()} BatchSize: ${batchSize}, Duration: ${elapsed}`, logStream);
            }
            catch (err) {
                _LOG(`Failed on ListObjects, error: ${err.message}, stack: ${err.stack}`, logStream);
            }
        }
        while (resp.IsTruncated);
    }
    finally {
        csvLogStream.end();
        logStream.end();
    }
}


/**
 * 
 * @param {Object} opts 
 * @param {S3Client} opts.s3Client
 * @param {Object} opts.transaction 
 * @param {object} opts.serviceRequest
 * @param {Lock} opts.lock
 */
async function callMigrateData(opts) {
    let response = await request({
        uri: opts.uri+opts.product,
        method: "POST",
        body: opts.body,
        resolveWithFullResponse: true,
        simple: false,
        rejectUnauthorized:false,
        headers: {
            "content-type": opts.contentType,
            "px-clientID" :opts.clientID,
            "px-globalID" :opts.globalID,
            "px-portalCode" :opts.portalCode,
            "px-companyName" :opts.companyName
        }
    });

    if (response.statusCode === 200) {
        let parsedResponse = null;
        let transactionID = null;
        if(response.body.toString().startsWith("<"))
        {
            parseString(response.body, function(err,result)
            {
                parsedResponse = result; 
                transactionID = parsedResponse.IdentityResponse.TransactionID[0]
            });
        }
        else
        {
         parsedResponse = JSON.parse(response.body);
         transactionID = parsedResponse.TransactionID
        }

        if (transactionID)
            return {
                success: true
            };
    }

    return {
        success: false,
        error: `Error calling migration endpoint: httpStatus: ${response.statusCode}, raw Response: ${response.body.toString()}`
    };
}

function parseResponse(s3Resp){
    let serviceRequest = null;
    try {
         serviceRequest = JSON.parse(s3Resp);
        // return serviceRequest;
        }
    catch {
        s3Resp = s3Resp.replace("utf-16","utf-8");
       // serviceRequest = s3Resp;
        // var resul = xmlParser.xml2json(s3Resp, {compact: true, spaces: 4});
        // serviceRequest = JSON.parse(resul);
        //  parseString(s3Resp, function(err,result){
        //      serviceRequest = JSON.parse(result);
        //    //return serviceRequest;
        // });
       
    }
    finally{
        return s3Resp;
    }
}

async function migrateResponseAsync(opts) {
    let logStream = opts.logStream;
    let csvLogStream = opts.csvLogStream;
    let lock = opts.lock;
    let record = {
        transactionID: null,
        s3Key: null,
        status: null,
        error: ''
        
    };

    
    let match = opts.key.split("/");
    //Logging
    record.s3Key = opts.key;
    if (process.env.TO_FILE)
        process.stdout.write(`Processing: ${opts.key} - ${opts.count.toString().padStart(5)} of ${opts.fileCount}\r`);
    else
        console.log(`Processing: ${opts.key} - ${opts.count.toString().padStart(5)} of ${opts.fileCount}`);

    let transactionID;

    try {
        let config = opts.config;
        const sourceS3Client = new S3Client({
            credentials: opts.sourceCreds
        });

        const targetS3Client = new S3Client({
            credentials: opts.targetCreds
        });

        const sourceDBClient = new DynamoDBClient({
            service: new DynamoDB({
                credentials: opts.sourceCreds,
                region: "us-west-2"
            })
        });

        const targetDBClient = new DynamoDBClient({
            service: new DynamoDB({
                credentials: opts.targetCreds,
                region: "us-west-2"
            })
        });

       
        transactionID = match[3];
        record.transactionID = transactionID;

        if (match[1]) {
            let getTasks = [
                core.getRequestAndTransaction(sourceDBClient, config.source.table, transactionID, "TransactionID"),
                core.getFromS3(sourceS3Client, {
                    sourceBucket: config.source.bucket,
                    sourceKey: opts.key
                })];

            let [transaction, s3Resp] = await Promise.all(getTasks);

            let serviceRequest = parseResponse(s3Resp);

           let contentType = "application/json"
           if(s3Resp.toString().startsWith("<")){
               contentType="application/xml";
           }

            let globalID = transaction.GlobalID;

            if (!transaction) {
                record.status = "NotFound"
                record.error = "No record found in dynamodb"
            }
            else {
              

                let alreadyCopied = await core.allCopied(targetS3Client, targetDBClient, config.destination.bucket, transactionID, globalID, config.destination.table, transaction);
                if (!alreadyCopied) {


                    let stat = await callMigrateData({
                        body: serviceRequest,
                        uri: config.migrationEndpoint,
                        clientID: transaction.ClientID,
                        globalID:  transaction.GlobalID,
                        portalCode:  transaction.PortalCode,
                        companyName:  transaction.CompanyName,
                        product: transaction.Product.toLowerCase(),
                        contentType:contentType
                    });

                    if (stat.success) {
                        record.status = "Completed";
                    }
                    else {
                        record.status = "MigrationFailed";
                        record.error = "Failed calling migration endpoint";
                    }
                }
                else {
                    record.status = "AlreadyCopied";
                }
            }
        }
    }
    catch (ex) {
        _LOG(`${new Date().toLocaleString()} Failed on ${transactionID}, error: ${ex.message}, stack: ${ex.stack}`, logStream);
    }

    await lock.acquireAsync();
    try {
        csvLogStream.write(`"${record.transactionID}","${record.s3Key}","${record.status}","${record.error}","${record.orderStatus}","${record.hasPDF}","${record.hasJSON}"\n`);
        _LOG(`${new Date().toLocaleString()} TransactionID: ${record.transactionID}, Status: ${record.status}`, logStream);
    }
    finally {
        lock.release();
    }
}

const fs = require("fs");
const DynamoDBClient = require("aws-sdk/clients/dynamodb").DocumentClient;
const DynamoDB = require("aws-sdk/clients/dynamodb");
const S3Client = require("aws-sdk/clients/s3");
const IniFileCreds = require("aws-sdk").SharedIniFileCredentials;
const KeyBuilder = require("./keyBuilder").Builder;
const AWS = require("aws-sdk");

const sqs = new AWS.SQS(); 
//const SERVICE_FILENAMES = require("../SSNTaxService/artifacts/lookUp/filenames").service;

module.exports = {
    getCountAsync: getCountAsync,
    getRequestAndTransaction: getRequestAndTransaction,
    allCopied: allFilesCopied,
    checkIfCopied: checkIfCopied,
    getFromS3: getFromS3,
    checkIfS3Copied:checkIfS3Copied,
    checkIfTransactionCopied: checkIfTransactionCopied,
    objectExists:objectExists
}

async function getCountAsync(state, tableName, profile) {
    if (process.env.FILE_COUNT) {
        console.log(`Using filecount from Environment variables`);
        state.fileCount = parseInt(process.env.FILE_COUNT);
        return state;
    }
    const params = {
        TableName: tableName,
        Limit : 8
    };

    const SourceDBClient = new DynamoDBClient({
        service: new DynamoDB({
            credentials:  new IniFileCreds({ profile: profile }),
            region: "us-west-2"
        })
    });

    let items;
    let count = 0;
    do{
        try{
            items =  await SourceDBClient.scan(params).promise();
            count +=8;
            insertIntoQueue(items.Items);
        }
        catch (err) {
            _LOG(`Failed on ListObjects from dynamo, error: ${err.message}, stack: ${err.stack}`, logStream);
        }
       
        // items.Items.forEach((item) => {
        //     insertIntoQueue(item);
           
        //     count +=1;
        // });
        params.ExclusiveStartKey  = items.LastEvaluatedKey;
    }while(typeof items.LastEvaluatedKey != "undefined") ;

    
    

    state.fileCount = count;

    return state;
}

 function insertIntoQueue(item){
    var params = {
        DelaySeconds: 10,
      
        MessageBody: JSON.stringify(item),
        QueueUrl: "https://sqs.us-west-2.amazonaws.com/666678657097/sbx-revphone-migration-w2-knowing-finch-green-revphone-batches"
      };
      
      sqs.sendMessage(params, function(err, data) {
        if (err) {
          console.log("Error", err);
        } else {
          console.log("Success", data.MessageId);
        }
      });
}




async function getRequestAndTransaction(dbClient, table, transactionID, idKey) {
    let doc = await dbClient.query({
        TableName: table,
        KeyConditionExpression: "#id = :id",
        ExpressionAttributeNames: {
            "#id": idKey
        },
        ExpressionAttributeValues: {
            ":id": transactionID
        }
    }).promise();

    return doc.Items[0];
}

/**
 * @param {S3Client} s3Client
 * @param {DynamoDBClient} dbClient
 */
async function allFilesCopied(s3Client, dbClient, targetBucket, transactionID, globalID, targetTable, legacyTransaction) {
    let resp = await checkIfCopied(s3Client, dbClient, targetBucket, transactionID, globalID, targetTable, legacyTransaction);
    return resp.allCopied;
}

async function checkIfCopied(s3Client, dbClient, targetBucket, transactionID, globalID, targetTable, legacyTransaction) {
    let resp = {
        allCopied: false,
        missing: 'none'
                  
    }
    const keyBuilder = new KeyBuilder("v1", globalID, transactionID);

    

    //Response record copied?
    exists = await objectExists(s3Client, targetBucket, keyBuilder.getServiceResponseKey());

    if (!exists) {
        resp.missing = "response";
        return resp;
    }


    resp.allCopied = true;
    return resp;
}

async function checkIfTransactionCopied(dbClient, targetTable, transactionID){
   let resp = {
        allCopied: false,
        missing: 'none'          
    } 
    try{
    let transaction = await getRequestAndTransaction(dbClient, targetTable, transactionID, "TransactionID");

    if (!transaction) {
        resp.missing = "TransactionRecord";
        return resp;
    }
     resp.allCopied = true;
}
catch(ex){
    console.log(ex);
}
    return resp;
}

async function checkIfS3Copied(s3Client,targetBucket, key){
let resp = {
        allCopied: false,
        missing: 'none'          
    }
    
     exists = await objectExists(s3Client, targetBucket, key);

    if (!exists) {
        resp.missing = key;
        return resp;
    }

    resp.allCopied = true;
    return resp;

}




async function objectExists(s3Client, bucket, key) {
    try {
        await s3Client.headObject({
            Bucket: bucket,
            Key: key
        }).promise();
        return true;
    }
    catch (err) {
        console.log(err);
        //return false;
        if (!err.code || err.code.toLowerCase() !== 'notfound') {
        //    throw err;
            
        }
        
        return false;
    }
}


async function getFromS3(sourceS3Client, opts, name, encoding) {
    try {
        let resp = await sourceS3Client.getObject({
            Bucket: opts.sourceBucket,
            Key: opts.sourceKey,
        }).promise();

        if (name) {
            let r = {};
            r[name] = resp.Body.toString(encoding);
            return r;
        }
        else {
            return resp.Body.toString(encoding);
        }
    } catch (err) {
        if (!err.statusCode || err.statusCode !== 404) {
            throw err;
        }
        console.log(err);
        return null;
    }
}





using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.Lambda.Core;
using Amazon.S3;
using Amazon.S3.Model;
using FAMS.BankruptycyService.v1.UseCases.Service;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.FEMAService.core;
using FAMS.FEMAService.core.Models;
using FAMS.FEMAService.v1.Models.Service;
using FAMS.FEMAService.v1.Models.Vendor;
using FAMS.FEMAService.v1.UseCases.Analytics;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace FAMS.FEMAService.v1
{
    public class API
    {
        static ConcurrentDictionary<string, HttpClient> HttpClients;
        static object HttpClientLock = new object();

        static List<Method> MethodLookup;
        static object MethodLock = new object();

        AlertUseCase AlertUseCase;
        ServiceUseCase UseCase;
        LoggingAssistant Logger;
        const string API_VERSION = "v1";



        #region Constructors
        public API()
        {
            UseCase = new ServiceUseCase();
            AlertUseCase = new AlertUseCase();

            InitializeMethodLookup();
            InitializeHttpClient();
        }


        //Used for testing purposes
        public API(IAmazonS3 s3Client, IAmazonDynamoDB dbClient)
        {
            UseCase = new ServiceUseCase(s3Client, dbClient);
            AlertUseCase = new AlertUseCase();

            InitializeMethodLookup();
            InitializeHttpClient();
        }
        #endregion

        #region Function Handlers
        /// <summary>
        /// Routing handler for the lambda functions.  This is the one method that the lambda will call directly, then based on HTTP Method and URI, this method will invoke the correct function to call.
        /// </summary>
        /// <param name="jodiRequest">Stream of JODIRequest. Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>Stream of JODI response.  The service response is b64 encoded in the body </returns>
        public async Task<Stream> RouteHandler(Stream jodiRequestStream, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string httpMethod = string.Empty;
            string uri = string.Empty;
            string requestID = string.Empty;

            JODIRequest request = null;
            JODIResponse response = null;
            MemoryStream responseStream = new MemoryStream();

            try
            {
                request = SerializationAssistant.DeserializeJson<JODIRequest>(jodiRequestStream);

                if (request == null)
                    throw new Exception("Unable to deserialize to JODIRequest object.");


                request.Context?.TryGetValue("http-method", out httpMethod);
                request.Context?.TryGetValue("orig-path", out uri);
                request?.Context?.TryGetValue("request-id", out requestID);

                Logger = new LoggingAssistant(context.FunctionName, "FAMS.FEMAService", requestID, request.Params.Persona);
                UseCase.Logger = Logger;
                AlertUseCase.Logger = Logger;

                Method method = JODIAssistant.FindMethod(MethodLookup, request);

                //ROUTING LOGIC
                if (method != null)
                {
                    response = await method.InvokeFunction(request, context);
                }
                else
                {
                    string errorMsg = string.Format("Unknown path or invalid Http Method in JODI request. Path={0},SupportedPaths={1}|HttpMethod={2},Supported Methods=GET,POST",
                                              uri,
                                              string.Join(",", MethodLookup.Select(a => a.Path)),
                                              httpMethod);
                    throw new Exception(errorMsg);
                }

                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                responseStream.Position = 0;

                return responseStream;
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex,
                                       string.Format("Failure in the RouteHandler. JODIRequest={0}", JODIAssistant.StreamToJson(jodiRequestStream)),
                                       FunctionTimer.ElapsedMilliseconds);

                string accept = string.Empty, contentType = string.Empty;
                request?.Params?.Header?.TryGetValue("accept", out accept);
                request?.Params?.Header?.TryGetValue("content-type", out contentType);
                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                response = CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, requestID);
                SerializationAssistant.SerializeJson<JODIResponse>(response, responseStream);
                return responseStream;
            }
            finally
            {
                FunctionTimer.Stop();

                //dont want to log to CW for keep warm request
                if (!GlobalConfiguration.KEEP_WARM_CLOUDWATCH_EVENT_RULE.Equals(requestID, StringComparison.OrdinalIgnoreCase))
                {
                    if (GlobalConfiguration.LOG_JODI)
                    {
                        Logger.LogJsonObject<JODIRequest>(request);
                        Logger.LogJsonObject<JODIResponse>(response);
                    }

                    Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                }
            }
        }

        /// <summary>
        /// GET - retrieve vendor response by Company ID & Transaction ID
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. CompanyID + Transaction id come from queryString</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> GetHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string clientID = string.Empty, globalID = string.Empty, transactionID = string.Empty, accept = string.Empty, requestID = string.Empty;

            jodiRequest?.Context?.TryGetValue("request-id", out requestID);
            jodiRequest?.Params?.Persona?.TryGetValue("clientID", out clientID);
            jodiRequest?.Params?.Persona?.TryGetValue("globalID", out globalID);
            jodiRequest?.Params?.QueryString?.TryGetValue("transactionID", out transactionID);
            jodiRequest?.Params?.Header?.TryGetValue("accept", out accept);


            FEMAServiceResponse response = null;
            ConcurrentDictionary<string, string> metaData = new ConcurrentDictionary<string, string>();
            try
            {
                clientID = clientID?.ToLower();
                globalID = globalID?.ToLower();
                transactionID = transactionID?.ToLower();

                accept = JODIAssistant.SetValidAcceptType(accept, string.Empty);

                // var femaTrans = await UseCase.GetDynamoDBTransaction<TransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, transactionID);

                string responseS3Key = UseCase.BuildS3Key(GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION, transactionID, "json");

                GetObjectResponse getResponse = await UseCase.GetS3Object(GlobalConfiguration.S3_BUCKET, responseS3Key);
                foreach (var meta in getResponse.Metadata.Keys)
                {
                    metaData.GetOrAdd(meta, getResponse.Metadata[meta]);
                }


                if (UseCase.ValidateGETCall(metaData, globalID))
                {
                    using (StreamReader sr = new StreamReader(getResponse.ResponseStream))
                    {
                        string type = getResponse?.Headers?.ContentType ?? string.Empty;
                        response = SerializationAssistant.DeserializeJson<FEMAServiceResponse>(sr);
                    }
                }

                //if accept isn't a valid content type, set accept to content type of response saved in S3
                accept = JODIAssistant.SetValidAcceptType(accept, responseS3Key);

                if (response == null)
                {
                    Logger.LogMessage(string.Format("Service Response not found in S3. Key={0},Bucket={1}", responseS3Key, GlobalConfiguration.S3_BUCKET), FunctionTimer.ElapsedMilliseconds);

                    return new JODIResponse()
                    {
                        HttpStatus = (int)HttpStatusCode.NotFound
                    };
                }

                else
                    return new JODIResponse()
                    {
                        ContentType = accept,
                        HttpStatus = (int)HttpStatusCode.OK,
                        ResponseBody = JODIAssistant.SerializeBodyToB64<FEMAServiceResponse>(accept, response)
                    };


            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the GetHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred retrieving the response.", (int)HttpStatusCode.InternalServerError, accept, requestID);
            }
            finally
            {
                FunctionTimer.Stop();

                Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
            }
        }


        /// <summary>
        /// POST - make request to vendor and map to service response
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. The actual service request is b64 encoded in the  body</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> PostHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            IVendorResponse vendorResponse = null;

            HttpResponseMessage httpResponse = null;
            VendorCall vendorCall = null;

            TransactionRecord<VendorCall> femaTrans = new TransactionRecord<VendorCall>();
            List<string> addOns = new List<string>();

            FEMAServiceRequest serviceRequest = UseCase.GetServiceRequestFromJODI<FEMAServiceRequest>(jodiRequest, FunctionTimer);

            string clientID = null, globalID = null, portalCode = null, requestID = null, accept = null, contentType = null, applicationPlan = null, companyName = null;
            string CorrelationToken = null; ;

            try
            {
                string serviceFileType = "json"; // JODIAssistant.GetFileType(jodiRequest.BodyType).ToString().ToLower();
                string vendorFileType = "json";

                jodiRequest?.Context?.TryGetValue("request-id", out requestID);
                applicationPlan = UseCase.GetAppPlan(jodiRequest);
                 requestID = requestID.ToLower();
                femaTrans.TransactionID = requestID;

                jodiRequest?.Params?.Header?.TryGetValue("accept", out accept);
                jodiRequest?.Params?.Header?.TryGetValue("content-type", out contentType);

                accept = JODIAssistant.SetValidAcceptType(accept, contentType);

                if (serviceRequest == null)
                    return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, accept, femaTrans.TransactionID);

                //Get Persona Info
                jodiRequest.Params?.Persona?.TryGetValue("companyName", out companyName);
                jodiRequest.Params?.Persona?.TryGetValue("clientID", out clientID);
                jodiRequest.Params?.Persona?.TryGetValue("globalID", out globalID);
                jodiRequest.Params?.Persona?.TryGetValue("portalCode", out portalCode);
                jodiRequest.Params.Header?.TryGetValue("correlationtoken", out CorrelationToken);

                clientID = clientID?.ToLower();
                globalID = globalID?.ToLower();
                requestID = requestID?.ToLower();
                portalCode = portalCode?.ToLower();

                var metaData = new Dictionary<string, string>() { { "x-amz-meta-globalid", globalID } };

                femaTrans.AppPlan = applicationPlan;
                femaTrans.CompanyName = companyName;
                femaTrans.RequestorID = serviceRequest?.RequestorID;
                femaTrans.ClientID = clientID;
                femaTrans.GlobalID = globalID;
                femaTrans.PortalCode = portalCode;
                femaTrans.ServiceName = GlobalConfiguration.SERVICE_ZONE_NAME;
                femaTrans.BucketName = GlobalConfiguration.S3_BUCKET;


                if (!UseCase.IsPersonaValid(femaTrans))
                    return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, femaTrans.TransactionID);

                femaTrans.RequestS3Key = UseCase.BuildS3Key(GlobalConfiguration.SERVICE_REQUEST_FOLDER, API_VERSION, femaTrans.TransactionID, serviceFileType);
                await UseCase.SaveToS3Bucket<FEMAServiceRequest>(serviceRequest, GlobalConfiguration.S3_BUCKET, femaTrans.RequestS3Key, GlobalConfiguration.KMS_KEY_ID, metaData);

                // ServiceConfiguration serviceConfig = await UseCase.GetServiceConfiguration(GlobalConfiguration.S3_BUCKET, GlobalConfiguration.VENDOR_CONFIG_FOLDER, femaTrans.PortalCode, GlobalConfiguration.ENVIRONMENT);
                Dictionary<string, FEMAService.core.Models.VendorConfiguration> serviceConfig = UseCase.GetVendorConfiguration();
                if (serviceConfig == null)
                    throw new Exception(string.Format("No service configuration file found. Bucket={0},Folder={1},PortalCode={2}", GlobalConfiguration.S3_BUCKET, GlobalConfiguration.VENDOR_CONFIG_FOLDER, femaTrans.PortalCode));

                FEMAService.core.Models.VendorConfiguration vendorConfig = serviceConfig["FEMA"];
                if (vendorConfig == null)
                    throw new Exception(string.Format("No FEMA vendor configuration found in service config. Bucket={0},Folder={1},PortalCode={2}", GlobalConfiguration.S3_BUCKET, GlobalConfiguration.VENDOR_CONFIG_FOLDER, femaTrans.PortalCode));

                UseCase.SetVendor(vendorConfig.VendorCode);

                HttpClient client = UseCase.InitializeHttpClient(HttpClients, vendorConfig, portalCode);

                if (UseCase.IsMockRequest(serviceRequest, applicationPlan))
                {
                    femaTrans.DataSource = DataSource.Mock.ToString();

                    //check for mock by mock key
                    vendorResponse = await UseCase.VendorSpecific.GetMockedResponseFromS3(GlobalConfiguration.S3_BUCKET,
                                                                           UseCase.BuildS3Key(GlobalConfiguration.MOCK_RESPONSE_FOLDER,
                                                                                              API_VERSION, vendorConfig.VendorCode + "/" + UseCase.ComputeMockKey(serviceRequest),
                                                                                              vendorFileType));

                    //no mock response found(expired or never created)
                    if (vendorResponse == null)
                    {
                        femaTrans.HttpStatus = (int)HttpStatusCode.NotFound;
                        return new JODIResponse()
                        {
                            HttpStatus = (int)HttpStatusCode.NotFound
                        };
                    }
                }
                else
                {
                    //validate request
                    var validationErrorResponse = UseCase.BuildValidationErrorResponse(serviceRequest, femaTrans, FunctionTimer);
                    if (validationErrorResponse != null)
                        return validationErrorResponse;

                    //normalize address if no county in request
                    NormalizedAddress normalizedAddress = null;
                    if (string.IsNullOrWhiteSpace(serviceRequest.Address.County))
                    {
                        normalizedAddress = await UseCase.NormalizeAddress(client, GlobalConfiguration.NORMALIZED_ADDRESS_URL,
                                                                     serviceRequest.Address.StreetAddress1,
                                                                     serviceRequest.Address.StreetAddress2,
                                                                     serviceRequest.Address.City,
                                                                     serviceRequest.Address.State,
                                                                     serviceRequest.Address.ZipCode);

                        serviceRequest.Address.County = normalizedAddress.County;
                    }

                    IVendorRequest vendorRequest = UseCase.VendorSpecific.MapServiceRequestToVendorRequest(serviceRequest, vendorConfig, normalizedAddress);
                    femaTrans.CacheKey = UseCase.ComputeCacheKey(femaTrans.GlobalID, serviceRequest);

                    //check cache
                    var cacheLimit = serviceRequest.CachePeriod != null ? serviceRequest.CachePeriod : vendorConfig.CachePeriodDays;

                    vendorResponse = await UseCase.VendorSpecific.SearchS3ForResponse(GlobalConfiguration.S3_BUCKET,
                                                                                      UseCase.BuildS3Key(GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, femaTrans.CacheKey, vendorFileType),
                                                                                      false,
                                                                                      cacheLimit);

                    if (vendorResponse == null) //no cache
                    {
                        femaTrans.DataSource = DataSource.Vendor.ToString();

                        vendorCall = new VendorCall
                        {
                            Name = vendorConfig.VendorCode + " " + vendorConfig.VendorProduct,
                            Sequence = 1,
                            RequestS3Key = UseCase.BuildS3Key(GlobalConfiguration.VENDOR_REQUEST_FOLDER, API_VERSION, femaTrans.CacheKey, vendorFileType),
                            DateTimeUTC = DateTime.UtcNow
                        };


                        await UseCase.VendorSpecific.SaveRequestToS3(vendorRequest, GlobalConfiguration.S3_BUCKET, vendorCall.RequestS3Key, GlobalConfiguration.KMS_KEY_ID);
                        httpResponse = await UseCase.CallVendor(client, vendorRequest, vendorConfig, vendorCall);
                        vendorCall.HttpStatus = (int)httpResponse.StatusCode;
                        vendorCall.ResponseS3Key = UseCase.BuildS3Key(GlobalConfiguration.VENDOR_RESPONSE_FOLDER, API_VERSION, femaTrans.CacheKey, vendorFileType);

                        //always save vendor response.
                        string content = await httpResponse.Content.ReadAsStringAsync();
                        if (httpResponse.IsSuccessStatusCode)
                        {
                            vendorResponse = UseCase.VendorSpecific.MapToVendorResponse(content);
                            await UseCase.VendorSpecific.SaveResponseToS3(vendorResponse, GlobalConfiguration.S3_BUCKET, vendorCall.ResponseS3Key, GlobalConfiguration.KMS_KEY_ID, vendorConfig.CachePeriodDays);
                        }
                        else
                        {
                            await UseCase.SaveToS3<string>(content, GlobalConfiguration.S3_BUCKET, vendorCall.ResponseS3Key, GlobalConfiguration.KMS_KEY_ID, vendorConfig.CachePeriodDays);

                            //throw exception if vendor call fails
                            throw new Exception(string.Format("Failure when calling {0}: {1}({2})", vendorCall.Name, (int)httpResponse.StatusCode, httpResponse.ReasonPhrase));
                        }
                    }
                    else //found cache
                    {
                        femaTrans.DataSource = DataSource.Cache.ToString();
                    }
                }

                //create the service response from vendor or mocked response
                FEMAServiceResponse serviceResponse = UseCase.VendorSpecific.CreateServiceResponseFromVendorResponse(vendorResponse, femaTrans.RequestorID, femaTrans.TransactionID, serviceRequest.Address);

                // Filter FEMA Response to exclude disaster prior to Filter Date if there is a Filter Date sent with the service request
                UseCase.FilterFEMAResponseByDate(serviceRequest, serviceResponse);

                if (serviceRequest.IncludeAnalytics)
                {
                    addOns.Add(AddOns.Analytics.ToString());
                    serviceResponse.Alerts = new List<Alert>();
                    AlertUseCase.ExecuteAlerts(serviceRequest, serviceResponse);
                }

                femaTrans.ResponseS3Key = UseCase.BuildS3Key(GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION, femaTrans.TransactionID, serviceFileType);
                femaTrans.HttpStatus = (int)HttpStatusCode.OK;
                await UseCase.SaveToS3Bucket<FEMAServiceResponse>(serviceResponse, GlobalConfiguration.S3_BUCKET, femaTrans.ResponseS3Key, GlobalConfiguration.KMS_KEY_ID, metaData);

                JODIResponse jodiResponse = jodiResponse = new JODIResponse()
                {
                    ContentType = accept,
                    HttpStatus = femaTrans.HttpStatus,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<FEMAServiceResponse>(accept, serviceResponse)
                };


                return jodiResponse;
            }
            catch (Exception ex)
            {
                //update status and log error
                femaTrans.HttpStatus = (int)HttpStatusCode.InternalServerError;
                Logger.LogServiceError(ex, "Failure in the PostHandler", FunctionTimer.ElapsedMilliseconds);
                Logger.LogServiceError(ex,
                                       String.Format("Failure in the PostHandler, Correlation-Token={0}", CorrelationToken),
                                       FunctionTimer.ElapsedMilliseconds, portalCode);

                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, accept, femaTrans.TransactionID);
            }
            finally
            {
                try
                {
                    FunctionTimer.Stop();
                    femaTrans.Elapsedms = FunctionTimer.ElapsedMilliseconds;
                    femaTrans.DateTimeUTC = DateTime.UtcNow;
                    femaTrans.VendorCalls = vendorCall != null ? new List<VendorCall> { vendorCall } : null;
                    femaTrans.AddOns = addOns;

                    await UseCase.SaveDynamoDBTransaction<TransactionRecord<VendorCall>>(GlobalConfiguration.DYNAMO_TABLE, femaTrans, femaTrans.TransactionID);
                }
                finally
                {
                    Logger.LogFunctionExecutionTime(FunctionTimer.ElapsedMilliseconds);
                    Logger.LogMessage(string.Format("Correlation-Token:{0}", CorrelationToken), FunctionTimer.ElapsedMilliseconds, portalCode);
                }
            }
        }


        /// <summary>
        /// A simple health check(check S3/Dynamo are active + make echotest call to vendor)
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - the health check doesn't need anything from the request</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  A 200 if all is up and running or a 500 if any issues</returns>
        private async Task<JODIResponse> HealthCheckHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            string contentType = "application/json";
            string portalCode = "HEALTHCHECK";

            try
            {
                HealthCheck healthCheck = await UseCase.RunHealthCheck(GlobalConfiguration.SERVICE_ZONE_NAME, GlobalConfiguration.S3_BUCKET, GlobalConfiguration.DYNAMO_TABLE);

                Dictionary<string, FEMAService.core.Models.VendorConfiguration> config = UseCase.GetVendorConfiguration();

                FEMAService.core.Models.VendorConfiguration vendorConfig = config["FEMA"];
                UseCase.SetVendor(vendorConfig.VendorCode);

                //vendor tests
                HttpClient client = UseCase.InitializeHttpClient(HttpClients, vendorConfig, portalCode);
                Task<HealthCheckComponent> v1 = UseCase.VendorSpecific.HealthCheck(client, vendorConfig);
                Task<HealthCheckComponent> v2 = UseCase.NormalizeAddressHealth(client, GlobalConfiguration.NORMALIZED_ADDRESS_URL, "30005 ladyface ct.", null, "Agoura Hills", "CA", "93065");
                await Task.WhenAll(new Task[] { v1, v2 });

                healthCheck.Components.TryAdd("VendorCall", v1.Result);
                healthCheck.Components.TryAdd("UtilityCall", v2.Result);

                bool errors = false;

                foreach (var comp in healthCheck.Components)
                {
                    if (comp.Value.Status == ComponentStatus.Red)
                    {
                        errors = true;
                        healthCheck.ServiceStatus = ComponentStatus.Red;
                        break;
                    }
                }


                return new JODIResponse()
                {
                    HttpStatus = errors ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK,
                    ContentType = "application/json",
                    ResponseBody = JODIAssistant.SerializeBodyToB64<HealthCheck>(contentType, healthCheck)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Health check failed", -1);

                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, "health");
            }
        }

        private async Task<JODIResponse> PingHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            return JODIAssistant.SetPingTestResponse();
        }


        /// <summary>
        /// Creates mock vendor responses and returns back the service request to get that mock response.
        /// </summary>
        /// <param name="request">A service mock object containing the service request + mocked vendor response</param>
        /// <param name="context"></param>
        /// <returns>The service request that was passed in. This will be used as the body of the POST request to the service.</returns>
        private async Task<JODIResponse> PostMockHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            string contentType = "application/json";

            FEMAServiceMock request = UseCase.GetServiceRequestFromJODI<FEMAServiceMock>(jodiRequest, FunctionTimer);

            if (request == null)
                return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, contentType, "mock");

            try
            {
                var vendorFileType = request.MockVendorResponse.StartsWith('<') ? "xml" : "json";

                string mockKey = UseCase.ComputeMockKey(request.MockServiceRequest);

                //saving as string so we can submit malformed data for testing purposes
                var mockVendorResponse = await UseCase.SaveToS3<string>(request.MockVendorResponse,
                                                                        GlobalConfiguration.S3_BUCKET,
                                                                        UseCase.BuildS3Key(GlobalConfiguration.MOCK_RESPONSE_FOLDER, API_VERSION, (request.VendorCode + "/" + mockKey), vendorFileType),
                                                                        GlobalConfiguration.KMS_KEY_ID);

                //create JODI response
                return new JODIResponse()
                {
                    ContentType = contentType,
                    HttpStatus = (int)HttpStatusCode.OK,
                    ResponseBody = JODIAssistant.SerializeBodyToB64<FEMAServiceRequest>(contentType, request.MockServiceRequest)
                };
            }
            catch (Exception ex)
            {
                Logger.LogServiceError(ex, "Failure in the PostMockHandler", FunctionTimer.ElapsedMilliseconds);

                return CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, "mock");
            }
            finally
            {
                FunctionTimer.Stop();
            }
        }

        #endregion

        #region Private Initializers

        private void InitializeHttpClient()
        {
            if (HttpClients == null)
            {
                lock (HttpClientLock)
                {
                    if (HttpClients == null)
                    {
                        HttpClients = new ConcurrentDictionary<string, HttpClient>();
                    }
                }
            }
        }

        private void InitializeMethodLookup()
        {
            if (MethodLookup == null)
            {
                lock (MethodLock)
                {
                    if (MethodLookup == null)
                    {
                        MethodLookup = new List<Method>();

                        Method getMethod = new Method
                        {
                            InvokeFunction = GetHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/report$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(getMethod);

                        Method postMethod = new Method
                        {
                            InvokeFunction = PostHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/order$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(postMethod);

                        Method healthMethod = new Method
                        {
                            InvokeFunction = HealthCheckHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/health$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(healthMethod);

                        Method pingMethod = new Method
                        {
                            InvokeFunction = PingHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.GET,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/ping", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(pingMethod);

                        Method mockMethod = new Method
                        {
                            InvokeFunction = PostMockHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/mock$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(mockMethod);
                        Method migrateMethod = new Method
                        {
                            InvokeFunction = PostFEMAResponseHandler,
                            Verb = Common.API.Models.Enums.HttpVerb.POST,
                            Path = string.Format(@"^(/v[0-9]+)?/{0}/migrate$", GlobalConfiguration.SERVICE_ZONE_NAME)
                        };
                        MethodLookup.Add(migrateMethod);
                    }
                }
            }

        }

        private JODIResponse CreateJODIErrorResponse(string errorMsg, int statusCode, string contentType, string transactionID)
        {
            return new JODIResponse()
            {
                ContentType = contentType,
                ErrorMessage = new JODIErrorResponse()
                {
                    Error = string.Format("{0}  TransactionID={1}", errorMsg, transactionID),
                    HttpStatus = statusCode
                }
            };
        }

        #endregion

        #region " Migrate Region --delete after migration is done"

        /// <summary>
        /// POST - make request to vendor and map to service response
        /// </summary>
        /// <param name="jodiRequest">Request from JODI - body is b64 encoded. The actual service request is b64 encoded in the  body</param>
        /// <param name="context"></param>
        /// <returns>A JODI response.  The service response is b64 encoded in the body </returns>
        private async Task<JODIResponse> PostFEMAResponseHandler(JODIRequest jodiRequest, ILambdaContext context)
        {
            Stopwatch FunctionTimer = new Stopwatch();
            FunctionTimer.Start();

            JODIResponse jodiResponse = new JODIResponse();
            FEMAServiceResponse serviceResponse = null;
            TransactionRecord<VendorCall> transaction = new TransactionRecord<VendorCall>();
            string accept = null;
            string contentType = "application/json";

            try
            {
                string serviceContentType = jodiRequest.BodyType;
                var persona = jodiRequest?.Params?.Persona;
                jodiRequest.Params.Persona.TryGetValue("clientID", out string clientID);
                jodiRequest.Params.Persona.TryGetValue("globalID", out string globalID);
                jodiRequest.Params.Persona.TryGetValue("portalCode", out string portalCode);

                jodiRequest.Context.TryGetValue("request-id", out string requestID);
                clientID = clientID?.ToLower();
                globalID = globalID?.ToLower();
                requestID = requestID?.ToLower();
                portalCode = portalCode?.ToLower();

                accept = JODIAssistant.SetValidAcceptType(accept, contentType);
                serviceResponse = JODIAssistant.DeserializeB64Body<FEMAServiceResponse>(jodiRequest.BodyType, jodiRequest.Body);
                string transactionID = !string.IsNullOrWhiteSpace(serviceResponse?.TransactionID) ? serviceResponse?.TransactionID : Guid.NewGuid().ToString();
                transactionID = transactionID.ToLower();
                transaction.TransactionID = transactionID;
                serviceResponse.TransactionID = transactionID;

                transaction.RequestorID = serviceResponse?.RequestorID;
                transaction.ClientID = clientID;
                transaction.GlobalID = globalID;
                transaction.PortalCode = portalCode;
                transaction.ExcludeFromBilling = true;
                transaction.DataSource = DataSource.Vendor.ToString();
                transaction.BucketName = GlobalConfiguration.S3_BUCKET;
                if (serviceResponse == null)
                    return CreateJODIErrorResponse("Invalid request body.", (int)HttpStatusCode.BadRequest, contentType, transaction.TransactionID);

                transaction.ResponseS3Key = UseCase.BuildS3Key(GlobalConfiguration.SERVICE_RESPONSE_FOLDER, API_VERSION, transaction.TransactionID, "json");
                transaction.HttpStatus = (int)HttpStatusCode.OK;
                var metaData = new Dictionary<string, string>() { { "x-amz-meta-globalid", globalID } };
                metaData.Add("x-amz-meta-transactionid", transaction.TransactionID);

                await UseCase.SaveToS3Bucket(serviceResponse, GlobalConfiguration.S3_BUCKET, transaction.ResponseS3Key, GlobalConfiguration.KMS_KEY_ID, metaData);

                jodiResponse.HttpStatus = (int)HttpStatusCode.OK;
                jodiResponse.ContentType = accept;
                jodiResponse.ResponseBody = JODIAssistant.SerializeBodyToB64(accept, serviceResponse);
            }

            catch (Exception ex)
            {
                FunctionTimer.Stop();
                Logger.LogServiceError(ex, "Unhandled exception in PostResponseHandler", FunctionTimer.ElapsedMilliseconds);
                jodiResponse = CreateJODIErrorResponse("An error has occurred.", (int)HttpStatusCode.InternalServerError, contentType, transaction.TransactionID);
            }

            return jodiResponse;
        }
        #endregion
    }
}

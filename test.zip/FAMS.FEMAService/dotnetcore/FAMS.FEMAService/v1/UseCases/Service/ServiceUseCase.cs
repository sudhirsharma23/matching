﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.Model;
using Amazon.S3;
using Amazon.S3.Model;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.Common.API.Models.JODI;
using FAMS.FEMAService.core;
using FAMS.FEMAService.core.Models;
using FAMS.FEMAService.v1.Models.Service;
using FAMS.FEMAService.v1.Models.Vendor;
using FAMS.FEMAService.v1.UseCases.Vendor;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace FAMS.BankruptycyService.v1.UseCases.Service
{
    public class ServiceUseCase
    {

        private IAmazonS3 _s3Client;
        private IAmazonDynamoDB _dbClient;
        private IDynamoDBContext _dbContext;
        private LoggingAssistant _logger;
        private IVendorUseCase _vendorSpecific;


        private VendorUseCaseFactory _vendorUseCaseFactory = new VendorUseCaseFactory();

        public LoggingAssistant Logger
        {
            get
            {
                return this._logger;
            }
            set
            {
                this._logger = value;
            }
        }

        public IVendorUseCase VendorSpecific
        {
            get
            {
                return this._vendorSpecific;
            }
        }

        public ServiceUseCase()
        {
            _s3Client = new AmazonS3Client();
            _dbClient = new AmazonDynamoDBClient();
            _dbContext = new DynamoDBContext(_dbClient);
        }

        public ServiceUseCase(IAmazonS3 s3Client, IAmazonDynamoDB dynamoClient)
        {
            _s3Client = s3Client;
            _dbClient = dynamoClient;
            _dbContext = new DynamoDBContext(_dbClient);
        }

        public void SetVendor(string vendor)
        {
            this._vendorSpecific = _vendorUseCaseFactory.CreateVendorUseCase(vendor, _s3Client, _logger);
        }

        public HttpClient InitializeHttpClient(ConcurrentDictionary<string, HttpClient> clients, FEMAService.core.Models.VendorConfiguration config, string portalCode)
        {
            HttpClient client = null;

            if (!clients.TryGetValue(portalCode, out client))
            {
                client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.Timeout = new TimeSpan(0, 0, config.TimeoutMS / 1000);

                clients.TryAdd(portalCode, client);
            }

            return client;
        }

        public async Task<HttpResponseMessage> CallVendor(HttpClient client, IVendorRequest vendorRequest, FEMAService.core.Models.VendorConfiguration config, VendorCall vendorCall)
        {
            HttpResponseMessage response = null;

            Stopwatch VendorWatch = new Stopwatch();
            VendorWatch.Start();

            try
            {
                response = await this._vendorSpecific.CallVendor(client, vendorRequest, config);
            }
            catch
            {
                Logger.LogVendorCall(vendorCall.Name, "Error calling Vendor (likely timeout). Exception caught in PostHandler", VendorWatch.ElapsedMilliseconds);
                throw;
            }
            finally //always log vendor call even if call throws exception
            {
                VendorWatch.Stop();

                if (vendorCall != null)
                {
                    Logger.LogVendorCall(vendorCall.Name,
                                                   string.Format("Calling Vendor.  URL={0},RequestS3Key={1}", config.URL, vendorCall.RequestS3Key),
                                                   VendorWatch.ElapsedMilliseconds);


                    vendorCall.Elapsedms = VendorWatch.ElapsedMilliseconds;
                }
            }

            return response;
        }

        public T GetServiceRequestFromJODI<T>(JODIRequest jodiRequest, Stopwatch functionTimer) where T : class
        {
            T request = null;

            try
            {
                request = JODIAssistant.DeserializeB64Body<T>(jodiRequest.BodyType, jodiRequest.Body);
            }
            catch (Exception ex)
            {
                _logger.LogServiceError(ex,
                                        string.Format("Failure to deserialize b64 body. Body={0}", jodiRequest.Body),
                                        functionTimer.ElapsedMilliseconds);
            }

            return request;
        }

        public JODIResponse BuildValidationErrorResponse(FEMAServiceRequest request, TransactionRecord<VendorCall> transaction, Stopwatch functionTimer)
        {
            JODIResponse response = null;

            string message = this._vendorSpecific.BuildValidationErrorMessage(request, transaction);

            if (!string.IsNullOrEmpty(message))
            {
                response = new JODIResponse()
                {
                    ErrorMessage = new JODIErrorResponse()
                    {
                        HttpStatus = (int)HttpStatusCode.BadRequest,
                        Error = message,
                    }
                };

                _logger.LogServiceError(new Exception(message),
                                                 "Request failed validation.",
                                                 functionTimer.ElapsedMilliseconds);
            }

            return response;
        }

        public string ComputeCacheKey(string globalID, FEMAServiceRequest request)
        {
            if (request == null)
                return null;

            string declarationDateFilter = string.Empty;
            if (request.Filters != null && request.Filters.ContainsKey("DeclarationDate") && request.Filters["DeclarationDate"] != null)
            {
                declarationDateFilter = request.Filters["DeclarationDate"];
            }


            byte[] hashValue = null;
            string key = string.Format("{0}|{1}|{2}", globalID, SerializationAssistant.SerializeJson(request.Address).Replace("\"\"", "null"), declarationDateFilter);
            key = new string(key.ToLower().ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());  //lowercase + remove whitespace

            UTF8Encoding enc = new UTF8Encoding();

            using (var sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(enc.GetBytes(key));
            }

            return BitConverter.ToString(hashValue).Replace("-", "");
        }

        public string ComputeMockKey(FEMAServiceRequest request)
        {
            if (request == null)
                return null;

            byte[] hashValue = null;
            string key = SerializationAssistant.SerializeJson(request.Address).Replace("\"\"", "null");
            key = new string(key.ToLower().ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());
            UTF8Encoding enc = new UTF8Encoding();

            using (var sha256 = SHA256.Create())
            {
                hashValue = sha256.ComputeHash(enc.GetBytes(key));
            }

            return BitConverter.ToString(hashValue).Replace("-", "");
        }

        public string BuildS3Key(string folder, string version, string name, string fileType)
        {
            if (string.IsNullOrEmpty(fileType))
                return string.Format("{0}/{1}/{2}", folder, version, name);
            else
                return string.Format("{0}/{1}/{2}.{3}", folder, version, name, fileType);
        }


        public Dictionary<string, FEMAService.core.Models.VendorConfiguration> GetVendorConfiguration()
        {
            var environment = GlobalConfiguration.ENVIRONMENT;

            var assembly = typeof(ServiceUseCase).GetTypeInfo().Assembly;

            string file = string.Format("FAMS.FEMAService.v1.Configs.Config.json");
            string resp = string.Empty;

            using (Stream resource = assembly.GetManifestResourceStream(file))
            {
                using (var reader = new StreamReader(resource))
                {
                    resp = reader.ReadToEnd();
                }
            }

            var portalConfig = JObject.Parse(resp);

            var defaultConfig = portalConfig["default"].ToObject<List<FEMAService.core.Models.VendorConfiguration>>();
            var envconfig = portalConfig[environment].ToObject<List<FEMAService.core.Models.VendorConfiguration>>();

            var dict = defaultConfig.ToDictionary(p => p.VendorCode);
            if (envconfig.Count > 0)
            {
                foreach (var configcode in envconfig)
                {
                    dict[configcode.VendorCode] = configcode;
                }
            }

            return dict;
        }

        public bool IsMockRequest(FEMAServiceRequest request, string applicationPlan)
        {
            if (!string.IsNullOrEmpty(applicationPlan) && applicationPlan.ToLower().StartsWith("mock"))
                return true;
            else if (!string.IsNullOrWhiteSpace(request.Address?.State) && request.Address.State.ToLower().StartsWith("z"))
                return true;
            else
                return false;
        }

        public async Task<PutObjectResponse> SaveToS3<T>(T document, string bucket, string key, string kmsKeyId, int cacheDays = 0, Dictionary<string, string> metaData = null)
        {
            PutObjectResponse response = null;

            try
            {
                response = await AWSAssistant.SaveToS3<T>(_s3Client, document, bucket, key, kmsKeyId, cacheDays,metaData);
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex, "Failure saving to S3", bucket, key);
                throw;
            }

            return response;
        }

        public async Task<PutObjectResponse> SaveToS3Bucket<T>(T document, string bucket, string key, string kmsKeyId, Dictionary<string, string> metaData, LifeSpan lifespan = LifeSpan.SevenYears)
        {
            PutObjectResponse response = null;

            try
            {
                response = await AWSAssistant.SaveToS3Bucket<T>(_s3Client, document, bucket, key, kmsKeyId, metaData, lifespan);
            }
            catch (Exception ex)
            {
                Logger.LogS3Error(ex, "Failure saving to S3", bucket, key);
                throw;
            }

            return response;
        }

        public async Task<GetObjectResponse> GetS3Object(string bucket, string key)
        {
            GetObjectResponse getResponse  = null;
            getResponse = await AWSAssistant.GetS3Object(_s3Client, bucket, key);

            return getResponse;
        }

        public async Task<T> SearchS3ByKey<T>(string bucket, string key, bool log404Error = false, int? cacheLimit = null)
        {
            T document = default(T);

            try
            {
                document = await AWSAssistant.SearchS3ByKey<T>(_s3Client, bucket, key, log404Error, cacheLimit);
            }
            catch (AmazonS3Exception ex)
            {
                //Some cases 404 is OK like when we are just searching for a key
                if (log404Error || ex.StatusCode != HttpStatusCode.NotFound)
                {
                    _logger.LogS3Error(ex,
                                       cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                       bucket,
                                       key);

                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogS3Error(ex,
                                   cacheLimit == null ? "Failure searching S3" : string.Format("Failure searching S3 for cached response. CacheLimitDays={0}", cacheLimit),
                                   bucket,
                                   key);

                throw;
            }

            return document;
        }

        public async Task SaveDynamoDBTransaction<T>(string table, T trans, string hashKey)
        {
            try
            {
                await AWSAssistant.SaveToDynamoDB<T>(_dbContext, table, trans, hashKey);
            }
            catch (Exception ex)
            {
                _logger.LogDynamoError(ex, "Failure saving transaction to DynamoDB", hashKey, table);
                _logger.LogJsonObject<T>(trans);

                throw;
            }
        }

        public async Task<T> GetDynamoDBTransaction<T>(string table, string hashKey)
        {
            T transaction = default(T);

            try
            {
                transaction = await AWSAssistant.GetFromDynamoDB<T>(_dbContext, table, hashKey);
            }
            catch (Exception ex)
            {
                _logger.LogDynamoError(ex, "Failure retrieving transaction from DynamoDB", table);

                throw;
            }

            return transaction;
        }

        public async Task<DescribeTableResponse> GetDynamoDBTableInfo(string table)
        {
            DescribeTableResponse response = null;

            try
            {
                response = await _dbClient.DescribeTableAsync(table);
            }
            catch (Exception ex)
            {
                _logger.LogDynamoError(ex, "Failure getting table info from DynamoDB", table);

                throw;
            }

            return response;
        }

        public bool IsPersonaValid(TransactionRecord<VendorCall> femaTrans)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();


            if (string.IsNullOrEmpty(femaTrans.ClientID))
                sb.Append("ClientID is a required field.");

            if (string.IsNullOrEmpty(femaTrans.PortalCode))
                sb.Append("PortalCode is a required field.");

            if (string.IsNullOrEmpty(femaTrans.GlobalID))
                sb.Append("GlobalID is a required field.");

            string msg = sb.ToString();

            if (!string.IsNullOrEmpty(msg))
            {
                _logger.LogServiceError(new Exception("Persona is missing/invalid"), msg, -1);
                valid = false;
            }

            return valid;
        }

        public async Task<HealthCheck> RunHealthCheck(string service, string bucket, string table)
        {
            HealthCheck healthCheck = new HealthCheck(service);
            await healthCheck.VerifyS3AndDynamo(_s3Client, bucket, _dbClient, table);
            return healthCheck;
        }

        public async Task<NormalizedAddress> NormalizeAddress(HttpClient httpClient, string normalizedAddressUrl, string streetAddress1, string streetAddress2, string city, string state, string zip)
        {
            NormalizedAddress normalizedAddress = null;

            string addressLine = string.Format("{0} {1}", streetAddress1, streetAddress2).Trim();
            string cityStateZip = string.Format("{0}, {1} {2}", city, state, zip).Trim();
            string url = string.Format(normalizedAddressUrl
                                        , HttpUtility.UrlEncode(addressLine)
                                        , HttpUtility.UrlEncode(cityStateZip));

            using (var response = await httpClient.GetAsync(url))
            {
                if (response == null || !response.IsSuccessStatusCode)
                    throw new Exception(string.Format("Address normalization failed. Address={0}, CityStateZip={1}", addressLine, cityStateZip));

                normalizedAddress = SerializationAssistant.DeserializeJson<NormalizedAddress>(await response.Content.ReadAsStreamAsync());
            }

            return normalizedAddress;
        }

        public async Task<HealthCheckComponent> NormalizeAddressHealth(HttpClient httpClient, string normalizedAddressUrl, string streetAddress1, string streetAddress2, string city, string state, string zip)
        {
            NormalizedAddress normalizedAddress = null;

            string addressLine = string.Format("{0} {1}", streetAddress1, streetAddress2).Trim();
            string cityStateZip = string.Format("{0}, {1} {2}", city, state, zip).Trim();
            string url = string.Format(normalizedAddressUrl
                                        , HttpUtility.UrlEncode(addressLine)
                                        , HttpUtility.UrlEncode(cityStateZip));

            HealthCheckComponent addressComponent = new HealthCheckComponent()
            {
                Name = "NormalizeAddress",
                Type = ComponentType.Infrastructure
            };


            Stopwatch s1 = new Stopwatch();
            s1.Start();
            using (var response = await httpClient.GetAsync(url))
            {
                s1.Stop();

                addressComponent.Information = new Dictionary<string, string>()
                {
                    {"URL", url },
                    {"ResponseStatus", ((int)response.StatusCode).ToString() },
                    {"ResponseTimeMS", s1.ElapsedMilliseconds.ToString() }
                };



                if (response == null || !response.IsSuccessStatusCode)
                {
                    addressComponent.Status = ComponentStatus.Red;
                    addressComponent.Information.Add("Error", $"Address normalization call failed. Address={addressLine}, CityStateZip={cityStateZip}");
                }

                normalizedAddress = SerializationAssistant.DeserializeJson<NormalizedAddress>(await response.Content.ReadAsStreamAsync());

                if (normalizedAddress == null)
                {
                    addressComponent.Status = ComponentStatus.Red;
                    addressComponent.Information.Add("Error", $"Failed to deserialize address. Address={addressLine}, CityStateZip={cityStateZip}");

                }

                if (!normalizedAddress.County.Equals("Los Angeles"))
                {
                    addressComponent.Status = ComponentStatus.Red;
                    addressComponent.Information.Add("Error", $"Incorrect data from normalized address. Address={addressLine}, CityStateZip={cityStateZip}");
                }
            }

            return addressComponent;
        }

        public string GetAppPlan(JODIRequest jodiRequest)
        {
            string appPlan = string.Empty;
            string applicationPlan = string.Empty;

            if (jodiRequest.Context != null && jodiRequest.Context.TryGetValue("application-plan", out applicationPlan))
                appPlan = applicationPlan;
            else if (jodiRequest.Params != null && jodiRequest.Params.Header.TryGetValue("application-plan", out applicationPlan))
                appPlan = applicationPlan;

            return applicationPlan;
        }

        public bool ValidateGETCall(ConcurrentDictionary<string, string> metaData, string globalID)
        {
            bool isValid = false;


            if (!string.IsNullOrWhiteSpace(GlobalConfiguration.GATEWAY_NAME) && GlobalConfiguration.GATEWAY_NAME.Equals("private", StringComparison.OrdinalIgnoreCase))
            {
                isValid = true;
            }
            else
            {
                if (metaData["x-amz-meta-globalid"].Equals(globalID, StringComparison.OrdinalIgnoreCase))
                {
                    isValid = true;
                }
            }

            return isValid;
        }

        public bool ValidateGETCall(TransactionRecord<VendorCall> transaction, string globalID)
        {
            bool isValid = false;
            bool isValidGateway = false;

            if (!string.IsNullOrWhiteSpace(GlobalConfiguration.GATEWAY_NAME) && GlobalConfiguration.GATEWAY_NAME.Equals("private", StringComparison.OrdinalIgnoreCase))
            {
                isValidGateway = true;
            }
            else
            {
                if (transaction.GlobalID.Equals(globalID, StringComparison.OrdinalIgnoreCase))
                {
                    isValidGateway = true;
                }
            }

            if (!string.IsNullOrWhiteSpace(transaction?.ResponseS3Key) && transaction.HttpStatus == 200 && isValidGateway)
            {
                isValid = true;
            }
            return isValid;
        }

        public void FilterFEMAResponseByDate(FEMAServiceRequest serviceRequest, FEMAServiceResponse serviceResponse)
        {
            if (serviceResponse?.Disasters != null && serviceResponse.Disasters.Any() && serviceRequest.Filters != null && serviceRequest.Filters.ContainsKey("DeclarationDate") && serviceRequest.Filters["DeclarationDate"] != null)
            {
                DateTime declarationDateFilter = DateTime.MinValue;
                if (DateTime.TryParse(serviceRequest.Filters["DeclarationDate"], out declarationDateFilter) && declarationDateFilter != DateTime.MinValue)
                {
                    serviceResponse.Disasters.RemoveAll(x =>
                    {
                        if (x?.DeclarationDate == null)
                            return true;

                        DateTime declarationDate = GetFEMADeclarationDate(x.DeclarationDate.Year, x.DeclarationDate.Month, x.DeclarationDate.Day);
                        if (declarationDate >= declarationDateFilter)
                            return false;

                        return true;
                    });
                }
            }
        }

        private DateTime GetFEMADeclarationDate(int? year, int? month, int? day)
        {
            DateTime dDate = DateTime.MinValue;

            if (day == null || day <= 0)
                day = 30;

            if (month == null || month <= 0)
                month = 12;

            if (year != null && year > 0)
            {
                dDate = new DateTime((int)year, (int)month, (int)day);
            }

            return dDate;
        }
    }
}

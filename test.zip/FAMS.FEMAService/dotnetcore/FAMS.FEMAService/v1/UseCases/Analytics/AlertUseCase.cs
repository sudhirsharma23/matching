﻿using FAMS.Common.API.Assistants;
using FAMS.FEMAService.v1.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace FAMS.FEMAService.v1.UseCases.Analytics
{
    public class AlertUseCase
    {
        public AlertUseCase()
        {
            InitializeAlertTypes();
        }

        public LoggingAssistant Logger
        {
            get
            {
                return this._logger;
            }
            set
            {
                this._logger = value;
            }
        }

        public void ExecuteAlerts(FEMAServiceRequest serviceRequest, FEMAServiceResponse serviceResponse)
        {
            var alertRules = new List<AlertRule>();

            foreach (var type in AlertTypes)
            {
                var alert = (AlertRule)Activator.CreateInstance(type);

                alertRules.Add(alert);
            }

            Parallel.ForEach(alertRules, alert =>
            {
                try
                {
                    alert.Execute(serviceRequest, serviceResponse, Logger);
                }
                catch (Exception ex)
                {
                    Logger.LogServiceError(ex, string.Format("Analytics failed."), 0);
                }
            });
        }

        #region Private Helpers

        private LoggingAssistant _logger;

        private static List<Type> AlertTypes;
        private static object AlertTypesLock = new object();

        private void InitializeAlertTypes()
        {
            if (AlertTypes == null)
            {
                lock (AlertTypesLock)
                {
                    if (AlertTypes == null)
                    {
                        string ns = string.Format("FAMS.FEMAService.v1.Alerts");

                        AlertTypes = Assembly.GetExecutingAssembly()
                                            .GetTypes()
                                            .Where(t => t.Namespace.Equals(ns, StringComparison.OrdinalIgnoreCase) && t.IsSubclassOf(typeof(AlertRule)) && !t.IsAbstract)
                                            .ToList();
                    }
                }
            }
        }

        #endregion
    }
}

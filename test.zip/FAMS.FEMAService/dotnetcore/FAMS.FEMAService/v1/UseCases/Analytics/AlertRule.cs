﻿using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.FEMAService.v1.Models.Service;
using System.Collections.Generic;

namespace FAMS.FEMAService.v1.UseCases.Analytics
{
    public abstract class AlertRule
    {
        public void Execute(FEMAServiceRequest serviceRequest, FEMAServiceResponse serviceResponse, LoggingAssistant logger)
        {
            ExecuteLogic(serviceRequest, serviceResponse, logger);
        }

        public abstract void ExecuteLogic(FEMAServiceRequest serviceRequest, FEMAServiceResponse serviceResponse, LoggingAssistant logger);
    }
}

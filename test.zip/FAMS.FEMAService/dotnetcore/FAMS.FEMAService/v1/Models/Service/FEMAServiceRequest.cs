﻿using FAMS.Common.API.Models;
using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using System.Collections.Generic;

namespace FAMS.FEMAService.v1.Models.Service
{
    public class FEMAServiceRequest : IAlertRequest
    {
        public string RequestorID { get; set; }
        public Address Address { get; set; }
        public bool IncludeAnalytics { get; set; }
        public int? CachePeriod { get; set; }
        public SerializableDictionary<string, object> AnalyticsInput { get; set; }
        public SerializableDictionary<string, string> Filters { get; set; }
    }
}

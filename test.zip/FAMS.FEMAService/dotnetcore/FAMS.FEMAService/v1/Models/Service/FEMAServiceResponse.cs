﻿using FAMS.Common.API.Models.Entities;
using FAMS.Common.API.Models.Infrastructure;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Serialization;

namespace FAMS.FEMAService.v1.Models.Service
{
    public class FEMAServiceResponse : IAlertResponse
    {
        public string TransactionID { get; set; }
        public string RequestorID { get; set; }
        public Address Address { get; set; }
        public ServiceResultType Result { get; set; }
        [XmlArrayItem("Disaster")]
        public List<FEMADisasterRecord> Disasters { get; set; }
        public List<Alert> Alerts { get; set; }
    }

    public class FEMADisasterRecord
    {
        public int DisasterNumber { get; set; }
        public bool IHProgramDeclared { get; set; }
        public bool IAProgramDeclared { get; set; }
        public bool PAProgramDeclared { get; set; }
        public bool HMProgramDeclared { get; set; }
        public string State { get; set; }
        public ParsedDate DeclarationDate { get; set; }
        public string DisasterType { get; set; }
        public string IncidentType { get; set; }
        public string Title { get; set; }
        public ParsedDate IncidentBeginDate { get; set; }
        public ParsedDate IncidentEndDate { get; set; }
        public ParsedDate DisasterCloseOutDate { get; set; }
        public int PlaceCode { get; set; }
        public string DeclaredCountyArea { get; set; }
        //public string Hash { get; set; }
        //public string LastRefresh { get; set; }
        //public string ID { get; set; }
    }

    public enum ServiceResultType
    {
        NoDisastersFound,
        DisastersFound
    }
}

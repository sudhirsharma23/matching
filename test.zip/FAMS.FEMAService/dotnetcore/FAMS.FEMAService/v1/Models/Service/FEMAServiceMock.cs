﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.FEMAService.v1.Models.Service
{
    public class FEMAServiceMock
    {
        public string VendorCode { get; set; }
        public FEMAServiceRequest MockServiceRequest { get; set; }
        public string MockVendorResponse { get; set; }
    }
}

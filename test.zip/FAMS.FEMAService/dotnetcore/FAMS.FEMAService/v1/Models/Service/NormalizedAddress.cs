﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;

namespace FAMS.FEMAService.v1.Models.Service
{
    [DataContract(Name = "NormalizedAddress", Namespace = "")]
    public class NormalizedAddress
    {

        /// <summary>
        /// StreetNumber of NormalizedAddress
        /// </summary>
        [DataMember]
        public string StreetNumber { get; set; }

        /// <summary>
        /// StreetPreDirection
        /// </summary>
        [DataMember]
        public string StreetPreDirection { get; set; }

        /// <summary>
        /// StreetName
        /// </summary>
        [DataMember]
        public string StreetName { get; set; }

        /// <summary>
        /// StreetType
        /// </summary>
        [DataMember]
        public string StreetType { get; set; }

        /// <summary>
        /// StreetPostDirection
        /// </summary>
        [DataMember]
        public string StreetPostDirection { get; set; }

        /// <summary>
        /// UnitDesignation
        /// </summary>
        [DataMember]
        public string UnitDesignation { get; set; }

        /// <summary>
        /// UnitNumber
        /// </summary>
        [DataMember]
        public string UnitNumber { get; set; }

        /// <summary>
        /// City  of NormalizedAddress
        /// </summary>
        [DataMember]
        public string City { get; set; }

        /// <summary>
        /// State  of NormalizedAddress
        /// </summary>
        [DataMember]
        public string State { get; set; }

        /// <summary>
        /// Zipcode  of NormalizedAddress
        /// </summary>
        [DataMember]
        public string Zipcode { get; set; }

        /// <summary>
        /// ZipcodePlus
        /// </summary>
        [DataMember]
        public string ZipcodePlus { get; set; }

        /// <summary>
        /// County of NormalizedAddress
        /// </summary>
        [DataMember]
        public string County { get; set; }

        /// <summary>
        /// DPVIndicator
        /// </summary>
        [DataMember]
        public string DPVIndicator { get; set; }

        /// <summary>
        /// DPVIsCMRA
        /// </summary>
        [DataMember]
        [JsonConverter(typeof(DPVIsCMRAConverter))]
        public long DPVIsCMRA { get; set; }

        /// <summary>
        /// Latitude  of NormalizedAddress
        /// </summary>
        [DataMember]
        [JsonConverter(typeof(NullableDecimalConverter))]
        public decimal Latitude { get; set; }

        /// <summary>
        /// Longitude of NormalizedAddress
        /// </summary>
        [DataMember]
        [JsonConverter(typeof(NullableDecimalConverter))]
        public decimal Longitude { get; set; }

        /// <summary>
        /// Error Code of NormalizedAddress
        /// </summary>
        [DataMember]
        public string ErrorCode { get; set; }


        private string _NormalizedAddressHash;

        [DataMember]
        public string NormalizedAddressHash
        {
            get
            {
                if (string.IsNullOrEmpty(_NormalizedAddressHash))
                {
                    _NormalizedAddressHash = GetNormalizedAddressHash();
                }
                return _NormalizedAddressHash;
            }
            set { _NormalizedAddressHash = value; }
        }

        private string GetNormalizedAddressHash()
        {
            string normalizedAddress = string.Format("{0}{1}{2}{3}{4}{5}{6}{7}{8}",
                this.StreetNumber, this.StreetPreDirection, this.StreetName, this.StreetType,
                this.StreetPostDirection, this.UnitNumber, this.City, this.State,
                this.Zipcode)?.ToLower();

            StringBuilder normalizedAddressHash = new StringBuilder();

            using (SHA512 sha1 = SHA512.Create())
            {
                byte[] hashData = sha1.ComputeHash(Encoding.Default.GetBytes(normalizedAddress));

                for (int i = 0; i < hashData.Length; i++)
                {
                    normalizedAddressHash.Append(hashData[i].ToString("X2"));
                }
            }

            return normalizedAddressHash.ToString();
        }
    }

    public class DPVIsCMRAConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(bool) || objectType == typeof(long);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            long TRUE = -1;
            long FALSE = 0;

            object value = reader.Value;

            if (value != null)
            {
                if (bool.TryParse(value.ToString(), out bool boolValue))
                {
                    return boolValue ? TRUE : FALSE;
                }
                else if (long.TryParse(value.ToString(), out long val))
                {
                    return val;
                }
            }

            return 0;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            writer.WriteValue(value);
        }
    }

    public class NullableDecimalConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return true;
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.Value != null && decimal.TryParse(reader.Value.ToString(), out decimal val))
                return val;

            return (decimal)0;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            writer.WriteValue(value);
        }
    }
}

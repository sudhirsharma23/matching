﻿using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.Enums;
using FAMS.Common.API.Models.Infrastructure;
using FAMS.FEMAService.v1.Models.Service;
using FAMS.FEMAService.v1.UseCases.Analytics;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;

namespace FAMS.FEMAService.v1.Alerts
{
    public class FEMA : AlertRule
    {
        private const string ALERT_CODE = "FEMA";
        private const string ALERT_DESC = "FEMA - The Federal Emergency Management Agency has declared the following disaster(s) in the vicinity of the property address location.";

        private Alert AlertResult;

        public FEMA()
        {
            AlertResult = new Alert()
            {
                Code = ALERT_CODE,
                Description = ALERT_DESC,
                Status = Status.NotEvaluated,
                Evidence = new List<SerializableDictionary<string, object>>()
            };
        }

        public override void ExecuteLogic(FEMAServiceRequest serviceRequest, FEMAServiceResponse serviceResponse, LoggingAssistant logger)
        {
            List<SerializableDictionary<string, object>> evidenceList = new List<SerializableDictionary<string, object>>();
            List<dynamic> facts = new List<dynamic>();
            AlertResult.Status = Status.NotFired;

            if (serviceResponse != null && serviceResponse.Result == ServiceResultType.DisastersFound && serviceResponse.Disasters != null && serviceResponse.Disasters.Count > 0)
            {
                foreach (var disaster in serviceResponse.Disasters)
                {
                    SerializableDictionary<string, object> evidence = new SerializableDictionary<string, object>();
                    dynamic alertFacts = new ExpandoObject();

                    try
                    {
                        DateTime transactionDate = DateTime.Today;
                        alertFacts.ExternalScoreCode = ALERT_CODE;
                        alertFacts.TransactionDate = transactionDate;

                        alertFacts.LogicStep = 1;
                        alertFacts.LogicExp = "Check incident start and end date";

                        string startDate = string.Format("{0}/{1}/{2}", disaster.IncidentBeginDate.Month, disaster.IncidentBeginDate.Day, disaster.IncidentBeginDate.Year);
                        string endDate = string.Format("{0}/{1}/{2}", disaster.IncidentEndDate.Month, disaster.IncidentEndDate.Day, disaster.IncidentEndDate.Year);

                        DateTime.TryParse(startDate, out DateTime incidentStartDate);
                        DateTime.TryParse(endDate, out DateTime incidentEndDate);

                        if (transactionDate >= incidentStartDate && (transactionDate <= incidentEndDate || incidentEndDate == DateTime.MinValue))
                        {
                            alertFacts.Status = AlertResult.Status = Status.Fired;
                            alertFacts.Reason = string.Format("The transaction date ({0}) is between the incident start date ({1}) and incident end date ({2}).", transactionDate.ToShortDateString(), incidentStartDate.ToShortDateString(), incidentEndDate.ToShortDateString());

                            evidence.Add("DisasterNumber", disaster.DisasterNumber);
                            evidence.Add("IncidentType", disaster.IncidentType);
                            evidence.Add("TransactionDate", transactionDate.ToShortDateString());
                            evidence.Add("IncidentStartDate", incidentStartDate.ToShortDateString());
                            evidence.Add("IncidentEndDate", incidentEndDate.ToShortDateString());
                            evidenceList.Add(evidence);
                        }
                        else
                        {
                            alertFacts.Reason = string.Format("The transaction date ({0}) is not between the incident start date ({1}) and incident end date ({2}).", transactionDate.ToShortDateString(), incidentStartDate.ToShortDateString(), incidentEndDate.ToShortDateString());
                        }
                    }
                    catch (Exception ex)
                    {
                        alertFacts.Error = ex.Message;
                        string msg = string.Format("Error running FEMA alert, {0}.", ALERT_CODE);
                        logger.LogServiceError(ex, msg, 0);
                    }
                    finally
                    {
                        alertFacts.Status = AlertResult.Status;
                        facts.Add(alertFacts);
                        AnalyticsAssistant.EmitAlertFacts(alertFacts, logger, ALERT_CODE);
                    }
                }
            }

            AlertResult.Evidence = (evidenceList.Count > 0) ? evidenceList : null;
            serviceResponse.Alerts.Add(AlertResult);
        }
    }
}
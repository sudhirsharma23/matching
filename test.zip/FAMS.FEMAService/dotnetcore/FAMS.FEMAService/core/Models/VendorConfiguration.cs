﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAMS.FEMAService.core.Models
{
    public class VendorConfiguration
    {
        public string VendorCode { get; set; }
        public string VendorProduct { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string URL { get; set; }
        public int TimeoutMS { get; set; }
        public int CachePeriodDays { get; set; } //default cache limit
        public Dictionary<string, string> Configurations { get; set; }
    }
}

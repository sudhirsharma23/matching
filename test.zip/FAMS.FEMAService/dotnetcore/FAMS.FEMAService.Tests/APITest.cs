using Amazon.DynamoDBv2;
using Amazon.Lambda.TestUtilities;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using Amazon.S3;
using FAMS.Common.API.Assistants;
using FAMS.Common.API.Models;
using FAMS.Common.API.Models.JODI;
using FAMS.FEMAService.v1;
using System;
using System.IO;
using System.Reflection;
using Xunit;

namespace FAMS.FEMAService.Tests
{
    public class APITest
    {
        AWSCredentials credentials;
        IAmazonS3 s3Client;
        IAmazonDynamoDB dbClient;

        private const string LAMBDA_NAME = "fema-lambda";

        public APITest()
        {
            //YOU WILL NEED TO CONFIGURE THIS FOR YOUR ENVIRONMENT
            credentials = GetAWSCredentialsFromProfile("sbx");
            s3Client = new AmazonS3Client(credentials, Amazon.RegionEndpoint.USWest2);
            dbClient = new AmazonDynamoDBClient(credentials, Amazon.RegionEndpoint.USWest2);

            Environment.SetEnvironmentVariable("S3_BUCKET", "sbx-fema-api-w2-humane-glowworm");
            Environment.SetEnvironmentVariable("DYNAMODB_TABLE", "sbx-fema-api-w2-humane-glowworm-fema-transactions");
            Environment.SetEnvironmentVariable("KMS_KEY_ID", "arn:aws:kms:us-west-2:666678657097:key/dc5730dd-5ea8-4486-b332-d06661a88fca");
            Environment.SetEnvironmentVariable("LOG_JODI", "false");
            Environment.SetEnvironmentVariable("ENVIRONMENT", "sbx");
            Environment.SetEnvironmentVariable("SERVICE_ZONE_NAME", "fema");
            Environment.SetEnvironmentVariable("KEEP_WARM_CLOUDWATCH_EVENT_RULE", "KeepWarmHealthCheck");
            Environment.SetEnvironmentVariable("NORMALIZED_ADDRESS_URL", "https://utils.rc.firstam.io/normalize/address?addressLine={0}&cityStateZip={1}");
        }

        [Fact]
        public async void TestRouteHandlerPOST()
        {
           string fileName = "Sample.json";
           //string fileName = "TRUSTEE.xml";

            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = ConvertServiceRequestToBase64("FAMS.FEMAService.Tests.SampleRequests", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/order", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    { "request-id", Guid.NewGuid().ToString() }
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                        //{"accept", "application/xml" },
                        //{"content-type", "application/xml" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerGET()
        {
            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/report", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    },
                    QueryString = new SerializableDictionary<string, string>()
                    {
                        {"transactionID", "<FILL IN>" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerHEALTH()
        {
            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = null,
                BodyType = null,
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "GET"},
                    { "orig-path", string.Format("/v1/{0}/health", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" },
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerPOSTMOCK()
        {
            string fileName = "MOCK.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = ConvertServiceRequestToBase64("FAMS.FEMAService.Tests.SampleMock", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/mock", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))}
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestAlert()
        {
            string fileName = "Sample.json";

            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = ConvertServiceRequestToBase64("FAMS.FEMAService.Tests.SampleRequests", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/order", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    { "request-id", Guid.NewGuid().ToString() }
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);

            // Invoke the lambda function
            var api = new API(s3Client, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            var ser = SerializationAssistant.DeserializeJson<JODIResponse>(routingResponse);

            Assert.True(ser.HttpStatus == 200);
            Assert.IsType<MemoryStream>(routingResponse);
        }

        [Fact]
        public async void TestRouteHandlerPOSTWithFilter()
        {
            string fileName = "SampleWithFilter.json";
            //string fileName = "TRUSTEE.xml";

            JODIRequest jr = new JODIRequest
            {
                Lambda = LAMBDA_NAME,
                Body = ConvertServiceRequestToBase64("FAMS.FEMAService.Tests.SampleRequests", fileName),
                BodyType = GetContentTypeFromFile(Path.GetExtension(fileName).ToLower()),
                Context = new SerializableDictionary<string, string>()
                {
                    { "http-method", "POST"},
                    { "orig-path", string.Format("/{0}/order", Environment.GetEnvironmentVariable("SERVICE_ZONE_NAME"))},
                    { "request-id", Guid.NewGuid().ToString() }
                },
                Params = new JODIRequestParams()
                {
                    Header = new SerializableDictionary<string, string>()
                    {
                        {"accept", "application/json" },
                        {"content-type", "application/json" }
                        //{"accept", "application/xml" },
                        //{"content-type", "application/xml" }
                    },
                    Persona = new SerializableDictionary<string, string>()
                    {
                        {"clientID", "JAKETEST" },
                        {"portalCode", "API" },
                        {"globalID", "TESTCO01" }
                    }
                }
            };

            MemoryStream responseStream = new MemoryStream();
            SerializationAssistant.SerializeJson<JODIRequest>(jr, responseStream);


            // Invoke the lambda function
            var api = new API(s3Client, dbClient);
            var context = new TestLambdaContext();
            context.FunctionName = LAMBDA_NAME;
            var routingResponse = await api.RouteHandler(responseStream, context);

            Assert.IsType<MemoryStream>(routingResponse);
        }

        private AWSCredentials GetAWSCredentialsFromProfile(string profile)
        {
            var credentialProfileStoreChain = new CredentialProfileStoreChain();

            if (credentialProfileStoreChain.TryGetAWSCredentials(profile, out AWSCredentials credentials))
                return credentials;
            else
                throw new AmazonClientException("Unable to find a " + profile + " profile in CredentialProfileStoreChain.");
        }

        private string ConvertServiceRequestToBase64(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);

            return Convert.ToBase64String(ms.ToArray());
        }

        private string ConvertServiceRequestToString(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);
            ms.Position = 0;

            var sr = new StreamReader(ms);
            return sr.ReadToEnd();
        }

        private MemoryStream ConvertServiceRequestToStream(string resourcePath, string fileName)
        {
            var assembly = typeof(APITest).GetTypeInfo().Assembly;

            string file = string.Format("{0}.{1}", resourcePath, fileName);

            Stream resource = assembly.GetManifestResourceStream(file);

            MemoryStream ms = new MemoryStream();
            resource.CopyTo(ms);
            ms.Position = 0;

            return ms;
        }

        private string GetContentTypeFromFile(string extension)
        {
            if (extension.Equals(".json"))
                return "application/json";
            else if (extension.Equals(".xml"))
                return "application/xml";
            else
                return string.Empty;
        }
    }
}
